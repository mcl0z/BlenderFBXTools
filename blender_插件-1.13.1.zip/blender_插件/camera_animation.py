from .core_base import *

# Camera animation property group/operators/panel.
class CameraAnimationProperties(bpy.types.PropertyGroup):
    """摄像机动画设置"""

    # --- 摄像机抖动设置 ---
    shake_frame_start: bpy.props.IntProperty(
        name="抖动起始帧",
        description="摄像机抖动效果的起始帧",
        default=1,
        min=1
    )
    shake_frame_end: bpy.props.IntProperty(
        name="抖动结束帧",
        description="摄像机抖动效果的结束帧",
        default=100,
        min=2
    )
    shake_type: bpy.props.EnumProperty(
        name="抖动类型",
        description="选择抖动的方式",
        items=[
            ('UP_DOWN', "上下摆动", "摄像机沿垂直方向(Z轴)摆动"),
            ('LEFT_RIGHT', "左右摆动", "摄像机沿水平方向(X轴)摆动"),
            ('RANDOM', "随机摆动", "摄像机在多个轴向上随机摆动")
        ],
        default='RANDOM'
    )
    shake_amount_pos: bpy.props.FloatProperty(
        name="位置抖动幅度",
        description="位置抖动的最大偏移量",
        default=0.1,
        min=0.0,
        max=5.0,
        unit='LENGTH'
    )
    shake_amount_rot: bpy.props.FloatProperty(
        name="旋转抖动幅度",
        description="旋转抖动的最大角度(度)",
        default=1.0,
        min=0.0,
        max=45.0,
        subtype='ANGLE',
        unit='ROTATION'
    )
    shake_frequency: bpy.props.FloatProperty(
        name="抖动频率",
        description="抖动的速度/频率 (值越高抖动越快)",
        default=5.0,
        min=0.1,
        max=50.0
    )
    shake_use_position: bpy.props.BoolProperty(
        name="启用位置抖动",
        description="是否应用位置上的抖动",
        default=True
    )
    shake_use_rotation: bpy.props.BoolProperty(
        name="启用旋转抖动",
        description="是否应用旋转上的抖动",
        default=True
    )
    
    # --- 摄像机自然晃动设置 ---
    natural_shake_enabled: bpy.props.BoolProperty(
        name="启用自然晃动",
        description="启用更自然的摄像机晃动效果",
        default=False
    )
    natural_shake_intensity: bpy.props.FloatProperty(
        name="晃动强度",
        description="控制摄像机晃动的幅度",
        default=0.05,
        min=0.0,
        max=1.0
    )
    natural_shake_frequency: bpy.props.FloatProperty(
        name="晃动频率",
        description="控制摄像机晃动的频率",
        default=0.5,
        min=0.1,
        max=5.0
    )
    natural_shake_seed: bpy.props.IntProperty(
        name="随机种子",
        description="控制晃动的随机模式",
        default=1,
        min=1
    )
    natural_shake_type: bpy.props.EnumProperty(
        name="晃动类型",
        description="选择晃动的风格",
        items=[
            ('HANDHELD', "手持", "模拟手持摄像机的自然晃动"),
            ('WALKING', "行走", "模拟行走时的摄像机晃动"),
            ('RUNNING', "奔跑", "模拟奔跑时的摄像机晃动")
        ],
        default='HANDHELD'
    )
    natural_shake_affect_location: bpy.props.BoolProperty(
        name="影响位置",
        description="晃动是否影响摄像机位置",
        default=True
    )
    natural_shake_affect_rotation: bpy.props.BoolProperty(
        name="影响旋转",
        description="晃动是否影响摄像机旋转",
        default=True
    )
    natural_shake_location_factor: bpy.props.FloatVectorProperty(
        name="位置权重",
        description="控制各轴向位置晃动的权重",
        default=(1.0, 1.0, 0.5),
        min=0.0,
        max=1.0,
        size=3
    )
    natural_shake_rotation_factor: bpy.props.FloatVectorProperty(
        name="旋转权重",
        description="控制各轴向旋转晃动的权重",
        default=(0.5, 0.5, 1.0),
        min=0.0,
        max=1.0,
        size=3
    )
    natural_shake_use_ease: bpy.props.BoolProperty(
        name="使用缓入缓出",
        description="在晃动开始和结束时使用平滑过渡",
        default=True
    )
    natural_shake_keyframe_gap: bpy.props.IntProperty(
        name="关键帧间隔",
        description="每隔多少帧插入一个关键帧",
        default=1,
        min=1,
        max=10
    )
    natural_shake_noise_method: bpy.props.EnumProperty(
        name="噪波方法",
        description="用于生成晃动的噪波算法",
        items=[
            ('PERLIN', "柏林噪波", "使用柏林噪波生成平滑的晃动"),
            ('SIMPLEX', "单纯形噪波", "使用单纯形噪波生成更自然的晃动"),
            ('RANDOM', "随机噪波", "使用随机数生成更急促的晃动")
        ],
        default='PERLIN'
    )
    
    # --- 摄像机自然晃动设置 ---
    natural_shake_enabled: bpy.props.BoolProperty(
        name="启用自然晃动",
        description="启用更自然的摄像机晃动效果",
        default=False
    )
    natural_shake_intensity: bpy.props.FloatProperty(
        name="晃动强度",
        description="控制摄像机晃动的幅度",
        default=0.05,
        min=0.0,
        max=1.0
    )
    natural_shake_frequency: bpy.props.FloatProperty(
        name="晃动频率",
        description="控制摄像机晃动的频率",
        default=0.5,
        min=0.1,
        max=5.0
    )
    natural_shake_seed: bpy.props.IntProperty(
        name="随机种子",
        description="控制晃动的随机模式",
        default=1,
        min=1
    )
    natural_shake_type: bpy.props.EnumProperty(
        name="晃动类型",
        description="选择晃动的风格",
        items=[
            ('HANDHELD', "手持", "模拟手持摄像机的自然晃动"),
            ('WALKING', "行走", "模拟行走时的摄像机晃动"),
            ('RUNNING', "奔跑", "模拟奔跑时的摄像机晃动")
        ],
        default='HANDHELD'
    )
    natural_shake_affect_location: bpy.props.BoolProperty(
        name="影响位置",
        description="晃动是否影响摄像机位置",
        default=True
    )
    natural_shake_affect_rotation: bpy.props.BoolProperty(
        name="影响旋转",
        description="晃动是否影响摄像机旋转",
        default=True
    )
    natural_shake_location_factor: bpy.props.FloatVectorProperty(
        name="位置权重",
        description="控制各轴向位置晃动的权重",
        default=(1.0, 1.0, 0.5),
        min=0.0,
        max=1.0,
        size=3
    )
    natural_shake_rotation_factor: bpy.props.FloatVectorProperty(
        name="旋转权重",
        description="控制各轴向旋转晃动的权重",
        default=(0.5, 0.5, 1.0),
        min=0.0,
        max=1.0,
        size=3
    )
    natural_shake_use_ease: bpy.props.BoolProperty(
        name="使用缓入缓出",
        description="在晃动开始和结束时使用平滑过渡",
        default=True
    )
    natural_shake_keyframe_gap: bpy.props.IntProperty(
        name="关键帧间隔",
        description="每隔多少帧插入一个关键帧",
        default=1,
        min=1,
        max=10
    )
    natural_shake_noise_method: bpy.props.EnumProperty(
        name="噪波方法",
        description="用于生成晃动的噪波算法",
        items=[
            ('PERLIN', "柏林噪波", "使用柏林噪波生成平滑的晃动"),
            ('SIMPLEX', "单纯形噪波", "使用单纯形噪波生成更自然的晃动"),
            ('RANDOM', "随机噪波", "使用随机数生成更急促的晃动")
        ],
        default='PERLIN'
    )

    # --- 摄像机跟踪设置 ---
    tracking_frame_start: bpy.props.IntProperty(
        name="跟踪起始帧",
        description="摄像机跟踪效果的起始帧",
        default=1,
        min=1
    )
    tracking_frame_end: bpy.props.IntProperty(
        name="跟踪结束帧",
        description="摄像机跟踪效果的结束帧",
        default=100,
        min=2
    )
    tracking_target: bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="跟踪目标",
        description="选择摄像机要跟踪的物体或骨骼"
        # poll function can be added later to filter object types if needed
    )
    tracking_bone_target: bpy.props.StringProperty(
        name="跟踪骨骼名称",
        description="如果跟踪目标是骨架，指定要跟踪的具体骨骼名称"
    )
    tracking_mode: bpy.props.EnumProperty(
        name="跟踪模式",
        description="选择摄像机的跟踪方式",
        items=[
            ('ROTATION_ONLY', "仅旋转跟踪", "摄像机位置不变，仅旋转朝向目标"),
            ('POSITION_ONLY', "仅位置跟踪", "摄像机旋转不变，仅移动位置以保持相对朝向"),
            ('ORBIT_AND_TRACK', "环绕跟踪", "环绕目标旋转并跟踪目标")
        ],
        default='ROTATION_ONLY'
    )

    # 添加环绕旋转参数
    orbit_speed: bpy.props.FloatProperty(
        name="旋转速度",
        description="环绕目标旋转的速度 (度/帧)",
        default=1.0,
        min=0.1,
        max=10.0
    )

    orbit_revolutions: bpy.props.FloatProperty(
        name="旋转圈数",
        description="在整个帧范围内完成的旋转圈数",
        default=1.0,
        min=0.1,
        max=10.0
    )

    orbit_radius: bpy.props.FloatProperty(
        name="环绕半径",
        description="围绕目标旋转的距离",
        default=5.0,
        min=0.1,
        max=50.0,
        unit='LENGTH'
    )

    # 环绕跟踪的垂直角度
    orbit_vertical_angle: bpy.props.FloatProperty(
        name="俯仰角度",
        description="环绕时的俯视角或仰视角（正值为俯视，负值为仰视）",
        default=0.0,
        min=-89.0,
        max=89.0,
        subtype='ANGLE',
        unit='ROTATION'
    )

    # 环绕距离（如果已有orbit_radius则不需要重复添加）
    orbit_radius: bpy.props.FloatProperty(
        name="环绕距离",
        description="摄像机与目标的距离",
        default=5.0,
        min=0.1,
        max=50.0,
        unit='LENGTH'
    )

# 新增摄像机抖动操作符
class ANIM_OT_ApplyCameraShake(bpy.types.Operator):
    bl_idname = "anim.apply_camera_shake"
    bl_label = "应用摄像机抖动"
    bl_description = "为选中的摄像机在指定帧范围内添加抖动效果"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # 必须选中一个摄像机对象
        obj = context.active_object
        return obj is not None and obj.type == 'CAMERA'

    def execute(self, context):
        cam_obj = context.active_object
        scene = context.scene
        props = scene.camera_anim_props

        # 检查是否是自然晃动模式
        if props.natural_shake_enabled:
            return self.apply_natural_shake(context, cam_obj, props)
        else:
            return self.apply_regular_shake(context, cam_obj, props)

    def apply_regular_shake(self, context, cam_obj, props):
        """应用普通的摄像机抖动效果"""
        scene = context.scene
        
        start_frame = props.shake_frame_start
        end_frame = props.shake_frame_end
        shake_type = props.shake_type
        amount_pos = props.shake_amount_pos
        amount_rot_deg = props.shake_amount_rot # 角度值
        frequency = props.shake_frequency
        use_pos = props.shake_use_position
        use_rot = props.shake_use_rotation

        if not use_pos and not use_rot:
            self.report({'WARNING'}, "未启用位置或旋转抖动")
            return {'CANCELLED'}

        if start_frame >= end_frame:
            self.report({'ERROR'}, "起始帧必须小于结束帧")
            return {'CANCELLED'}

        # 确保对象有动画数据
        if not cam_obj.animation_data:
            cam_obj.animation_data_create()
        if not cam_obj.animation_data.action:
            # 创建新动作或使用现有动作
            action_name = f"{cam_obj.name}Action"
            cam_obj.animation_data.action = bpy.data.actions.get(action_name) or bpy.data.actions.new(name=action_name)

        action = cam_obj.animation_data.action
        current_frame_original = scene.frame_current # 保存当前帧

        # 准备随机种子，确保每次运行结果不同但单次运行内一致
        random.seed(time.time())
        # 为每个轴向生成不同的随机偏移，使噪声看起来更自然
        seed_offset_x = random.random() * 100
        seed_offset_y = random.random() * 100
        seed_offset_z = random.random() * 100
        seed_offset_rx = random.random() * 100
        seed_offset_ry = random.random() * 100
        seed_offset_rz = random.random() * 100

        # 迭代每一帧应用混合抖动
        for frame in range(start_frame, end_frame + 1):
            scene.frame_set(frame) # 设置场景到当前帧以获取正确的变换

            # 1. 获取当前帧的原始世界变换
            original_matrix = cam_obj.matrix_world.copy()
            orig_loc, orig_rot_quat, orig_scale = original_matrix.decompose()

            # --- 计算抖动偏移量 ---
            pos_offset = mathutils.Vector((0.0, 0.0, 0.0))
            rot_offset_euler = mathutils.Euler((0.0, 0.0, 0.0), 'XYZ') # 使用XYZ欧拉角

            time_param = frame / frequency # 时间参数影响噪声变化

            if use_pos:
                noise_x = (random.random() * 2 - 1) if shake_type == 'RANDOM' else 0
                noise_y = (random.random() * 2 - 1) if shake_type == 'RANDOM' else ((random.random() * 2 - 1) if shake_type == 'LEFT_RIGHT' else 0)
                noise_z = (random.random() * 2 - 1) if shake_type == 'RANDOM' else ((random.random() * 2 - 1) if shake_type == 'UP_DOWN' else 0)

                # 使用简单的随机数模拟 (也可以换成更平滑的噪声函数如 mathutils.noise)
                # 这里用 random 模拟快速抖动
                pos_offset.x = noise_x * amount_pos
                pos_offset.y = noise_y * amount_pos
                pos_offset.z = noise_z * amount_pos

            if use_rot:
                amount_rot_rad = math.radians(amount_rot_deg) # 转换为弧度
                noise_rx = (random.random() * 2 - 1) if shake_type == 'RANDOM' else 0
                noise_ry = (random.random() * 2 - 1) if shake_type == 'RANDOM' else ((random.random() * 2 - 1) if shake_type == 'LEFT_RIGHT' else 0) # 假设左右摆动影响Y轴旋转
                noise_rz = (random.random() * 2 - 1) if shake_type == 'RANDOM' else ((random.random() * 2 - 1) if shake_type == 'UP_DOWN' else 0) # 假设上下摆动影响Z轴旋转

                rot_offset_euler.x = noise_rx * amount_rot_rad
                rot_offset_euler.y = noise_ry * amount_rot_rad
                rot_offset_euler.z = noise_rz * amount_rot_rad

            new_loc = orig_loc + pos_offset
            rot_offset_quat = rot_offset_euler.to_quaternion()
            new_rot_quat = orig_rot_quat @ rot_offset_quat
            
            # 应用混合后的变换到对象 (临时，为了插帧) 
            # 设置局部变换 即内部坐标系
            # 如果父级有变换，需要转换回内部坐标系
            if cam_obj.parent:
                 parent_inv = cam_obj.matrix_parent_inverse.copy()
                 new_matrix_world = mathutils.Matrix.Translation(new_loc) @ new_rot_quat.to_matrix().to_4x4() @ mathutils.Matrix.Diagonal(orig_scale).to_4x4()
                 new_matrix_local = parent_inv @ new_matrix_world
                 cam_obj.matrix_local = new_matrix_local
            else:
                 cam_obj.location = new_loc
                 cam_obj.rotation_quaternion = new_rot_quat
                 cam_obj.scale = orig_scale # 缩放不变

            # 插入
            if use_pos:
                cam_obj.keyframe_insert(data_path="location", frame=frame)
            if use_rot:
                cam_obj.keyframe_insert(data_path="rotation_quaternion", frame=frame)

        scene.frame_set(current_frame_original)

        self.report({'INFO'}, f"已在帧 {start_frame}-{end_frame} 应用摄像机抖动")
        return {'FINISHED'}
        
    def apply_natural_shake(self, context, cam_obj, props):
        """应用自然晃动效果，模拟风吹或手持摄像机的自然晃动"""
        scene = context.scene
        
        start_frame = props.shake_frame_start
        end_frame = props.shake_frame_end
        shake_type = props.natural_shake_type
        intensity = props.natural_shake_intensity
        frequency = props.natural_shake_frequency
        use_location = props.natural_shake_affect_location
        use_rotation = props.natural_shake_affect_rotation
        keyframe_gap = props.natural_shake_keyframe_gap
        noise_method = props.natural_shake_noise_method
        
        if not use_location and not use_rotation:
            self.report({'WARNING'}, "未启用位置或旋转晃动")
            return {'CANCELLED'}

        if start_frame >= end_frame:
            self.report({'ERROR'}, "起始帧必须小于结束帧")
            return {'CANCELLED'}

        # 确保对象有动画数据
        if not cam_obj.animation_data:
            cam_obj.animation_data_create()
        if not cam_obj.animation_data.action:
            # 创建新动作或使用现有动作
            action_name = f"{cam_obj.name}Action"
            cam_obj.animation_data.action = bpy.data.actions.get(action_name) or bpy.data.actions.new(name=action_name)

        action = cam_obj.animation_data.action
        current_frame_original = scene.frame_current # 保存当前帧

        # 设置随机种子
        random.seed(props.natural_shake_seed)
        
        # 根据晃动类型调整参数
        if shake_type == 'HANDHELD':
            loc_multiplier = 0.1
            rot_multiplier = 0.5
        elif shake_type == 'WALKING':
            loc_multiplier = 0.2
            rot_multiplier = 0.3
        else:  # RUNNING
            loc_multiplier = 0.3
            rot_multiplier = 0.6

        # 为每一帧添加晃动
        for frame in range(start_frame, end_frame + 1):
            # 只在指定间隔的帧上添加关键帧
            if frame % keyframe_gap != 0:
                continue
                
            scene.frame_set(frame) # 设置场景到当前帧以获取正确的变换
            
            # 获取当前帧的原始世界变换
            original_matrix = cam_obj.matrix_world.copy()
            orig_loc, orig_rot_quat, orig_scale = original_matrix.decompose()
            
            # 转换为欧拉角以便更容易修改
            orig_rot_euler = orig_rot_quat.to_euler('XYZ')
            
            # 计算时间因子
            time_factor = frame * 0.05 * frequency
            
            # 位置晃动
            pos_offset = mathutils.Vector((0.0, 0.0, 0.0))
            if use_location:
                # 根据选择的噪波方法生成随机值
                if noise_method == 'PERLIN':
                    # 使用Perlin噪声生成平滑的晃动
                    try:
                        # 尝试使用mathutils中的噪声函数
                        pos_offset.x = mathutils.noise.noise((time_factor, 0, 0)) * intensity * loc_multiplier * props.natural_shake_location_factor[0]
                        pos_offset.y = mathutils.noise.noise((0, time_factor, 0)) * intensity * loc_multiplier * props.natural_shake_location_factor[1]
                        pos_offset.z = mathutils.noise.noise((0, 0, time_factor)) * intensity * loc_multiplier * props.natural_shake_location_factor[2]
                    except:
                        # 如果mathutils.noise不可用，使用正弦函数模拟
                        pos_offset.x = math.sin(time_factor * 1.0) * math.sin(time_factor * 2.7) * intensity * loc_multiplier * props.natural_shake_location_factor[0]
                        pos_offset.y = math.sin(time_factor * 1.5) * math.sin(time_factor * 3.1) * intensity * loc_multiplier * props.natural_shake_location_factor[1]
                        pos_offset.z = math.sin(time_factor * 2.0) * math.sin(time_factor * 1.7) * intensity * loc_multiplier * props.natural_shake_location_factor[2]
                else:
                    # 使用正弦和余弦函数生成平滑的随机值
                    pos_offset.x = math.sin(time_factor * 1.0) * math.sin(time_factor * 2.7) * intensity * loc_multiplier * props.natural_shake_location_factor[0]
                    pos_offset.y = math.sin(time_factor * 1.5) * math.sin(time_factor * 3.1) * intensity * loc_multiplier * props.natural_shake_location_factor[1]
                    pos_offset.z = math.sin(time_factor * 2.0) * math.sin(time_factor * 1.7) * intensity * loc_multiplier * props.natural_shake_location_factor[2]
                
                # 添加一些随机性
                if noise_method == 'RANDOM':
                    pos_offset.x += (random.random() - 0.5) * intensity * loc_multiplier * 0.5 * props.natural_shake_location_factor[0]
                    pos_offset.y += (random.random() - 0.5) * intensity * loc_multiplier * 0.5 * props.natural_shake_location_factor[1]
                    pos_offset.z += (random.random() - 0.5) * intensity * loc_multiplier * 0.5 * props.natural_shake_location_factor[2]
            
            # 旋转晃动
            rot_offset = mathutils.Euler((0.0, 0.0, 0.0), 'XYZ')
            if use_rotation:
                if noise_method == 'PERLIN':
                    try:
                        # 尝试使用mathutils中的噪声函数
                        rot_offset.x = mathutils.noise.noise((time_factor * 2.5, 10, 10)) * intensity * rot_multiplier * 0.05 * props.natural_shake_rotation_factor[0]
                        rot_offset.y = mathutils.noise.noise((20, time_factor * 3.0, 20)) * intensity * rot_multiplier * 0.05 * props.natural_shake_rotation_factor[1]
                        rot_offset.z = mathutils.noise.noise((30, 30, time_factor * 1.7)) * intensity * rot_multiplier * 0.05 * props.natural_shake_rotation_factor[2]
                    except:
                        # 如果mathutils.noise不可用，使用正弦函数模拟
                        rot_offset.x = math.sin(time_factor * 2.5) * math.sin(time_factor * 1.3) * intensity * rot_multiplier * 0.05 * props.natural_shake_rotation_factor[0]
                        rot_offset.y = math.sin(time_factor * 3.0) * math.sin(time_factor * 2.2) * intensity * rot_multiplier * 0.05 * props.natural_shake_rotation_factor[1]
                        rot_offset.z = math.sin(time_factor * 1.7) * math.sin(time_factor * 2.9) * intensity * rot_multiplier * 0.05 * props.natural_shake_rotation_factor[2]
                else:
                    # 使用不同频率的正弦函数生成平滑的旋转晃动
                    rot_offset.x = math.sin(time_factor * 2.5) * math.sin(time_factor * 1.3) * intensity * rot_multiplier * 0.05 * props.natural_shake_rotation_factor[0]
                    rot_offset.y = math.sin(time_factor * 3.0) * math.sin(time_factor * 2.2) * intensity * rot_multiplier * 0.05 * props.natural_shake_rotation_factor[1]
                    rot_offset.z = math.sin(time_factor * 1.7) * math.sin(time_factor * 2.9) * intensity * rot_multiplier * 0.05 * props.natural_shake_rotation_factor[2]
                
                # 添加一些随机性
                if noise_method == 'RANDOM':
                    rot_offset.x += (random.random() - 0.5) * intensity * rot_multiplier * 0.02 * props.natural_shake_rotation_factor[0]
                    rot_offset.y += (random.random() - 0.5) * intensity * rot_multiplier * 0.02 * props.natural_shake_rotation_factor[1]
                    rot_offset.z += (random.random() - 0.5) * intensity * rot_multiplier * 0.02 * props.natural_shake_rotation_factor[2]
            
            # 应用位置和旋转偏移
            new_loc = orig_loc + pos_offset
            new_rot_euler = mathutils.Euler((
                orig_rot_euler.x + rot_offset.x,
                orig_rot_euler.y + rot_offset.y,
                orig_rot_euler.z + rot_offset.z
            ), 'XYZ')
            new_rot_quat = new_rot_euler.to_quaternion()
            
            # 应用变换
            if cam_obj.parent:
                parent_inv = cam_obj.matrix_parent_inverse.copy()
                new_matrix_world = mathutils.Matrix.Translation(new_loc) @ new_rot_quat.to_matrix().to_4x4() @ mathutils.Matrix.Diagonal(orig_scale).to_4x4()
                new_matrix_local = parent_inv @ new_matrix_world
                cam_obj.matrix_local = new_matrix_local
            else:
                cam_obj.location = new_loc
                cam_obj.rotation_euler = new_rot_euler
                cam_obj.scale = orig_scale
            
            # 插入关键帧
            if use_location:
                cam_obj.keyframe_insert('location', frame=frame)
            if use_rotation:
                cam_obj.keyframe_insert('rotation_euler', frame=frame)
        
        # 恢复原始当前帧
        scene.frame_set(current_frame_original)
        
        self.report({'INFO'}, f"已为摄像机添加自然晃动效果 (帧 {start_frame} 到 {end_frame})")
        return {'FINISHED'}

# 新增摄像机跟踪操作符
class ANIM_OT_ApplyCameraTracking(bpy.types.Operator):
    bl_idname = "anim.apply_camera_tracking"
    bl_label = "应用摄像机跟踪"
    bl_description = "使选中的摄像机在指定帧范围内跟踪目标"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        props = context.scene.camera_anim_props
        return (context.active_object and 
                context.active_object.type == 'CAMERA' and 
                props.tracking_target)
    def execute(self, context):
        scene = context.scene
        props = scene.camera_anim_props
        cam = context.active_object
        target = props.tracking_target

        # Add imports if they are not already at the top of the file
        import math
        import mathutils
        import traceback # For error reporting

        if not target:
            self.report({'WARNING'}, "请先选择一个跟踪目标")
            return {'CANCELLED'}

        # 获取参数
        start_frame = props.tracking_frame_start
        end_frame = props.tracking_frame_end
        tracking_mode = props.tracking_mode

        if end_frame <= start_frame:
            self.report({'WARNING'}, "结束帧必须大于起始帧")
            return {'CANCELLED'}

        # --- 准备动画数据和 F-Curves ---
        if not cam.animation_data:
            cam.animation_data_create()
        action = cam.animation_data.action
        if not action:
            # Use a more specific name for the action
            action = bpy.data.actions.new(f"{cam.name}_TrackingAction")
            cam.animation_data.action = action

        # --- 确定旋转模式和数据路径 ---
        # Prefer Quaternion, fall back to Euler XYZ for simplicity in calculations hi i'm deepseekR1 
        rot_mode = cam.rotation_mode
        if rot_mode not in {'QUATERNION', 'AXIS_ANGLE'}:
            # Force Euler XYZ if it's an Euler mode but not simple XYZ
            if rot_mode not in ('XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX'):
                cam.rotation_mode = 'XYZ' # Set the object's mode
            rot_mode = cam.rotation_mode # Read the potentially changed mode
            rot_data_path = 'rotation_euler'
            rot_indices = range(3) # X, Y, Z
        elif rot_mode == 'QUATERNION':
            rot_data_path = 'rotation_quaternion'
            rot_indices = range(4) # W, X, Y, Z
        else: # AXIS_ANGLE is tricky to handle directly with tracking math
             self.report({'WARNING'}, f"暂不支持 {rot_mode} 旋转模式的直接跟踪，请切换到欧拉或四元数")
             return {'CANCELLED'}

        loc_data_path = 'location'

        # --- 辅助函数: 获取/创建 F-Curve 并清除范围 ---
        def get_or_create_fcurve_and_clear_range(data_path, index):
            fcurve = action.fcurves.find(data_path, index=index)
            if not fcurve:
                # This is where the original error occurred if the fcurve existed
                # but bpy.ops tried to create it again. `find` avoids this.
                fcurve = action.fcurves.new(data_path, index=index)

            # Clear keyframes *only* within the target range before adding new ones
            keyframes_to_remove = [kp for kp in fcurve.keyframe_points if start_frame <= kp.co.x <= end_frame]
            # Iterate over a copy for safe removal
            for kp in keyframes_to_remove:
                 try:
                    fcurve.keyframe_points.remove(kp)
                 except RuntimeError: # Handle potential issues if kp is already gone
                    print(f"Warning: Could not remove keyframe at {kp.co.x} for {data_path}[{index}]")
                    pass # Continue if removal fails for some reason
            return fcurve

        # --- 获取或创建所有需要的 F-Curves ---
        try:
            loc_fcurves = {i: get_or_create_fcurve_and_clear_range(loc_data_path, i) for i in range(3)}
            rot_fcurves = {i: get_or_create_fcurve_and_clear_range(rot_data_path, i) for i in rot_indices}
        except Exception as e: # Catch potential errors during F-Curve handling
            traceback.print_exc()
            self.report({'ERROR'}, f"处理 F-Curves 时出错: {e}")
            return {'CANCELLED'}

        # --- 记录应用跟踪前的初始状态 ---
        # Evaluate at the frame *before* the tracking starts, or scene start
        eval_frame = max(scene.frame_start, start_frame - 1)
        if start_frame <= scene.frame_start:
            eval_frame = scene.frame_start

        original_frame = scene.frame_current
        scene.frame_set(eval_frame)
        context.view_layer.update() # Ensure evaluated state is calculated

        # Store initial LOCAL transforms for reference in some modes
        initial_local_location = cam.location.copy()
        initial_local_rotation = getattr(cam, rot_data_path).copy()
        initial_world_matrix = cam.matrix_world.copy() # Store initial world matrix too

        scene.frame_set(original_frame) # Restore original frame immediately
        context.view_layer.update()

        # --- 缓存目标的骨骼（如果需要）---
        target_bone = None
        if target.type == 'ARMATURE' and props.tracking_bone_target:
            target_bone = target.pose.bones.get(props.tracking_bone_target)
            if not target_bone:
                self.report({'WARNING'}, f"在骨架 '{target.name}' 中未找到骨骼 '{props.tracking_bone_target}', 将跟踪骨架原点")
                # Do not cancel, just track the armature origin instead

        # 逐帧处理
        try:
            for frame in range(start_frame, end_frame + 1):
                scene.frame_set(frame)

                context.view_layer.update()
                if target_bone:
                
                    try:
                         target_pos_world = target.matrix_world @ target_bone.head
                    except (ReferenceError, AttributeError):
       
                         target_pos_world = target.matrix_world.translation.copy()
                         target_bone = None 
                         print(f"Warning: Target bone lost at frame {frame}, tracking armature origin.")
                else:
                    target_pos_world = target.matrix_world.translation.copy()

                current_cam_world_loc = cam.matrix_world.translation.copy()


                new_cam_world_pos = current_cam_world_loc
                rot_quat_world = cam.matrix_world.to_quaternion() 

                if tracking_mode == 'ROTATION_ONLY':

                    new_cam_world_pos = initial_world_matrix.translation

                    direction_world = target_pos_world - new_cam_world_pos
                    if direction_world.length > 0.0001:

                        rot_quat_world = direction_world.to_track_quat('-Z', 'Y')
                    else:

                        rot_quat_world = initial_world_matrix.to_quaternion()

                elif tracking_mode == 'POSITION_ONLY':

                    if frame == start_frame:

                         initial_target_pos_world = target_pos_world.copy()
                         world_offset_vector = initial_world_matrix.translation - initial_target_pos_world

                    new_cam_world_pos = target_pos_world + world_offset_vector
                    # Keep the initial world orientation
                    rot_quat_world = initial_world_matrix.to_quaternion()

                elif tracking_mode == 'ORBIT_AND_TRACK':
                    duration = end_frame - start_frame
                    progress = (frame - start_frame) / duration if duration > 0 else 0


                    if props.orbit_revolutions > 0 and duration > 0:
                        angle = progress * 2 * math.pi * props.orbit_revolutions
                    else:
                        angle = (frame - start_frame) * math.radians(props.orbit_speed)
                    vertical_angle = math.radians(props.orbit_vertical_angle)
                    radius = props.orbit_radius
                    offset_x = radius * math.cos(angle) * math.cos(vertical_angle)
                    offset_y = radius * math.sin(angle) * math.cos(vertical_angle)
                    offset_z = radius * math.sin(vertical_angle)
                    orbit_offset_world = mathutils.Vector((offset_x, offset_y, offset_z))


                    new_cam_world_pos = target_pos_world + orbit_offset_world


                    look_at_world = target_pos_world - new_cam_world_pos
                    if look_at_world.length > 0.0001:
                        rot_quat_world = look_at_world.to_track_quat('-Z', 'Y')
                    else:
            
                         if frame > start_frame and rot_fcurves: 
                             try:
                    
                                 if rot_data_path == 'rotation_quaternion':
                                     last_rot_val = [rot_fcurves.get(i).evaluate(frame - 1) for i in rot_indices if rot_fcurves.get(i)]
                                     if len(last_rot_val) == 4: 
                                         rot_quat_world = mathutils.Quaternion(last_rot_val).normalized()
                                     else:
                                          rot_quat_world = initial_world_matrix.to_quaternion()
                                 else: 
                                     last_rot_val = [rot_fcurves.get(i).evaluate(frame - 1) for i in rot_indices if rot_fcurves.get(i)]
                                     if len(last_rot_val) == 3:
                                          rot_quat_world = mathutils.Euler(last_rot_val, rot_mode).to_quaternion()
                                     else:
                                          rot_quat_world = initial_world_matrix.to_quaternion()
                             except: 
                                rot_quat_world = initial_world_matrix.to_quaternion()
                         else:
                             rot_quat_world = initial_world_matrix.to_quaternion()



                target_world_matrix = (mathutils.Matrix.Translation(new_cam_world_pos) @
                                       rot_quat_world.to_matrix().to_4x4())

                if cam.parent:
                    local_matrix = cam.matrix_parent_inverse @ target_world_matrix
                else:
                    local_matrix = target_world_matrix 

                cam.location = local_matrix.to_translation()
                if rot_data_path == 'rotation_quaternion':
                    cam.rotation_quaternion = local_matrix.to_quaternion().normalized()
                else:
                    cam.rotation_euler = local_matrix.to_euler(rot_mode)

                cam.keyframe_insert(data_path=loc_data_path, frame=frame)
                cam.keyframe_insert(data_path=rot_data_path, frame=frame)

        except Exception as e:
            traceback.print_exc()
            self.report({'ERROR'}, f"应用跟踪时出错: {e}")
 
            scene.frame_set(original_frame)
            context.view_layer.update()
            return {'CANCELLED'}

            scene.frame_set(original_frame)
            context.view_layer.update()

        all_fcurves = list(loc_fcurves.values()) + list(rot_fcurves.values())
        for fc in all_fcurves:
            if not fc or not fc.keyframe_points:
                 continue
            for kp in fc.keyframe_points:

                if start_frame <= kp.co.x <= end_frame:
                    kp.interpolation = 'BEZIER' 
                    kp.handle_left_type = 'AUTO'
                    kp.handle_right_type = 'AUTO'
            try:
                fc.update() 
            except Exception as e:
                 print(f"Warning: Could not update fcurve {fc.data_path}[{fc.array_index}]: {e}")

        self.report({'INFO'}, f"已为摄像机 '{cam.name}' 应用跟踪动画 [{start_frame}-{end_frame}]")
        return {'FINISHED'}
class ANIM_PT_CameraAnimation(bpy.types.Panel):
    bl_label = "摄像机动画工具"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "动画工具" # 和主面板保持一致

    @classmethod
    def poll(cls, context):
        # 只在 active_panel 为 CAMERA 时显示
        return context.scene.anim_merge_props.active_panel == 'CAMERA'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        props = scene.camera_anim_props # 获取摄像机动画属性

        active_obj = context.active_object

        # 检查是否选中了摄像机
        if not active_obj or active_obj.type != 'CAMERA':
            box = layout.box()
            box.label(text="请先选择一个摄像机对象", icon='ERROR')
            return

        # --- 摄像机自然晃动设置 ---
        natural_box = layout.box()
        natural_box.label(text="自然晃动效果", icon='MOD_NOISE')
        
        # 启用/禁用自然晃动
        natural_box.prop(props, "natural_shake_enabled", text="启用自然晃动")
        
        # 只有启用时才显示其他选项
        if props.natural_shake_enabled:
            # 帧范围
            row = natural_box.row(align=True)
            row.prop(props, "shake_frame_start", text="起始帧")
            row.prop(props, "shake_frame_end", text="结束帧")
            
            # 基本参数
            natural_box.prop(props, "natural_shake_type", text="晃动类型")
            natural_box.prop(props, "natural_shake_intensity", text="强度")
            natural_box.prop(props, "natural_shake_frequency", text="频率")
            
            # 影响选项
            row = natural_box.row(align=True)
            row.prop(props, "natural_shake_affect_location", text="影响位置")
            row.prop(props, "natural_shake_affect_rotation", text="影响旋转")
            
            # 高级选项
            advanced = natural_box.box()
            advanced.label(text="高级设置:")
            advanced.prop(props, "natural_shake_noise_method", text="噪波方法")
            advanced.prop(props, "natural_shake_keyframe_gap", text="关键帧间隔")
            
            if props.natural_shake_affect_location:
                advanced.prop(props, "natural_shake_location_factor", text="位置权重")
            if props.natural_shake_affect_rotation:
                advanced.prop(props, "natural_shake_rotation_factor", text="旋转权重")
            
            # 随机种子
            advanced.prop(props, "natural_shake_seed", text="随机种子")
            
            # 应用按钮
            natural_box.operator("anim.apply_camera_shake", text="应用自然晃动效果", icon='PLAY')

        # --- 摄像机抖动功能区 ---
        shake_box = layout.box()
        shake_box.label(text="摄像机抖动", icon='SHADERFX') # 使用一个看起来像效果的图标

        # 抖动帧范围
        row = shake_box.row(align=True)
        row.prop(props, "shake_frame_start", text="起始帧")
        row.prop(props, "shake_frame_end", text="结束帧")

        # 抖动类型
        shake_box.prop(props, "shake_type", text="类型")

        # 抖动影响开关
        row = shake_box.row(align=True)
        row.prop(props, "shake_use_position", text="位置", toggle=True)
        row.prop(props, "shake_use_rotation", text="旋转", toggle=True)

        # 抖动幅度 - 根据开关启用/禁用
        row = shake_box.row(align=True)
        pos_col = row.column(align=True)
        pos_col.enabled = props.shake_use_position # 启用/禁用位置幅度
        pos_col.prop(props, "shake_amount_pos", text="幅度")

        rot_col = row.column(align=True)
        rot_col.enabled = props.shake_use_rotation # 启用/禁用旋转幅度
        rot_col.prop(props, "shake_amount_rot", text="幅度")

        # 抖动频率
        shake_box.prop(props, "shake_frequency", text="频率")

        # 应用抖动按钮
        shake_box.operator("anim.apply_camera_shake", text="应用抖动效果", icon='PLAY')

        # --- 摄像机跟踪功能区 ---
        track_box = layout.box()
        track_box.label(text="摄像机跟踪", icon='CONSTRAINT')

        # 跟踪帧范围
        row = track_box.row(align=True)
        row.prop(props, "tracking_frame_start", text="起始帧")
        row.prop(props, "tracking_frame_end", text="结束帧")

        # 跟踪目标选择
        track_box.prop(props, "tracking_target", text="目标物体")

        # 如果目标是骨架，显示骨骼名称输入
        if props.tracking_target and props.tracking_target.type == 'ARMATURE':
            row = track_box.row(align=True)
            # 添加骨骼搜索功能 (可以使用现有的骨骼搜索，或者简单文本输入)
            row.prop(props, "tracking_bone_target", text="骨骼名称")
            # 可以考虑加一个按钮从骨架中选择骨骼

        # 跟踪模式
        track_box.prop(props, "tracking_mode", text="模式")

        # 应用跟踪按钮 - 正确设置启用状态
        track_button_row = track_box.row()
        track_button_row.enabled = bool(props.tracking_target) # 在行上设置 enabled
        track_button_row.operator("anim.apply_camera_tracking", text="应用跟踪效果", icon='PLAY')

        # 在绘制跟踪设置的部分
        if props.tracking_mode == 'ORBIT_AND_TRACK':
            track_box.prop(props, "orbit_radius")
            track_box.prop(props, "orbit_revolutions")
            track_box.prop(props, "orbit_speed")
            track_box.prop(props, "orbit_vertical_angle")

