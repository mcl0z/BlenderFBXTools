from .core_base import *
from .ops_orientation_library import (
    ANIM_OT_DeleteLibraryAction,
    ANIM_OT_RenameLibraryAction,
    ANIM_OT_ApplyProgressiveOffset,
    ANIM_OT_ApplyFixedOrientation,
)

PANEL_ITEMS = (
    ('MERGE', "动画合并", "ANIM"),
    ('LIBRARY', "动作库", "ACTION"),
    ('PATH', "路径动画", "CURVE_PATH"),
    ('BREATH', "呼吸动画", "ARMATURE_DATA"),
    ('CAMERA', "摄像机动画", "CAMERA_DATA"),
    ('UPDATE', "更新与信息", "INFO"),
)


# Main UI panels and update workflow.
class ANIM_PT_MainPanel(bpy.types.Panel):
    bl_label = "骨骼动画管理工具"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "动画工具"
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.anim_merge_props

        box = layout.box()
        row = box.row(align=True)
        row.alignment = 'CENTER'
        row.label(text="功能选择", icon="TOOL_SETTINGS")

        grid = box.grid_flow(
            row_major=True,
            columns=2,
            even_columns=True,
            even_rows=True,
            align=True,
        )
        for panel_id, label, icon in PANEL_ITEMS:
            op = grid.operator(
                "wm.context_set_enum",
                text=label,
                icon=icon,
                depress=(props.active_panel == panel_id),
            )
            op.data_path = "scene.anim_merge_props.active_panel"
            op.value = panel_id

        label_map = {panel_id: label for panel_id, label, _ in PANEL_ITEMS}
        status_box = layout.box()
        status_box.label(
            text=f"当前功能: {label_map.get(props.active_panel, props.active_panel)}",
            icon='INFO',
        )
        active_obj = context.active_object
        if active_obj:
            active_icon = 'ARMATURE_DATA' if active_obj.type == 'ARMATURE' else 'OBJECT_DATA'
            status_box.label(text=f"当前对象: {active_obj.name}", icon=active_icon)
        else:
            status_box.label(text="当前对象: 未选择", icon='ERROR')

class ANIM_PT_ActionLibrary(bpy.types.Panel):
    bl_label = "动作资产库"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "动画工具"
    
    @classmethod
    def poll(cls, context):
        return context.scene.anim_merge_props.active_panel == 'LIBRARY'
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.anim_merge_props
        layout.use_property_split = False
        layout.use_property_decorate = False

        has_items = len(props.action_library_items) > 0
        selected_valid = has_items and 0 <= props.action_library_index < len(props.action_library_items)
        selected_item = props.action_library_items[props.action_library_index] if selected_valid else None
        active_obj = context.active_object
        has_armature_target = bool(active_obj and active_obj.type == 'ARMATURE')
        selected_file_exists = bool(selected_item and selected_item.filepath and Path(selected_item.filepath).exists())

        box = layout.box()
        box.label(text="动作库", icon='LIBRARY_DATA_DIRECT')
        box.label(text=f"资产总数: {len(props.action_library_items)}", icon='INFO')
        if props.library_last_message:
            msg_box = box.box()
            msg_box.label(text=f"最近操作: {props.library_last_message}", icon='CHECKMARK')

        target_line = box.row(align=True)
        if has_armature_target:
            target_line.label(text=f"目标骨架: {active_obj.name}", icon='ARMATURE_DATA')
        elif active_obj:
            target_line.label(text=f"当前对象非骨架: {active_obj.name}", icon='ERROR')
        else:
            target_line.label(text="目标骨架: 未选择", icon='ERROR')

        if selected_item:
            start_f, end_f = selected_item.frame_range
            box.label(text=f"当前选中: {selected_item.name}", icon='ACTION')
            box.label(text=f"来源: {selected_item.source_fbx} | 帧范围: {start_f}-{end_f}", icon='TIME')
            if not selected_file_exists:
                box.label(text="警告: 选中动作文件不存在，建议删除该条目", icon='ERROR')
        elif has_items:
            box.label(text="动作库有条目，但当前选择无效", icon='ERROR')
        else:
            box.label(text="动作库为空，请先导入动作", icon='INFO')

        quick_manage = box.row(align=True)
        rename_row = quick_manage.row(align=True)
        rename_row.enabled = selected_valid and selected_file_exists
        rename_row.operator(ANIM_OT_RenameLibraryAction.bl_idname, text="重命名", icon='GREASEPENCIL')

        delete_row = quick_manage.row(align=True)
        delete_row.enabled = selected_valid
        delete_row.operator(ANIM_OT_DeleteLibraryAction.bl_idname, text="删除", icon='TRASH')

        manage_box = box.box()
        manage_box.label(text="导入/导出", icon='FILE_FOLDER')
        import_row = manage_box.row(align=True)
        import_row.operator("anim.import_to_library", text="导入FBX", icon='IMPORT')
        import_row.operator("anim.import_json", text="导入JSON", icon='FILE_TEXT')

        export_row = manage_box.row(align=True)
        export_row.enabled = has_armature_target
        export_row.operator("anim.export_action", text="导出当前动作", icon='EXPORT')
        export_row.operator("anim.save_custom_action", text="保存当前动作到库", icon='FILE_TICK')
        if not has_armature_target:
            manage_box.label(text="导出/保存需要选中骨架对象", icon='INFO')

        box.prop(props, "show_library", 
            icon='DOWNARROW_HLT' if props.show_library else 'RIGHTARROW',
            text="显示库内容" if not props.show_library else "隐藏库内容",
            emboss=True
        )
        
        if props.show_library:
            list_box = box.box()
            list_box.template_list(
                "ANIM_UL_ActionLibrary", "",
                props, "action_library_items",
                props, "action_library_index",
                rows=7
            )

            if not selected_valid:
                box.label(text="请先在列表中选择一个动作", icon='ERROR')
            elif not selected_file_exists:
                box.label(text="选中动作文件不存在，无法作为合并来源", icon='ERROR')
            else:
                box.label(text="已选择来源动作，请切换到“动画合并”面板执行", icon='INFO')

class ANIM_PT_MergeControl(bpy.types.Panel):
    bl_label = "动画合并"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "动画工具"
    
    @classmethod
    def poll(cls, context):
        return context.scene.anim_merge_props.active_panel == 'MERGE'
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.anim_merge_props
        obj = context.active_object
        has_armature_target = bool(obj and obj.type == 'ARMATURE')
        has_items = len(props.action_library_items) > 0
        selected_valid = has_items and 0 <= props.action_library_index < len(props.action_library_items)
        selected_item = props.action_library_items[props.action_library_index] if selected_valid else None
        selected_file_exists = bool(selected_item and selected_item.filepath and Path(selected_item.filepath).exists())
        auto_source_start = None
        auto_source_end = None
        if selected_item and selected_file_exists:
            auto_source_start = int(selected_item.frame_range[0])
            auto_source_end = int(selected_item.frame_range[1])

        source_box = layout.box()
        source_box.label(text="动画来源（动作库）", icon='LIBRARY_DATA_DIRECT')

        if selected_item:
            start_f, end_f = selected_item.frame_range
            source_box.label(text=f"当前来源: {selected_item.name}", icon='ACTION')
            source_box.label(text=f"分类: {selected_item.source_fbx} | 帧范围: {start_f}-{end_f}", icon='TIME')
            if not selected_file_exists:
                source_box.label(text="来源动作文件不存在，请删除后重新导入", icon='ERROR')
        elif has_items:
            source_box.label(text="动作库有条目，但当前选择无效", icon='ERROR')
        else:
            source_box.label(text="动作库为空，请先到动作库面板导入动作", icon='ERROR')

        source_switch = source_box.row(align=True)
        switch_op = source_switch.operator(
            "wm.context_set_enum",
            text="打开动作库选择来源",
            icon='ACTION',
        )
        switch_op.data_path = "scene.anim_merge_props.active_panel"
        switch_op.value = 'LIBRARY'

        execute_row = source_box.row(align=True)
        execute_row.scale_y = 1.2
        execute_row.enabled = has_armature_target and selected_valid and selected_file_exists
        execute_row.operator("anim.execute_merge_from_source", text="应用动作库选中动画", icon='PLAY')
        if not has_armature_target:
            source_box.label(text="请先选中目标骨架对象", icon='ERROR')
        elif not (selected_valid and selected_file_exists):
            source_box.label(text="请先在动作库中选择一个有效动作", icon='INFO')

        time_box = layout.box()
        col = time_box.column(align=True)
        col.label(text="时间控制", icon='TIME')
        
        # 源帧范围只读展示（自动识别）
        source_row = col.row(align=True)
        source_row.label(text="源帧范围:")
        if auto_source_start is not None and auto_source_end is not None:
            source_row.label(text=f"{auto_source_start} - {auto_source_end}", icon='KEYFRAME_HLT')
        else:
            source_row.label(text="未识别（请先在动作库选择有效动画）", icon='ERROR')
        
        # 目标起始帧设置
        target_row = col.row(align=True)
        target_row.label(text="目标起始帧:")
        target_row.prop(props, "target_start", text="")
        
        # 循环设置
        loop_row = col.row(align=True)
        loop_row.label(text="循环次数:")
        loop_row.prop(props, "loop_times", text="")
        
        merge_box = layout.box()
        merge_box.label(text="合并策略", icon='MODIFIER')
        mode_row = merge_box.row()
        mode_row.prop(props, "merge_mode", expand=True)
        merge_box.prop(props, "apply_transform", icon='ORIENTATION_LOCAL')
        merge_box.prop(props, "enable_bone_mapping", icon='BONE_DATA')
        if props.enable_bone_mapping:
            merge_box.label(text="启用后会在执行时弹出骨骼映射面板", icon='INFO')

        info_box = layout.box()
        info_box.label(text="当前状态", icon='INFO')
        if obj and obj.type == 'ARMATURE':
            info_box.label(text=f"目标骨架: {obj.name}", icon='ARMATURE_DATA')
            if selected_item and selected_file_exists:
                info_box.label(text=f"来源动作: {selected_item.name}", icon='ACTION')
            elif selected_item:
                info_box.label(text="来源动作文件不存在", icon='ERROR')
            else:
                info_box.label(text="来源动作: 未在动作库中选择", icon='INFO')
            
            if obj.animation_data and obj.animation_data.action:
                action = obj.animation_data.action
                frame_count = sum(len(fc.keyframe_points) for fc in action.fcurves)
                info_box.label(text=f"当前动作: {action.name}", icon='ACTION')
                info_box.label(text=f"关键帧总数: {frame_count}")
                info_box.label(text=f"帧范围: {int(action.frame_range[0])}-{int(action.frame_range[1])}")
            else:
                info_box.label(text="没有检测到动画", icon='KEYFRAME_HLT')
                
            if obj.location.length > 0.001 or obj.rotation_euler.to_quaternion().angle > 0.001:
                warning_box = info_box.box()
                warning_box.alert = True
                warning_box.label(text=f"注意: 骨架不在原点/有旋转", icon='ERROR')
                warning_box.label(text=f"位置: {format_vector(obj.location)}")
                warning_box.label(text=f"旋转: {format_vector(obj.rotation_euler)}")
        else:
            info_box.label(text="请选择骨架对象", icon='ERROR')

        tool_box = layout.box()
        tool_box.label(text="动作后期处理", icon='TOOL_SETTINGS')
        has_action = bool(
            obj
            and obj.type == 'ARMATURE'
            and obj.animation_data
            and obj.animation_data.action
        )
        tool_col = tool_box.column(align=True)
        tool_col.enabled = has_action
        tool_col.operator(ANIM_OT_ApplyProgressiveOffset.bl_idname, icon='IPO_CONSTANT', text="应用渐进位移")
        tool_col.operator(ANIM_OT_ApplyFixedOrientation.bl_idname, icon='ORIENTATION_GIMBAL', text="应用固定朝向")
        if not has_action:
            tool_box.label(text="需要选中带动作的骨架对象", icon='ERROR')

# 检查更新
def check_for_updates(auto_check=True):

    global last_update_check, update_available, latest_version, download_url, update_message

    if hasattr(bpy.app, "online_access") and not bpy.app.online_access:
        print("Blender 已禁用在线访问，跳过更新检查。")
        return
    
    # 如果是自动检查且上次检查时间未超过间隔，则跳过
    current_time = time.time()
    if auto_check and (current_time - last_update_check < UPDATE_CHECK_INTERVAL):
        return
    
    last_update_check = current_time
    
    # 获取当前版本
    current_version = ADDON_INFO['version']
    
    # 创建一个线程进行后台检查，避免阻塞主线程
    def background_check():
        global update_available, latest_version, download_url, update_message
        try:
            # 禁用SSL证书验证（仅用于测试环境）
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            
            # 发送请求检查更新
            print(f"正在连接更新服务器: {UPDATE_SERVER}/check_update")
            response = urllib.request.urlopen(f"{UPDATE_SERVER}/check_update", context=ctx, timeout=5)
            data = json.loads(response.read().decode('utf-8'))
            print(f"收到更新信息: {data}")
            
            server_version = tuple(data.get('version', (1, 8, 12)))
            latest_version = server_version
            update_message = data.get('message', '')
            download_url = data.get('download_url', '')
            
            # 比较版本号
            update_available = False
            for i in range(min(len(current_version), len(server_version))):
                if server_version[i] > current_version[i]:
                    update_available = True
                    break
                elif server_version[i] < current_version[i]:
                    break
            
            if update_available:
                print(f"发现新版本: {'.'.join(map(str, latest_version))}")
            else:
                print("当前已是最新版本")
                
        except urllib.error.URLError as e:
            print(f"无法连接到更新服务器: {str(e)}")
        except json.JSONDecodeError as e:
            print(f"解析服务器响应失败: {str(e)}")
        except Exception as e:
            print(f"检查更新时出错: {str(e)}")
    
    # 启动后台线程
    update_thread = threading.Thread(target=background_check)
    update_thread.daemon = True
    update_thread.start()

# 下载并安装更新
def download_and_install_update():

    global download_url

    if hasattr(bpy.app, "online_access") and not bpy.app.online_access:
        return {'CANCELLED'}, "Blender 已禁用在线访问，无法下载更新"
    
    if not download_url:
        return {'CANCELLED'}, "无法获取下载链接"
    
    try:
        # 创建临时目录下载更新
        temp_dir = tempfile.mkdtemp()
        temp_file = os.path.join(temp_dir, "update.py")
        
        # 禁用SSL证书验证（仅用于测试环境）
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        # 下载更新文件
        print(f"正在下载更新: {download_url}")
        opener = urllib.request.build_opener()
        opener.addheaders = [('User-agent', f'Blender/{bpy.app.version_string} FBXAnimImporter/{".".join(map(str, ADDON_INFO["version"]))}')]
        urllib.request.install_opener(opener)
        urllib.request.urlretrieve(download_url, temp_file)
        
        # 检查下载的文件
        if os.path.getsize(temp_file) == 0:
            raise ValueError("下载的文件为空")
            
        # 验证下载的文件是否是有效的Python脚本
        with open(temp_file, 'r', encoding='utf-8') as f:
            content = f.read()
            if not "bl_info" in content or not "register" in content:
                raise ValueError("下载的文件不是有效的Blender插件")
        
        # 获取当前脚本路径
        current_file = os.path.abspath(__file__)
        print(f"当前插件路径: {current_file}")
        
        # 备份当前文件
        backup_file = current_file + ".bak"
        shutil.copy2(current_file, backup_file)
        print(f"已备份原文件至: {backup_file}")
        
        # 替换当前文件
        shutil.copy2(temp_file, current_file)
        print(f"已更新插件文件: {current_file}")
        
        # 清理临时文件
        shutil.rmtree(temp_dir)
        
        # 强制重新加载当前文件
        try:
            bpy.ops.script.reload()
            print("尝试重新加载脚本")
        except:
            pass
        
        return {'FINISHED'}, "更新已下载，请重启Blender以应用更新。重启前请先保存您的工作！"
    except urllib.error.URLError as e:
        return {'CANCELLED'}, f"下载失败: 无法连接到服务器 ({str(e)})"
    except PermissionError:
        return {'CANCELLED'}, "更新失败: 无法写入文件，权限不足"
    except ValueError as e:
        return {'CANCELLED'}, f"更新失败: {str(e)}"
    except Exception as e:
        # 如果出现异常，尝试恢复备份
        try:
            backup_file = os.path.abspath(__file__) + ".bak"
            if os.path.exists(backup_file):
                shutil.copy2(backup_file, os.path.abspath(__file__))
                print("发生错误，已从备份恢复")
        except:
            pass
        return {'CANCELLED'}, f"更新失败: {str(e)}"

class ANIM_OT_CheckForUpdates(bpy.types.Operator):
    bl_idname = "anim.check_for_updates"
    bl_label = "检查更新"
    bl_description = "检查插件更新"
    
    def execute(self, context):
        check_for_updates(auto_check=False)
        self.report({'INFO'}, "更新检查已在后台启动，稍后将显示结果")
        return {'FINISHED'}

class ANIM_OT_InstallUpdate(bpy.types.Operator):
    bl_idname = "anim.install_update"
    bl_label = "安装更新"
    bl_description = "下载并安装插件更新"
    
    def execute(self, context):
        result, message = download_and_install_update()
        self.report({'INFO'}, message)
        return result

class ANIM_PT_UpdatePanel(bpy.types.Panel):
    bl_label = "更新与信息"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "动画工具"
    
    @classmethod
    def poll(cls, context):
        return context.scene.anim_merge_props.active_panel == 'UPDATE'
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.anim_merge_props
        
        # 当前版本
        version_str = '.'.join(map(str, ADDON_INFO['version']))
        box = layout.box()
        box.label(text=f"当前版本: {version_str}", icon='BLENDER')
        box.prop(props, "auto_check_update", icon='URL')
        
        # 更新状态
        if update_available and latest_version:
            latest_ver_str = '.'.join(map(str, latest_version))
            update_box = layout.box()
            update_box.alert = True
            update_box.label(text=f"发现新版本: {latest_ver_str}", icon='FILE_TICK')
            
            if update_message:
                message_box = update_box.box()
                message_box.scale_y = 0.7
                message_box.label(text="更新说明:")
                for line in update_message.split('\n'):
                    message_box.label(text=line)
            
            update_row = update_box.row(align=True)
            update_row.scale_y = 1.5
            update_row.operator("anim.install_update", text="下载并安装更新", icon='IMPORT')
        else:
            layout.label(text="当前已是最新版本" if last_update_check > 0 else "尚未检查更新")
        
        # 手动检查按钮
        check_row = layout.row(align=True)
        check_row.scale_y = 1.2
        check_row.operator("anim.check_for_updates", text="手动检查更新", icon='FILE_REFRESH')
        
        # 上次检查时间
        if last_update_check > 0:
            time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(last_update_check))
            layout.label(text=f"上次检查: {time_str}", icon='TIME')
            
        # 关于信息
        about_box = layout.box()
        about_box.label(text="关于插件", icon='HELP')
        about_box.label(text=f"作者: {ADDON_INFO['author']}")
        about_box.label(text=f"适用于Blender {ADDON_INFO['blender'][0]}.{ADDON_INFO['blender'][1]}.{ADDON_INFO['blender'][2]}+")
        about_box.label(text=ADDON_INFO['description'])
