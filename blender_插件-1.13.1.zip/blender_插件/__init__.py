bl_info = {
    "name": "动画助手",
    "author": "ΔIng KMnO4",
    "version": (1, 13, 1),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > 动画工具",
    "description": "AMI 动画工作流工具，支持动作库、动画合并、骨骼映射、路径/呼吸/摄像机动画。",
    "warning": "",
    "doc_url": "",
    "category": "Animation",
}

from .core_base import *
from .ops_merge_library import *
from .ops_bone_tools import *
from .ops_orientation_library import *
from .ui_update import *
from .path_animation import *
from .breath_animation import *
from .camera_animation import *

# Track startup update timer registration in package scope.
_startup_timer_registered = False


@bpy.app.handlers.persistent
def _on_blend_load(_dummy):
    # 每次打开工程后，统一从磁盘刷新动作库，避免项目间状态串扰
    try:
        load_library_actions()
    except Exception as e:
        print(f"加载工程后刷新动作库失败: {e}")


classes = (
    ActionLibraryItem,
    BoneSelectionItem,
    AnimMergeProperties,
    ANIM_OT_ImportToLibrary,
    ANIM_OT_UseLibraryAction,
    ANIM_OT_UseLibraryActionWithBones,
    ANIM_OT_MergeFBX,
    ANIM_OT_ExecuteMergeFromSource,
    ANIM_OT_MergeFBXWithBones,
    ANIM_OT_SaveCustomAction,
    ANIM_OT_SelectBones,
    ANIM_OT_SelectAllBones,
    ANIM_OT_ExportAction,
    ANIM_OT_ImportActionFromJSON,
    ANIM_OT_CheckForUpdates,
    ANIM_OT_InstallUpdate,
    ANIM_OT_ListFBXBones,
    ANIM_OT_ShowBonesDialog,
    ANIM_OT_CopyBoneName,
    ANIM_OT_SearchBone,
    ANIM_OT_SelectBoneItem,
    ANIM_OT_SelectSearchedBone,
    ANIM_OT_ConfirmBoneSelection,
    ANIM_OT_ReloadBoneMapping,
    ANIM_OT_AutoBoneMapping,
    ANIM_OT_ApplyProgressiveOffset,
    ANIM_OT_ApplyFixedOrientation,
    ANIM_OT_RenameLibraryAction,
    ANIM_OT_DeleteLibraryAction,
    ANIM_OT_CreateLibraryFolder,
    ANIM_OT_DeleteLibraryFolder,
    ANIM_UL_ActionLibrary,
    ANIM_PT_ActionLibrary,
    ANIM_PT_MergeControl,
    ANIM_PT_UpdatePanel,
    PathAnimationProperties,
    ANIM_OT_CreateBezierPath,
    ANIM_OT_SetPathTarget,
    ANIM_OT_ApplyPathAnimation,
    ANIM_OT_ApplyControlPoints,
    ANIM_PT_PathAnimation,
    BreathAnimationProperties,
    ANIM_OT_ApplyBreathAnimation,
    ANIM_PT_BreathAnimation,
    CameraAnimationProperties,
    ANIM_OT_ApplyCameraShake,
    ANIM_OT_ApplyCameraTracking,
    ANIM_PT_CameraAnimation,
    ANIM_PT_MainPanel,
)


def register():
    bpy.utils.register_class(ActionLibraryItem)
    bpy.utils.register_class(BoneSelectionItem)

    bpy.utils.register_class(AnimMergeProperties)
    bpy.utils.register_class(PathAnimationProperties)
    bpy.utils.register_class(BreathAnimationProperties)
    bpy.utils.register_class(CameraAnimationProperties)

    for cls in classes:
        if cls in [
            ActionLibraryItem,
            BoneSelectionItem,
            AnimMergeProperties,
            PathAnimationProperties,
            BreathAnimationProperties,
            CameraAnimationProperties,
        ]:
            continue
        try:
            bpy.utils.register_class(cls)
        except ValueError as e:
            print(f"注册类时出错 {cls.__name__}: {e}")

    bpy.types.Scene.anim_merge_props = bpy.props.PointerProperty(type=AnimMergeProperties)
    bpy.types.Scene.bone_selection = bpy.props.CollectionProperty(type=BoneSelectionItem, options={'SKIP_SAVE'})
    bpy.types.Scene.path_anim_props = bpy.props.PointerProperty(type=PathAnimationProperties)
    bpy.types.Scene.breath_anim_props = bpy.props.PointerProperty(type=BreathAnimationProperties)
    bpy.types.Scene.camera_anim_props = bpy.props.PointerProperty(type=CameraAnimationProperties)

    # 启用插件后立即同步一次动作库，避免列表残留旧缓存
    try:
        load_library_actions()
    except Exception as e:
        print(f"启动时刷新动作库失败: {e}")

    if _on_blend_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_blend_load)

    if not bpy.app.timers.is_registered(load_library_actions):
        bpy.app.timers.register(load_library_actions, first_interval=1.0)

    global _startup_timer_registered
    if not _startup_timer_registered:

        def check_updates_on_startup():
            scene = getattr(bpy.context, "scene", None)
            if scene is None or not hasattr(scene, "anim_merge_props"):
                return 1.0

            if hasattr(bpy.app, "online_access") and not bpy.app.online_access:
                print("Blender 已禁用在线访问，跳过自动检查更新。")
                return None

            if scene.anim_merge_props.auto_check_update:
                check_for_updates(auto_check=True)
            return None

        bpy.app.timers.register(check_updates_on_startup, first_interval=3.0)
        _startup_timer_registered = True


def unregister():
    try:
        if hasattr(bpy.types.Scene, "camera_anim_props"):
            del bpy.types.Scene.camera_anim_props
    except AttributeError:
        pass
    try:
        if hasattr(bpy.types.Scene, "breath_anim_props"):
            del bpy.types.Scene.breath_anim_props
    except AttributeError:
        pass
    try:
        if hasattr(bpy.types.Scene, "path_anim_props"):
            del bpy.types.Scene.path_anim_props
    except AttributeError:
        pass
    try:
        if hasattr(bpy.types.Scene, "bone_selection"):
            del bpy.types.Scene.bone_selection
    except AttributeError:
        pass
    try:
        if hasattr(bpy.types.Scene, "anim_merge_props"):
            del bpy.types.Scene.anim_merge_props
    except AttributeError:
        pass

    for cls in reversed(classes):
        if cls in [
            ActionLibraryItem,
            BoneSelectionItem,
            AnimMergeProperties,
            PathAnimationProperties,
            BreathAnimationProperties,
            CameraAnimationProperties,
        ]:
            continue
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            print(f"无法卸载类 {cls.__name__}, 可能已被卸载")

    try:
        bpy.utils.unregister_class(CameraAnimationProperties)
        bpy.utils.unregister_class(BreathAnimationProperties)
        bpy.utils.unregister_class(PathAnimationProperties)
        bpy.utils.unregister_class(AnimMergeProperties)

        bpy.utils.unregister_class(BoneSelectionItem)
        bpy.utils.unregister_class(ActionLibraryItem)
    except RuntimeError as e:
        print(f"卸载属性类型类时出错: {e}")

    if bpy.app.timers.is_registered(load_library_actions):
        bpy.app.timers.unregister(load_library_actions)

    try:
        if _on_blend_load in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(_on_blend_load)
    except Exception:
        pass

    global _startup_timer_registered
    _startup_timer_registered = False


if __name__ == "__main__":
    register()
