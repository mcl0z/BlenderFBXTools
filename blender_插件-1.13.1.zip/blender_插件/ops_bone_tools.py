from .core_base import *

# Bone inspection, search and auto-mapping operators.
class ANIM_OT_ListFBXBones(bpy.types.Operator):

    bl_idname = "anim.list_fbx_bones"
    bl_label = "获取FBX骨骼列表"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.anim_merge_props
        
        # 如果使用库文件
        if props.is_from_library:
            if not props.action_library_items:
                self.report({'ERROR'}, "未选择动作库中的动作")
                return {'CANCELLED'}
            item = props.action_library_items[props.action_library_index]
            filepath = Path(item.filepath)
            
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    action_data = json.load(f)
                
                # 提取骨骼名称
                bone_names = set()
                for fcurve in action_data.get('fcurves', []):
                    data_path = fcurve.get('data_path', '')
                    match = re.search(r'pose\.bones\["([^"]+)"\]', data_path)
                    if match:
                        bone_names.add(match.group(1))
                
                if not bone_names:
                    self.report({'INFO'}, "未找到骨骼，可能是物体级别的动画")
                    return {'CANCELLED'}
                
                # 保存骨骼列表
                context.scene['fbx_bones'] = list(bone_names)
                
                # 向用户报告
                self.report({'INFO'}, f"已找到 {len(bone_names)} 个骨骼")
                
                # 显示骨骼列表的对话框
                bpy.ops.anim.show_bones_dialog('INVOKE_DEFAULT')
                return {'FINISHED'}
            except Exception as e:
                self.report({'ERROR'}, f"读取动作文件失败: {str(e)}")
                return {'CANCELLED'}
        
        # 如果使用FBX文件
        else:
            if not props.filepath:
                self.report({'ERROR'}, "未选择FBX文件")
                return {'CANCELLED'}
            
            # 临时导入FBX以获取骨骼列表
            original_objects = set(bpy.context.scene.objects)
            try:
                bpy.ops.import_scene.fbx(
                    filepath=props.filepath,
                    use_anim=True,
                    automatic_bone_orientation=True,
                    ignore_leaf_bones=True
                )
            except Exception as e:
                self.report({'ERROR'}, f"FBX导入失败: {str(e)}")
                return {'CANCELLED'}
            
            # 找出新导入的物体
            new_objects = set(bpy.context.scene.objects) - original_objects
            armatures = [obj for obj in new_objects if obj.type == 'ARMATURE']
            
            if not armatures:
                # 清理导入的物体
                for obj in new_objects:
                    bpy.data.objects.remove(obj, do_unlink=True)
                self.report({'ERROR'}, "FBX文件中没有骨架")
                return {'CANCELLED'}
            
            # 第一个骨架
            armature = armatures[0]
            
            # 获取骨骼名称
            bone_names = [bone.name for bone in armature.data.bones]
            
            # 保存骨骼列表
            context.scene['fbx_bones'] = bone_names
            
            # 清理导入的物体
            for obj in new_objects:
                bpy.data.objects.remove(obj, do_unlink=True)
            
            # 向用户报告
            self.report({'INFO'}, f"已找到 {len(bone_names)} 个骨骼")
            
            # 显示骨骼列表的对话框
            bpy.ops.anim.show_bones_dialog('INVOKE_DEFAULT')
            return {'FINISHED'}

class ANIM_OT_ShowBonesDialog(bpy.types.Operator):

    bl_idname = "anim.show_bones_dialog"
    bl_label = "FBX骨骼列表"
    bl_options = {'REGISTER', 'UNDO'}
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="FBX文件中的骨骼:", icon='BONE_DATA')
        
        # 获取骨骼列表
        bone_names = context.scene.get('fbx_bones', [])
        
        if bone_names:
            box = layout.box()
            col = box.column(align=True)
            
            for bone_name in sorted(bone_names):
                row = col.row()
                row.label(text=bone_name)
                copy_op = row.operator("anim.copy_bone_name", text="", icon='COPYDOWN')
                copy_op.bone_name = bone_name
        else:
            layout.label(text="未找到骨骼", icon='ERROR')
        
        # 使用提示
        help_box = layout.box()
        help_box.label(text="使用提示:", icon='INFO')
        help_box.label(text="1. 点击骨骼名称旁的复制按钮")
        help_box.label(text="2. 在骨骼映射界面中粘贴到'映射到'输入框")
        
    def execute(self, context):
        return {'FINISHED'}
        
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=400)

class ANIM_OT_CopyBoneName(bpy.types.Operator):

    bl_idname = "anim.copy_bone_name"
    bl_label = "复制骨骼名称"
    
    bone_name: bpy.props.StringProperty()
    
    def execute(self, context):
        context.window_manager.clipboard = self.bone_name
        self.report({'INFO'}, f"已复制: {self.bone_name}")
        return {'FINISHED'}

class ANIM_OT_SearchBone(bpy.types.Operator):

    bl_idname = "anim.search_bone"
    bl_label = "搜索目标骨骼"
    bl_options = {'REGISTER', 'UNDO'}
    
    # 存储当前编辑的骨骼项索引
    bone_index: bpy.props.IntProperty()
    
    # 搜索文本
    bone_search_text: bpy.props.StringProperty(
        name="搜索",
        description="输入骨骼名称进行搜索",
        update=lambda self, context: self.update_search(context)
    )
    
    # 当前选中的骨骼
    selected_bone: bpy.props.StringProperty(default="")
    
    def update_search(self, context):

        self.selected_bone = ""
    
    def get_bone_items(self, context):

        items = []
        
        # 获取当前骨架
        active_obj = context.active_object
        if active_obj and active_obj.type == 'ARMATURE':
            # 获取搜索文本
            search_text = self.bone_search_text.lower()
            
            # 搜索所有匹配的骨骼
            bone_names = []
            for bone in active_obj.data.bones:
                if search_text in bone.name.lower():
                    bone_names.append(bone.name)
            
            # 按字母排序
            bone_names.sort()
            
            # 转换为选项列表
            for name in bone_names:
                items.append((name, name, f"选择 {name}"))
        
        # 如果没有匹配的骨骼，添加一个提示
        if not items:
            items.append(("", "没有匹配的骨骼", ""))
            
        return items
    
    bone_list: bpy.props.EnumProperty(
        name="匹配骨骼",
        description="符合搜索条件的骨骼列表",
        items=get_bone_items
    )
    
    def execute(self, context):
        if self.selected_bone:
            # 将选中的骨骼名称应用到目标映射字段
            if self.bone_index < len(context.scene.bone_selection):
                item = context.scene.bone_selection[self.bone_index]
                item.mapped_to = self.selected_bone
                self.report({'INFO'}, f"已将骨骼 '{item.name}' 映射到 '{self.selected_bone}'")
                return {'FINISHED'}
        return {'CANCELLED'}
    
    def invoke(self, context, event):
        # 清空搜索文本和选择
        self.bone_search_text = ""
        self.selected_bone = ""
        return context.window_manager.invoke_props_dialog(self, width=300)
    
    def draw(self, context):
        layout = self.layout
        
        # 搜索框
        search_row = layout.row()
        search_row.prop(self, "bone_search_text", icon='VIEWZOOM')
        
        # 获取匹配的骨骼数量
        matched_bones = 0
        active_obj = context.active_object
        if active_obj and active_obj.type == 'ARMATURE':
            search_text = self.bone_search_text.lower()
            for bone in active_obj.data.bones:
                if search_text in bone.name.lower():
                    matched_bones += 1
        
        # 显示匹配信息
        if matched_bones > 0:
            layout.label(text=f"找到 {matched_bones} 个匹配骨骼")
        else:
            layout.label(text="没有找到匹配的骨骼", icon='ERROR')
        
        # 骨骼列表
        box = layout.box()
        col = box.column()
        
        # 显示匹配的骨骼
        active_obj = context.active_object
        if active_obj and active_obj.type == 'ARMATURE':
            search_text = self.bone_search_text.lower()
            
            # 获取并排序匹配的骨骼
            matching_bones = []
            for bone in active_obj.data.bones:
                if search_text in bone.name.lower():
                    matching_bones.append(bone.name)
            
            matching_bones.sort()
            
            # 显示骨骼按钮
            for bone_name in matching_bones:
                row = col.row()
                op = row.operator("anim.select_searched_bone", text=bone_name)
                op.bone_name = bone_name
                op.bone_index = self.bone_index
        
        # 显示当前选中的骨骼
        if self.selected_bone:
            selected_row = layout.row()
            selected_row.label(text=f"已选择: {self.selected_bone}", icon='CHECKMARK')

class ANIM_OT_SelectBoneItem(bpy.types.Operator):

    bl_idname = "anim.select_bone_item"
    bl_label = "选择骨骼项"
    
    bone_name: bpy.props.StringProperty()
    
    def execute(self, context):
        # 直接设置搜索操作符的selected_bone值
        wm = context.window_manager
        
        # 通过标签找到我们的搜索操作符
        for op in wm.operators:
            if op.bl_idname == "ANIM_OT_SearchBone":
                op.selected_bone = self.bone_name
                self.report({'INFO'}, f"已选择: {self.bone_name}")
                return {'FINISHED'}
        
        # 如果找不到操作符，则更新骨骼映射操作符的属性
        if hasattr(context, 'active_operator') and hasattr(context.active_operator, 'selected_bone'):
            context.active_operator.selected_bone = self.bone_name
        
        return {'FINISHED'}

class ANIM_OT_ConfirmBoneSelection(bpy.types.Operator):

    bl_idname = "anim.confirm_bone_selection"
    bl_label = "确认骨骼选择"
    
    bone_name: bpy.props.StringProperty()
    bone_index: bpy.props.IntProperty()
    
    def execute(self, context):
        if self.bone_name and self.bone_index < len(context.scene.bone_selection):
            item = context.scene.bone_selection[self.bone_index]
            item.mapped_to = self.bone_name
            self.report({'INFO'}, f"已将骨骼 '{item.name}' 映射到 '{self.bone_name}'")
        return {'FINISHED'}

# 添加一个新的操作符用于选择搜索到的骨骼
class ANIM_OT_SelectSearchedBone(bpy.types.Operator):

    bl_idname = "anim.select_searched_bone"
    bl_label = "选择搜索到的骨骼"
    
    bone_name: bpy.props.StringProperty()
    bone_index: bpy.props.IntProperty()
    
    def execute(self, context):
        # 直接应用映射，不需要经过其他操作符
        if self.bone_index < len(context.scene.bone_selection):
            item = context.scene.bone_selection[self.bone_index]
            item.mapped_to = self.bone_name
            self.report({'INFO'}, f"已将骨骼 '{item.name}' 映射到 '{self.bone_name}'")
            
            # 关闭对话框
            return {'FINISHED'}
        
        return {'CANCELLED'}

# 计算字符串的相似度得分
def string_similarity(s1, s2):

    # 转为小写进行比较
    s1, s2 = s1.lower(), s2.lower()
    
    # 完全匹配
    if s1 == s2:
        return 1.0
    
    # 去除常见的前缀和后缀再比较
    prefixes = ['bone_', 'b_', 'bone.', 'bones.']
    suffixes = ['.l', '.r', '_l', '_r', '_left', '_right', '.left', '.right']
    
    s1_clean = s1
    s2_clean = s2
    
    # 处理前缀
    for prefix in prefixes:
        if s1.startswith(prefix):
            s1_clean = s1[len(prefix):]
        if s2.startswith(prefix):
            s2_clean = s2[len(prefix):]
    
    # 处理后缀
    for suffix in suffixes:
        if s1_clean.endswith(suffix):
            s1_clean = s1_clean[:-len(suffix)]
        if s2_clean.endswith(suffix):
            s2_clean = s2_clean[:-len(suffix)]
    
    # 如果清洗后完全匹配
    if s1_clean == s2_clean:
        return 0.9  # 给一个较高但不是完全匹配的分数
    
    # 如果一个是另一个的子串
    if s1_clean in s2_clean or s2_clean in s1_clean:
        return 0.8
    
    # 计算编辑距离
    len_s1, len_s2 = len(s1_clean), len(s2_clean)
    if len_s1 == 0 or len_s2 == 0:
        return 0.0
        
    # 莱文斯坦距离简化版本
    distance = 0
    for i, c1 in enumerate(s1_clean):
        if i < len_s2 and c1 == s2_clean[i]:
            continue
        distance += 1
    
    # 归一化距离
    similarity = 1.0 - (distance / max(len_s1, len_s2))
    return max(0.0, similarity)

# 获取FBX骨骼位置信息
def get_fbx_bone_positions(filepath):

    positions = {}
    
    # 临时导入FBX
    original_objects = set(bpy.context.scene.objects)
    try:
        bpy.ops.import_scene.fbx(
            filepath=filepath,
            use_anim=True,
            automatic_bone_orientation=True,
            ignore_leaf_bones=True
        )
        
        # 找出新导入的物体
        new_objects = set(bpy.context.scene.objects) - original_objects
        armatures = [obj for obj in new_objects if obj.type == 'ARMATURE']
        
        if armatures:
            # 使用第一个骨架
            armature = armatures[0]
            
            # 获取每个骨骼的全局位置
            for bone in armature.data.bones:
                # 获取骨骼头部的全局坐标
                head_pos = armature.matrix_world @ bone.head_local
                positions[bone.name] = {
                    'head': head_pos.copy(),
                    'parent': bone.parent.name if bone.parent else None
                }
        
        # 清理导入的物体
        for obj in new_objects:
            bpy.data.objects.remove(obj, do_unlink=True)
            
    except Exception as e:
        print(f"获取FBX骨骼位置失败: {str(e)}")
    
    return positions

# 从JSON文件中获取骨骼信息 
def get_json_bone_names(filepath):

    bone_names = set()
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            action_data = json.load(f)
        
        # 提取骨骼名称
        for fcurve in action_data.get('fcurves', []):
            data_path = fcurve.get('data_path', '')
            match = re.search(r'pose\.bones\["([^"]+)"\]', data_path)
            if match:
                bone_names.add(match.group(1))
                
    except Exception as e:
        print(f"从JSON获取骨骼名称失败: {str(e)}")
    
    return bone_names

# 自动预测骨骼映射
def predict_bone_mapping(context, source_bones, target_armature):

    if not source_bones or not target_armature:
        return {}
    
    # 获取目标骨架的所有骨骼
    target_bones = [bone.name for bone in target_armature.data.bones]
    
    # 创建映射
    mapping = {}
    
    # 首先基于名称进行精确匹配
    for source_bone in source_bones:
        if source_bone in target_bones:
            mapping[source_bone] = source_bone
            
    # 然后基于名称相似度匹配剩余的骨骼
    unmapped_sources = [b for b in source_bones if b not in mapping]
    
    for source_bone in unmapped_sources:
        best_match = None
        best_score = 0.5  # 设置阈值，避免不相关的匹配
        
        for target_bone in target_bones:
            # 计算相似度
            similarity = string_similarity(source_bone, target_bone)
            
            if similarity > best_score:
                best_score = similarity
                best_match = target_bone
        
        if best_match:
            mapping[source_bone] = best_match
    
    # 对于特定的左右对称骨骼进行特殊处理
    for source_bone in unmapped_sources:
        if source_bone not in mapping:
            # 处理左侧和右侧的命名规则
            if any(suffix in source_bone.lower() for suffix in ['left', '_l', '.l']):
                # 寻找可能的右侧对应骨骼
                source_right = source_bone.lower().replace('left', 'right').replace('_l', '_r').replace('.l', '.r')
                if source_right in mapping:
                    # 如果右侧有映射，尝试将左侧匹配到相应的左侧骨骼
                    right_target = mapping[source_right]
                    left_target = right_target.lower().replace('right', 'left').replace('_r', '_l').replace('.r', '.l')
                    # 确认左侧目标骨骼存在
                    if left_target in target_bones:
                        mapping[source_bone] = left_target
    
    return mapping

# 添加用于自动骨骼映射的操作符
class ANIM_OT_AutoBoneMapping(bpy.types.Operator):

    bl_idname = "anim.auto_bone_mapping"
    bl_label = "自动骨骼映射"
    bl_options = {'REGISTER', 'UNDO'}
    
    match_threshold: bpy.props.FloatProperty(
        name="匹配阈值",
        description="骨骼名称相似度匹配的阈值",
        default=0.6,
        min=0.1,
        max=1.0
    )
    
    def execute(self, context):
        props = context.scene.anim_merge_props
        target_armature = context.active_object
        
        if not target_armature or target_armature.type != 'ARMATURE':
            self.report({'ERROR'}, "请先选择目标骨架")
            return {'CANCELLED'}
        
        source_bones = []
        
        # 从骨骼选择列表中获取源骨骼
        for item in context.scene.bone_selection:
            if item.selected:
                source_bones.append(item.name)
        
        if not source_bones:
            self.report({'ERROR'}, "没有选择任何源骨骼")
            return {'CANCELLED'}
        
        # 预测骨骼映射
        mapping = predict_bone_mapping(context, source_bones, target_armature)
        
        if not mapping:
            self.report({'WARNING'}, "无法预测任何骨骼映射关系")
            return {'CANCELLED'}
        
        # 将预测的映射应用到骨骼选择列表
        count = 0
        for item in context.scene.bone_selection:
            if item.name in mapping and item.selected:
                item.mapped_to = mapping[item.name]
                item.use_mapping = True
                count += 1
        
        self.report({'INFO'}, f"成功预测并应用了 {count} 个骨骼映射")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "match_threshold")
        layout.label(text="这将根据骨骼名称相似度自动预测映射关系", icon='INFO')

# Operator for applying progressive offset
