# Addon Module Layout

This addon was split from a monolithic single file into focused modules.
All source files are kept under 1000 lines for easier maintenance.

## Files

- `__init__.py`
  - Package entrypoint
  - Class registration and unregistration
- `core_base.py`
  - Shared imports/constants
  - Property groups
  - Core animation serialization/merge helpers
  - Bone mapping reload logic
  - `load_library_actions`
- `ops_merge_library.py`
  - Library import/export/save operators
  - FBX merge operators
  - Action list UI list class
- `ops_bone_tools.py`
  - Bone listing/search/selection operators
  - Auto mapping and helper utilities
- `ops_orientation_library.py`
  - Progressive offset/fixed orientation operators
  - Library delete/create folder operators
- `ui_update.py`
  - Main panel and merge/library/update panels
  - Update check/download workflow
- `path_animation.py`
  - Path animation operators and panel
- `breath_animation.py`
  - Breath animation property/operator/panel
- `camera_animation.py`
  - Camera animation property/operators/panel

## Packaging

Use project-level script:

```bash
python3 build_addon_zip.py
```

This creates a Blender-installable ZIP under `dist/`.

Build a single-file addon (merge all module `.py` into one file):

```bash
python3 build_singlefile_addon.py
```

Default output:

```text
dist/blender_插件_singlefile.py
```
