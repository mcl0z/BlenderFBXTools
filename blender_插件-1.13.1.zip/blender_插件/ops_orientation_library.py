from .core_base import *


def _refresh_library_view(context, target_filepath=None, target_name=None):
    load_library_actions()
    props = context.scene.anim_merge_props
    props.show_library = True
    props.active_panel = 'LIBRARY'

    items = props.action_library_items
    if not items:
        props.action_library_index = 0
        return

    target_idx = None
    target_path_str = str(target_filepath) if target_filepath else None
    if target_path_str:
        for i, it in enumerate(items):
            if it.filepath == target_path_str:
                target_idx = i
                break
    if target_idx is None and target_name:
        for i, it in enumerate(items):
            if it.name == target_name:
                target_idx = i
                break
    if target_idx is None:
        target_idx = min(props.action_library_index, len(items) - 1)
    props.action_library_index = max(0, target_idx)


# Post-processing and library folder management operators.
class ANIM_OT_ApplyProgressiveOffset(bpy.types.Operator):

    bl_idname = "anim.apply_progressive_offset"
    bl_label = "应用渐进位移"
    bl_options = {'REGISTER', 'UNDO'}

    start_frame: bpy.props.IntProperty(
        name="起始帧",
        description="应用偏移的起始帧",
        default=1,
        min=0
    )
    end_frame: bpy.props.IntProperty(
        name="结束帧",
        description="应用偏移的结束帧",
        default=100,
        min=1
    )
    offset_per_frame: bpy.props.FloatProperty(
        name="每帧偏移量",
        description="在朝向方向上，每帧增加的位移量",
        default=0.01,
        unit='LENGTH'
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'ARMATURE' and obj.animation_data and obj.animation_data.action

    def invoke(self, context, event):
        action = context.active_object.animation_data.action
        # Try to guess a reasonable default range from the action
        if action and action.frame_range and action.frame_range[1] > action.frame_range[0]:
            self.start_frame = int(action.frame_range[0])
            self.end_frame = int(action.frame_range[1])
        else:
             # Fallback if no action or invalid range
             self.start_frame = context.scene.frame_start
             self.end_frame = context.scene.frame_end

        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        armature = context.active_object
        action = armature.animation_data.action

        if not action:
            self.report({'ERROR'}, "目标骨架没有活动Action")
            return {'CANCELLED'}

        start_frame = self.start_frame
        end_frame = self.end_frame
        offset_per_frame = self.offset_per_frame

        if start_frame >= end_frame:
            self.report({'ERROR'}, "起始帧必须小于结束帧")
            return {'CANCELLED'}

        # --- Determine Forward Vector at the *Action's* Start Frame ---
        current_frame = context.scene.frame_current
        # Determine the frame to use for orientation (Action start or frame 1)
        orientation_frame = int(action.frame_range[0]) if action and action.frame_range and action.frame_range[0] is not None else 1

        forward_vector = mathutils.Vector((0.0, 1.0, 0.0)) # Default to world Y
        try:
            print(f"Attempting to set frame to {orientation_frame} for orientation calculation.")
            # Set frame specifically to get the initial orientation
            context.scene.frame_set(orientation_frame)
            context.view_layer.update() # Ensure scene updates for matrix

            world_matrix = armature.matrix_world.copy()
            # Assuming Local +Y is the forward direction for objects in Blender
            forward_vector_candidate = world_matrix.col[1].xyz
            # Check if the vector has non-zero length before normalizing
            if forward_vector_candidate.length_squared > 0.000001: # Use length_squared for efficiency
                 forward_vector = forward_vector_candidate.normalized()
            else:
                 # This might happen if scale is zero or object is perfectly aligned in a weird way
                 self.report({'WARNING'}, "无法确定骨架朝向 (可能缩放为0?), 使用世界+Y轴代替")
                 # Keep the default world Y vector

            # Update print statement to reflect which frame was used
            print(f"Orientation from Frame {orientation_frame}: Forward Vector = {format_vector(forward_vector)}")

        except Exception as e:
             self.report({'ERROR'}, f"获取帧 {orientation_frame} 状态时出错: {e}")
             # Restore frame before returning
             context.scene.frame_set(current_frame)
             context.view_layer.update()
             return {'CANCELLED'}
        finally:
            # Always restore original frame
            context.scene.frame_set(current_frame)
            context.view_layer.update()

        # --- Find Location F-Curves for the Armature Object ---
        # We target the object's location curves by default
        loc_fcurves = {
            fc.array_index: fc
            for fc in action.fcurves
            if fc.data_path == 'location'
        }

        if len(loc_fcurves) != 3:
            self.report({'ERROR'}, "未找到完整的对象位置 F-Curves (X, Y, Z)。此功能当前仅支持修改对象本身的位移动画。")
            # Future improvement: Add option to target a specific root bone's location
            return {'CANCELLED'}

        # --- Collect Keyframes in Range ---
        # Stores data for frames that have at least one location keyframe within the range
        # {frame_int: {'kp': [kp_x, kp_y, kp_z], 'original_value': [x, y, z]}}
        keyframes_to_modify = {}
        min_frame_in_range = float('inf')
        max_frame_in_range = float('-inf')

        for axis_index, fcurve in loc_fcurves.items():
            if not fcurve.keyframe_points:
                 continue # Skip curves with no keyframes

            for kp in fcurve.keyframe_points:
                # Use the keyframe's actual frame number (float) for range check
                # but group by rounded integer frame for processing
                if start_frame <= kp.co.x <= end_frame:
                    frame_int = int(round(kp.co.x))
                    min_frame_in_range = min(min_frame_in_range, frame_int)
                    max_frame_in_range = max(max_frame_in_range, frame_int)

                    if frame_int not in keyframes_to_modify:
                        # Initialize structure for this frame
                        keyframes_to_modify[frame_int] = {
                            'kp': [None, None, None],
                            'original_value': [None, None, None] # Use None to detect missing keys later
                        }

                    # Store the keyframe point object itself
                    keyframes_to_modify[frame_int]['kp'][axis_index] = kp
                    # Store the original value directly from the keyframe point
                    keyframes_to_modify[frame_int]['original_value'][axis_index] = kp.co.y

        # --- Apply Progressive Offset ---
        sorted_frames = sorted(keyframes_to_modify.keys())

        if not sorted_frames:
             self.report({'INFO'}, f"在指定的帧范围 [{start_frame}-{end_frame}] 内未找到对象位置关键帧。")
             return {'FINISHED'} # No work to do, but not an error

        # Use the first actual keyframe *found within the user-specified range* as the zero point for progress calculation.
        # This ensures the offset starts correctly even if the user range doesn't start at the very first keyframe.
        actual_start_frame_for_offset = min_frame_in_range
        modified_count = 0

        print(f"Processing {len(sorted_frames)} frames with keyframes between {min_frame_in_range} and {max_frame_in_range}.")
        print(f"Using frame {actual_start_frame_for_offset} as baseline for progressive offset.")

        for frame_int in sorted_frames:
            data = keyframes_to_modify[frame_int]

            # Check if we have keyframes and original values for all 3 axes at this frame
            if any(kp is None for kp in data['kp']) or any(val is None for val in data['original_value']):
                print(f"Skipping frame {frame_int}: Missing keyframe or original value on one or more axes.")
                # Find which axis is missing for better debugging
                missing_axes = [i for i, kp in enumerate(data['kp']) if kp is None]
                print(f"  Missing key points on axes: {missing_axes}")
                missing_vals = [i for i, val in enumerate(data['original_value']) if val is None]
                print(f"  Missing original values on axes: {missing_vals}")
                continue # Skip this frame if data is incomplete

            # Now safe to create the vector
            original_loc = mathutils.Vector(data['original_value'])

            # Calculate progress relative to the first keyframe *found in the range*
            progress = frame_int - actual_start_frame_for_offset
            # Ensure progress is not negative if actual_start_frame_for_offset is somehow greater (shouldn't happen with sorting)
            if progress < 0: progress = 0

            # Calculate the offset vector for this frame
            offset = forward_vector * offset_per_frame * progress

            # Calculate the new location
            new_loc = original_loc + offset

            # Print occasional debug info for verification
            if frame_int == sorted_frames[0] or frame_int == sorted_frames[-1] or frame_int % 20 == 0: # Adjust frequency as needed
                 print(f"  Frame {frame_int}: Progress={progress:.2f}, Offset={format_vector(offset)}, Orig={format_vector(original_loc)}, New={format_vector(new_loc)}")

            # Apply the new location to the keyframe points for X, Y, Z
            key_modified_this_frame = False
            for axis_index in range(3):
                kp = data['kp'][axis_index]
                # Double check kp exists (already checked above, but belt-and-suspenders)
                if kp:
                    # Only update if the value actually changed significantly? Optional.
                    # if abs(kp.co.y - new_loc[axis_index]) > 0.0001:
                    kp.co.y = new_loc[axis_index]
                    key_modified_this_frame = True

            if key_modified_this_frame:
                modified_count += 1 # Count frames where at least one key was updated

        # --- Update Curves ---
        if modified_count > 0:
            print(f"Updating {len(loc_fcurves)} F-curves...")
            for fcurve in loc_fcurves.values():
                try:
                    # This ensures Blender recognizes the changes
                    fcurve.update()
                except Exception as e:
                    # Report error but try to continue updating others
                    print(f"Error updating fcurve {fcurve.data_path}[{fcurve.array_index}]: {e}")
                    self.report({'ERROR'}, f"更新曲线时出错: {e}")

            self.report({'INFO'}, f"已在 {modified_count} 个关键帧上应用渐进位移 (检测范围 {min_frame_in_range}-{max_frame_in_range})")
        else:
            # This case might be hit if offset_per_frame is 0 or keyframes existed but weren't modified
            self.report({'INFO'}, "未修改任何关键帧 (可能范围内无关键帧、偏移量为0或数值无变化)")


        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "start_frame")
        layout.prop(self, "end_frame")
        layout.prop(self, "offset_per_frame")

        info_box = layout.box()
        info_box.label(text="说明:", icon='INFO')
        info_box.label(text="- 此操作会直接修改选中骨架当前Action的对象位置关键帧。")
        info_box.label(text="- 偏移量从指定范围内的第一个关键帧开始，逐帧累加。")
        # Update help text to clarify the orientation source
        info_box.label(text="- 偏移方向基于 Action第一帧 (或帧1) 时骨架对象的局部+Y轴在世界空间中的朝向。")
        info_box.label(text="- 仅处理在指定范围内的现有对象位置关键帧。")
        info_box.label(text="- 请确保在运行前将时间滑块移出修改范围，以避免预览冲突。")


# End of ANIM_OT_ApplyProgressiveOffset class definition

# Operator for applying fixed orientation
class ANIM_OT_ApplyFixedOrientation(bpy.types.Operator):

    bl_idname = "anim.apply_fixed_orientation"
    bl_label = "应用固定朝向"
    bl_options = {'REGISTER', 'UNDO'}

    start_frame: bpy.props.IntProperty(
        name="起始帧",
        description="应用固定朝向的起始帧",
        default=1,
        min=0
    )
    end_frame: bpy.props.IntProperty(
        name="结束帧",
        description="应用固定朝向的结束帧",
        default=100,
        min=1
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'ARMATURE' and obj.animation_data and obj.animation_data.action

    def invoke(self, context, event):
        action = context.active_object.animation_data.action
        # Try to guess a reasonable default range
        if action and action.frame_range and action.frame_range[1] > action.frame_range[0]:
            self.start_frame = int(action.frame_range[0])
            self.end_frame = int(action.frame_range[1])
        else:
            self.start_frame = context.scene.frame_start
            self.end_frame = context.scene.frame_end
        # Ensure start frame is at least 1 if action range is weird
        self.start_frame = max(1, self.start_frame)

        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        armature = context.active_object
        action = armature.animation_data.action

        if not action:
            self.report({'ERROR'}, "目标骨架没有活动Action")
            return {'CANCELLED'}

        start_frame_user = self.start_frame
        end_frame_user = self.end_frame

        if start_frame_user >= end_frame_user:
            self.report({'ERROR'}, "起始帧必须小于结束帧")
            return {'CANCELLED'}

        # --- Determine Orientation at the Action's Start Frame ---
        current_frame = context.scene.frame_current
        orientation_frame = int(action.frame_range[0]) if action and action.frame_range and action.frame_range[0] is not None else 1
        target_world_rotation_quat = None

        try:
            print(f"Attempting to set frame to {orientation_frame} for initial orientation capture.")
            context.scene.frame_set(orientation_frame)
            context.view_layer.update()

            # Capture world rotation as Quaternion
            target_world_rotation_quat = armature.matrix_world.to_quaternion()
            print(f"Captured orientation (Quaternion) from Frame {orientation_frame}: {target_world_rotation_quat}")

        except Exception as e:
            self.report({'ERROR'}, f"获取帧 {orientation_frame} 旋转状态时出错: {e}")
            context.scene.frame_set(current_frame)
            context.view_layer.update()
            return {'CANCELLED'}
        finally:
            # Restore original frame
            context.scene.frame_set(current_frame)
            context.view_layer.update()

        if target_world_rotation_quat is None:
             self.report({'ERROR'}, "未能获取初始旋转")
             return {'CANCELLED'}

        # --- Find Rotation F-Curves (Object Level) ---
        # Determine current rotation mode ONCE
        current_rotation_mode = armature.rotation_mode
        print(f"Armature rotation mode: {current_rotation_mode}")

        rot_fcurves_quat = {
            fc.array_index: fc
            for fc in action.fcurves
            if fc.data_path == 'rotation_quaternion'
        }
        rot_fcurves_euler = {
            fc.array_index: fc
            for fc in action.fcurves
            if fc.data_path == 'rotation_euler'
        }
        # We will modify curves based on current_rotation_mode

        # --- Collect Keyframes in User Range ---
        keyframes_to_modify = set()
        active_fcurves_to_update = set() # Track which curves actually get modified

        curves_to_check = list(rot_fcurves_quat.values()) + list(rot_fcurves_euler.values())

        for fcurve in curves_to_check:
            if not fcurve.keyframe_points:
                 continue
            for kp in fcurve.keyframe_points:
                # Check if the keyframe falls within the user-specified range
                # We modify from the start_frame_user onwards
                if start_frame_user <= kp.co.x <= end_frame_user:
                    keyframes_to_modify.add(int(round(kp.co.x)))

        # --- Apply Fixed Orientation ---
        sorted_frames = sorted(list(keyframes_to_modify))

        if not sorted_frames:
             self.report({'INFO'}, f"在指定的帧范围 [{start_frame_user}-{end_frame_user}] 内未找到对象旋转关键帧。")
             return {'FINISHED'}

        modified_count = 0
        print(f"Processing {len(sorted_frames)} frames with rotation keyframes between {sorted_frames[0]} and {sorted_frames[-1]}.")

        # --- Pre-calculate Target Rotation in Current Mode ---
        target_rotation_value = None
        if 'QUATERNION' in current_rotation_mode:
            target_rotation_value = target_world_rotation_quat.copy()
            print(f"Target Rotation (Quaternion): {target_rotation_value}")
        elif 'AXIS_ANGLE' in current_rotation_mode:
            # Axis angle needs careful handling - converting world quat to local axis angle is complex.
            # For simplicity, let's convert the target quat to Euler based on mode if AxisAngle is detected
            # Or better yet, force quaternion mode temporarily? Sticking to Euler for now if AxisAngle.
             try:
                target_rotation_value = target_world_rotation_quat.to_euler(current_rotation_mode)
                print(f"Target Rotation (converted to Euler {current_rotation_mode} from AxisAngle): {target_rotation_value}")
             except ValueError as e:
                self.report({'ERROR'}, f"无法将目标旋转转换为欧拉角（模式：{current_rotation_mode}）：{e}")
                return {'CANCELLED'}
        else: # Handle all Euler modes (XYZ, XZY, etc.)
            try:
                target_rotation_value = target_world_rotation_quat.to_euler(current_rotation_mode)
                print(f"Target Rotation (Euler {current_rotation_mode}): {target_rotation_value}")
            except ValueError as e:
                 self.report({'ERROR'}, f"无法将目标旋转转换为欧拉角（模式：{current_rotation_mode}）：{e}")
                 return {'CANCELLED'}

        if target_rotation_value is None:
            self.report({'ERROR'}, "无法计算目标旋转值")
            return {'CANCELLED'}

        # --- Modify Keyframes --- 
        for frame_int in sorted_frames:
            # Check if the frame is actually within the user range (redundant due to collection method, but safe)
            if not (start_frame_user <= frame_int <= end_frame_user):
                continue

            key_modified_this_frame = False

            if 'QUATERNION' in current_rotation_mode:
                # Ensure all 4 quaternion curves exist for this frame
                for i in range(4):
                    fcurve = rot_fcurves_quat.get(i)
                    if not fcurve:
                         # Create fcurve if it doesn't exist
                         fcurve = action.fcurves.new(data_path='rotation_quaternion', index=i)
                         rot_fcurves_quat[i] = fcurve
                         print(f"Created missing fcurve: rotation_quaternion[{i}]")

                    # Insert or update keyframe
                    # Use insert() which handles both cases
                    kp = fcurve.keyframe_points.insert(frame_int, target_rotation_value[i], options={'NEEDED', 'FAST'})
                    #kp.interpolation = 'LINEAR' # Or CONSTANT? Let's stick to Blender default for now
                    active_fcurves_to_update.add(fcurve)
                    key_modified_this_frame = True
                # Clean up Euler keys at this frame (optional but good practice)
                for i in range(3):
                    if i in rot_fcurves_euler:
                         kp_to_remove = rot_fcurves_euler[i].keyframe_points.find(frame_int)
                         if kp_to_remove:
                             rot_fcurves_euler[i].keyframe_points.remove(kp_to_remove)
                             print(f"Removed conflicting Euler key at frame {frame_int} axis {i}")
                             active_fcurves_to_update.add(rot_fcurves_euler[i])

            else: # Euler or AxisAngle (handled as Euler)
                # Ensure all 3 euler curves exist for this frame
                for i in range(3):
                    fcurve = rot_fcurves_euler.get(i)
                    if not fcurve:
                        fcurve = action.fcurves.new(data_path='rotation_euler', index=i)
                        rot_fcurves_euler[i] = fcurve
                        print(f"Created missing fcurve: rotation_euler[{i}]")

                    # Insert or update keyframe
                    kp = fcurve.keyframe_points.insert(frame_int, target_rotation_value[i], options={'NEEDED', 'FAST'})
                    active_fcurves_to_update.add(fcurve)
                    key_modified_this_frame = True
                # Clean up Quaternion keys at this frame
                for i in range(4):
                    if i in rot_fcurves_quat:
                        kp_to_remove = rot_fcurves_quat[i].keyframe_points.find(frame_int)
                        if kp_to_remove:
                            rot_fcurves_quat[i].keyframe_points.remove(kp_to_remove)
                            print(f"Removed conflicting Quaternion key at frame {frame_int} axis {i}")
                            active_fcurves_to_update.add(rot_fcurves_quat[i])

            if key_modified_this_frame:
                modified_count += 1

        # --- Update Curves ---
        if modified_count > 0:
            print(f"Updating {len(active_fcurves_to_update)} modified F-curves...")
            for fcurve in active_fcurves_to_update:
                 try:
                     fcurve.update()
                 except Exception as e:
                     print(f"Error updating fcurve {fcurve.data_path}[{fcurve.array_index}]: {e}")
                     self.report({'ERROR'}, f"更新曲线时出错: {e}")

            self.report({'INFO'}, f"已在 {modified_count} 个关键帧上应用固定朝向 (检测范围 {sorted_frames[0]}-{sorted_frames[-1]})")
        else:
             self.report({'INFO'}, "未修改任何旋转关键帧 (可能范围内无关键帧)")

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "start_frame")
        layout.prop(self, "end_frame")

        info_box = layout.box()
        info_box.label(text="说明:", icon='INFO')
        info_box.label(text="- 此操作会直接修改选中骨架当前Action的对象旋转关键帧。")
        info_box.label(text="- 它会读取 Action第一帧(或帧1) 的骨架世界旋转。")
        info_box.label(text="- 然后将此旋转值应用到指定范围内的所有现有旋转关键帧上。")
        info_box.label(text="- 会根据骨架当前的旋转模式 (欧拉/四元数) 修改对应通道。")
        info_box.label(text="- 请确保在运行前将时间滑块移出修改范围。")

# End of ANIM_OT_ApplyFixedOrientation class definition


class ANIM_OT_RenameLibraryAction(bpy.types.Operator):
    bl_idname = "anim.rename_library_action"
    bl_label = "重命名选中动作"
    bl_options = {'REGISTER', 'UNDO'}

    new_name: bpy.props.StringProperty(
        name="新动作名称",
        default=""
    )

    @classmethod
    def poll(cls, context):
        props = context.scene.anim_merge_props
        return props and props.action_library_items and props.action_library_index >= 0

    def invoke(self, context, event):
        props = context.scene.anim_merge_props
        idx = props.action_library_index
        if not (0 <= idx < len(props.action_library_items)):
            self.report({'WARNING'}, "没有选中的有效动作项")
            return {'CANCELLED'}
        self.new_name = props.action_library_items[idx].name
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        layout = self.layout
        props = context.scene.anim_merge_props
        idx = props.action_library_index
        old_name = props.action_library_items[idx].name if 0 <= idx < len(props.action_library_items) else ""
        layout.label(text=f"当前名称: {old_name}", icon='ACTION')
        layout.prop(self, "new_name", text="新名称")

    def execute(self, context):
        props = context.scene.anim_merge_props
        idx = props.action_library_index
        if not (0 <= idx < len(props.action_library_items)):
            self.report({'WARNING'}, "没有选中的有效动作项")
            return {'CANCELLED'}

        item = props.action_library_items[idx]
        old_name = item.name
        new_name = self.new_name.strip()

        if not new_name:
            self.report({'ERROR'}, "新名称不能为空")
            return {'CANCELLED'}

        if new_name == old_name:
            self.report({'INFO'}, "名称未变化")
            return {'CANCELLED'}

        for i, other in enumerate(props.action_library_items):
            if i != idx and other.name == new_name:
                self.report({'ERROR'}, "动作库中已存在同名动作")
                return {'CANCELLED'}

        path_changed = False
        item_path = Path(item.filepath) if item.filepath else None
        updated_path = item_path

        try:
            if not item_path:
                self.report({'ERROR'}, "动作项没有有效文件路径，无法重命名")
                return {'CANCELLED'}
            if not item_path.exists():
                self.report({'ERROR'}, f"动作文件不存在，无法重命名: {item_path.name}")
                return {'CANCELLED'}
            if item_path.suffix.lower() != ".json":
                self.report({'ERROR'}, f"只支持重命名JSON动作文件: {item_path.name}")
                return {'CANCELLED'}

            # 尝试同步重命名文件名，便于后续管理
            safe_stem = clean_filename(new_name) or "Action"
            candidate = item_path.with_name(f"{safe_stem}{item_path.suffix}")
            if candidate != item_path:
                counter = 1
                while candidate.exists():
                    candidate = item_path.with_name(f"{safe_stem}_{counter}{item_path.suffix}")
                    counter += 1
                item_path.rename(candidate)
                updated_path = candidate
                path_changed = True

            # 同步更新 JSON 中的动作名称
            with open(updated_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            data["name"] = new_name
            with open(updated_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            self.report({'ERROR'}, f"重命名失败: {str(e)}")
            return {'CANCELLED'}

        item.name = new_name
        if updated_path:
            item.filepath = str(updated_path)

        props.library_last_message = (
            f"已重命名动作: {old_name} -> {new_name}"
            + (" (文件名已更新)" if path_changed else "")
        )
        _refresh_library_view(context, target_filepath=updated_path, target_name=new_name)
        self.report({'INFO'}, props.library_last_message)
        return {'FINISHED'}


# Operator to delete a selected action from the library
class ANIM_OT_DeleteLibraryAction(bpy.types.Operator):

    bl_idname = "anim.delete_library_action"
    bl_label = "删除选中动作"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        props = context.scene.anim_merge_props
        # Enable only if the list is not empty and an item is selected
        return props and props.action_library_items and props.action_library_index >= 0

    def execute(self, context):
        props = context.scene.anim_merge_props
        index_to_remove = props.action_library_index

        if not (0 <= index_to_remove < len(props.action_library_items)):
            self.report({'WARNING'}, "没有选中的有效动作项")
            return {'CANCELLED'}

        item_to_remove = props.action_library_items[index_to_remove]
        action_name = item_to_remove.name
        action_filepath_str = item_to_remove.filepath

        if not action_filepath_str:
            self.report({'ERROR'}, f"动作 '{action_name}' 没有有效的文件路径，无法删除")
            _refresh_library_view(context)
            return {'CANCELLED'}

        action_filepath = Path(action_filepath_str)

        # Confirmation dialog
        # Using invoke_confirm is generally better, but for simplicity using execute with report
        print(f"准备删除动作: {action_name} ({action_filepath})")

        # --- Delete the file --- 
        try:
            if action_filepath.is_file():
                os.remove(action_filepath)
                print(f"已删除文件: {action_filepath}")
            else:
                self.report({'WARNING'}, f"文件未找到，可能已被删除: {action_filepath}")
                # Proceed to remove from list even if file not found

            props.library_last_message = f"已删除动作: {action_name}"
            _refresh_library_view(context)

            self.report({'INFO'}, f"已删除动作: '{action_name}'")
            return {'FINISHED'}

        except OSError as e:
            self.report({'ERROR'}, f"删除文件 '{action_filepath.name}' 时出错: {e}")
            return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, f"删除动作时发生未知错误: {e}")
            return {'CANCELLED'}

    # Optional: Add invoke method for confirmation dialog
    # def invoke(self, context, event):
    #     return context.window_manager.invoke_confirm(self, event)


# Helper function to get library folders
def get_library_folders(self, context):
    items = []
    if LIBRARY_PATH.exists() and LIBRARY_PATH.is_dir():
        for item in LIBRARY_PATH.iterdir():
            if item.is_dir():
                items.append((item.name, item.name, f"目标分类 {item.name}"))
    if not items:
        items.append(("_NO_FOLDERS_", "没有可用的分类", "请先创建分类"))
    items.sort(key=lambda x: x[0].lower())
    return items

# Operator to create a new folder in the library
class ANIM_OT_CreateLibraryFolder(bpy.types.Operator):

    bl_idname = "anim.create_library_folder"
    bl_label = "创建新分类"
    bl_options = {'REGISTER', 'UNDO'}

    new_folder_name: bpy.props.StringProperty(
        name="分类名称",
        description="新分类（文件夹）的名称",
        default="新分类"
    )

    def execute(self, context):
        raw_name = self.new_folder_name.strip()
        if not raw_name:
            self.report({'ERROR'}, "分类名称不能为空")
            return {'CANCELLED'}

        cleaned_name_part = clean_filename(raw_name)
        if not cleaned_name_part or cleaned_name_part in [".", ".."]:
            self.report({'ERROR'}, "无效的分类名称部分")
            return {'CANCELLED'}

        safe_name = f"Group_{cleaned_name_part}"

        new_folder_path = LIBRARY_PATH / safe_name

        if new_folder_path.exists():
            self.report({'ERROR'}, f"分类 '{safe_name}' 已存在")
            return {'CANCELLED'}

        try:
            new_folder_path.mkdir(parents=True, exist_ok=False)
            self.report({'INFO'}, f"已创建分类 '{safe_name}'")
            return {'FINISHED'}
        except OSError as e:
            self.report({'ERROR'}, f"创建分类 '{safe_name}' 时出错 {e}")
            return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, f"创建分类时发生未知错误 {e}")
            return {'CANCELLED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

class ANIM_OT_DeleteLibraryFolder(bpy.types.Operator):

    bl_idname = "anim.delete_library_folder"
    bl_label = "删除分类"
    bl_options = {'REGISTER', 'UNDO'}

    folder_to_delete: bpy.props.EnumProperty(
        name="要删除的分类",
        description="选择要永久删除的分类及其所有内容",
        items=get_library_folders
    )

    @classmethod
    def poll(cls, context):
        folders = get_library_folders(cls, context)
        return folders and folders[0][0] != "_NO_FOLDERS_"

    def execute(self, context):
        target_folder_name = self.folder_to_delete
        if target_folder_name == "_NO_FOLDERS_":
            self.report({'ERROR'}, "没有选择有效的分类")
            return {'CANCELLED'}

        folder_path = LIBRARY_PATH / target_folder_name

        if not folder_path.is_dir():
            self.report({'ERROR'}, f"分类文件夹未找到 {folder_path}")
            return {'CANCELLED'}

        try:
            print(f"即将永久删除文件夹及其内容 {folder_path}")
            shutil.rmtree(str(folder_path))
            print(f"已删除文件夹 {folder_path}")

            props = context.scene.anim_merge_props
            indices_to_remove = []
            for i, item in enumerate(props.action_library_items):
                if item.source_fbx == target_folder_name:
                    indices_to_remove.append(i)

            removed_count = 0
            for i in sorted(indices_to_remove, reverse=True):
                try:
                    props.action_library_items.remove(i)
                    removed_count += 1
                except Exception as e:
                    print(f"从列表移除项目 {i} 时出错 {e}")

            if props.action_library_items:
                 current_index = props.action_library_index
                 if current_index in indices_to_remove:
                     props.action_library_index = 0
                 else:
                      removed_before_current = sum(1 for i in indices_to_remove if i < current_index)
                      props.action_library_index = max(0, current_index - removed_before_current)
            else:
                 props.action_library_index = -1

            self.report({'INFO'}, f"已删除分类 '{target_folder_name}' 并移除了 {removed_count} 个动作项")
            context.area.tag_redraw()
            return {'FINISHED'}

        except OSError as e:
            self.report({'ERROR'}, f"删除文件夹 '{target_folder_name}' 时出错 {e}")
            return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, f"删除分类时发生未知错误 {e}")
            return {'CANCELLED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "folder_to_delete")
        layout.separator()
        warning_box = layout.box()
        warning_box.alert = True
        warning_box.label(text="警告 此操作将永久删除所选分类及其包含的所有动作文件", icon='ERROR')
        warning_box.label(text="此操作无法撤销", icon='CANCEL_M')
