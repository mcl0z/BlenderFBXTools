from .core_base import *

# Breath animation property group/operator/panel.
class BreathAnimationProperties(bpy.types.PropertyGroup):
    """骨骼呼吸动画设置"""
    
    # 动画帧范围
    frame_start: bpy.props.IntProperty(
        name="起始帧",
        description="呼吸动画的起始帧",
        default=1,
        min=1
    )
    
    frame_end: bpy.props.IntProperty(
        name="结束帧",
        description="呼吸动画的结束帧",
        default=100,
        min=2
    )
    
    # 旋转幅度 (角度)
    rotation_amount: bpy.props.FloatProperty(
        name="旋转幅度",
        description="骨骼旋转的最大角度(度)",
        default=3.0,
        min=0.1,
        max=20.0
    )
    
    # 旋转轴
    rotation_axis: bpy.props.EnumProperty(
        name="旋转轴",
        description="骨骼旋转的主要轴向",
        items=[
            ('X', "X轴", "沿X轴旋转"),
            ('Y', "Y轴", "沿Y轴旋转"),
            ('Z', "Z轴", "沿Z轴旋转")
        ],
        default='Z'
    )
    
    # 动画周期数
    cycles: bpy.props.IntProperty(
        name="周期数",
        description="在指定帧范围内完成的呼吸周期数",
        default=2,
        min=1,
        max=20
    )
    
    # 缓动类型
    easing_type: bpy.props.EnumProperty(
        name="缓动类型",
        description="呼吸动画的缓动方式",
        items=[
            ('SINE', "正弦", "平滑的正弦波动"),
            ('QUAD', "二次方", "更加缓慢的起止"),
            ('LINEAR', "线性", "均匀速度")
        ],
        default='SINE'
    )

# 添加一个呼吸动画操作符
class ANIM_OT_ApplyBreathAnimation(bpy.types.Operator):
    bl_idname = "anim.apply_breath_animation"
    bl_label = "应用呼吸动画"
    bl_description = "为选中的骨骼添加轻微旋转的呼吸效果"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        # 检查是否有活动的骨架且处于姿态模式
        return (context.active_object and 
                context.active_object.type == 'ARMATURE' and
                context.active_object.mode == 'POSE' and
                context.selected_pose_bones)
    
    def execute(self, context):
        import math
        import mathutils # 需要导入 mathutils

        props = context.scene.breath_anim_props
        obj = context.active_object # 使用 obj 而不是 armature
        scene = context.scene # 需要 scene 对象

        # Check if the active object is an armature
        if not obj or obj.type != 'ARMATURE':
            self.report({'WARNING'}, "请选择一个骨架对象")
            return {'CANCELLED'}

        # Check if in Pose Mode
        if context.mode != 'POSE':
            self.report({'WARNING'}, "请进入姿态模式 (Pose Mode)")
            return {'CANCELLED'}

        selected_pose_bones = context.selected_pose_bones
        if not selected_pose_bones:
            self.report({'WARNING'}, "请在姿态模式下选择至少一个骨骼") # 更清晰的提示
            return {'CANCELLED'}

        # Ensure animation data exists
        if not obj.animation_data:
            obj.animation_data_create()
        action = obj.animation_data.action
        if not action:
            # 使用 obj.name
            action = bpy.data.actions.new(name=f"{obj.name}_BreathAction")
            obj.animation_data.action = action

        # Animation parameters
        frame_start = props.frame_start
        frame_end = props.frame_end
        duration = frame_end - frame_start + 1
        if duration <= 0:
            self.report({'WARNING'}, "结束帧必须大于起始帧")
            return {'CANCELLED'}

        rotation_amount_rad = math.radians(props.rotation_amount)
        cycles = props.cycles
        # frequency = (2 * math.pi * cycles) / duration # Frequency not directly used
        axis = props.rotation_axis # 'X', 'Y', 'Z'
        easing_type = props.easing_type # 'LINEAR', 'EASE_IN', 'EASE_OUT', 'SINE', 'QUAD'

        # --- Main Loop ---\
        current_frame_scene = scene.frame_current # Store current frame

        try: # Use try/finally to restore frame
            for pb in selected_pose_bones:
                # --- Determine rotation mode and property ---
                rotation_prop = 'rotation_quaternion' if pb.rotation_mode == 'QUATERNION' else 'rotation_euler'
                is_quaternion = (rotation_prop == 'rotation_quaternion')

                # --- Get Base Rotation (evaluated at frame before start) ---
                eval_frame = max(scene.frame_start, frame_start - 1)
                if frame_start <= scene.frame_start: # Handle edge case
                     eval_frame = scene.frame_start

                # Store current pose bone state before changing frame (important!)
                original_quat = pb.rotation_quaternion.copy()
                original_euler = pb.rotation_euler.copy()
                original_matrix = pb.matrix.copy() # Store full matrix as well

                # Set frame and update dependency graph to get evaluated state
                scene.frame_set(eval_frame)
                obj.data.update_tag() # Tag armature data for update
                context.view_layer.update() # Evaluate the dependency graph

                # Read the *evaluated* rotation at eval_frame
                if is_quaternion:
                    base_rotation = pb.rotation_quaternion.copy()
                else:
                    # Ensure Euler mode is consistent if not Quaternion
                    if pb.rotation_mode not in {'XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX'}:
                         pb.rotation_mode = 'XYZ' # Default to XYZ Euler if not set
                         self.report({'INFO'}, f"骨骼 {pb.name} 旋转模式已设为 XYZ")
                    base_rotation = pb.rotation_euler.copy()

                # Restore original pose bone state immediately after reading base rotation
                pb.rotation_quaternion = original_quat
                pb.rotation_euler = original_euler
                pb.matrix = original_matrix # Restore matrix too
                context.view_layer.update() # Update view layer after restoring state


                # --- Apply Breath Animation Keyframes within the specified range ---
                for frame in range(frame_start, frame_end + 1):
                    # Calculate progress (0 to 1) within the duration
                    denom = duration - 1 if duration > 1 else 1
                    progress = (frame - frame_start) / denom

                    # Apply easing function to progress
                    eased_progress = progress # Default to linear
                    if easing_type == 'EASE_IN':
                        eased_progress = progress * progress # Quadratic ease-in
                    elif easing_type == 'EASE_OUT':
                        eased_progress = 1 - (1 - progress) * (1 - progress) # Quadratic ease-out
                    elif easing_type == 'SINE': # Keep existing easing types if desired
                        eased_progress = 0.5 * (1 - math.cos(progress * math.pi))
                    elif easing_type == 'QUAD': # Approximation? Better sine is usually used
                         # The previous QUAD implementation seemed complex, using simple Sine below
                         pass # Falls back to Sine via Sine calculation below

                    # Calculate the angle offset using a sine wave based on eased progress
                    # Ensures 'cycles' complete waves over the duration
                    # Common approach: angle_offset = amplitude * sin(phase)
                    # Phase goes from 0 to cycles * 2 * pi
                    phase = eased_progress * cycles * 2 * math.pi
                    angle_offset = rotation_amount_rad * math.sin(phase)


                    # Create the incremental rotation offset based on the axis
                    if is_quaternion:
                        # Create quaternion offset around the specified axis
                        axis_vector = mathutils.Vector((1.0 if axis == 'X' else 0.0,
                                                        1.0 if axis == 'Y' else 0.0,
                                                        1.0 if axis == 'Z' else 0.0))
                        breath_offset_rotation = mathutils.Quaternion(axis_vector, angle_offset)
                        # Combine base rotation with the offset
                        # Apply breath offset in the *local* space relative to the base pose
                        final_rotation = base_rotation @ breath_offset_rotation
                        pb.rotation_quaternion = final_rotation
                    else: # Euler
                        # Create Euler offset (applied to the specific axis)
                        # Combining Euler rotations directly can be tricky due to order.
                        # It's often safer to convert to matrices/quaternions for combination.
                        breath_offset_euler = mathutils.Euler((angle_offset if axis == 'X' else 0.0,
                                                               angle_offset if axis == 'Y' else 0.0,
                                                               angle_offset if axis == 'Z' else 0.0), pb.rotation_mode)

                        # Combine: Convert base Euler to matrix, multiply by offset Euler's matrix, convert back
                        base_matrix = base_rotation.to_matrix().to_4x4()
                        offset_matrix = breath_offset_euler.to_matrix().to_4x4()

                        # Apply breath offset locally relative to the base pose
                        final_matrix = base_matrix @ offset_matrix
                        # Convert back to Euler, using the bone's original mode
                        final_rotation = final_matrix.to_euler(pb.rotation_mode) # base_rotation is not needed here

                        pb.rotation_euler = final_rotation

                    # Insert keyframe for the calculated rotation at the current frame
                    # This will overwrite existing keyframes *only* for this property at this frame
                    pb.keyframe_insert(data_path=rotation_prop, frame=frame)

            self.report({'INFO'}, f"已为 {len(selected_pose_bones)} 个骨骼应用呼吸动画 [{frame_start}-{frame_end}]")

        except Exception as e:
            import traceback
            traceback.print_exc() # Print detailed error to console
            self.report({'ERROR'}, f"应用呼吸动画时出错: {e}")
            # Restore frame even on error
            scene.frame_set(current_frame_scene)
            # Update viewport
            context.view_layer.update()
            return {'CANCELLED'}
        finally:
            # Restore the original frame that was active before the operator ran
            scene.frame_set(current_frame_scene)
            # Update viewport to show final state/reflect changes
            context.view_layer.update()
            # Optional: Refresh editors if needed, but update() often suffices
            # for area in context.screen.areas:
            #     if area.type in ['VIEW_3D', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR']:
            #         area.tag_redraw()

        return {'FINISHED'}

# 添加呼吸动画面板
class ANIM_PT_BreathAnimation(bpy.types.Panel):
    bl_label = "骨骼呼吸动画"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "动画工具"
    
    @classmethod
    def poll(cls, context):
        # 只在active_panel为BREATH时显示，但内容会根据是否有选中骨架和姿态模式而变化
        return context.scene.anim_merge_props.active_panel == 'BREATH'
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.breath_anim_props
        
        # 获取活动对象
        armature = context.active_object
        
        # 显示说明
        if armature.mode != 'POSE':
            box = layout.box()
            box.label(text="需要处于姿态模式", icon='INFO')
            row = layout.row()
            row.operator("object.mode_set", text="进入姿态模式").mode = 'POSE'
            return
        
        # 选中骨骼信息
        selected_bones = context.selected_pose_bones
        box = layout.box()
        if selected_bones:
            box.label(text=f"已选择 {len(selected_bones)} 个骨骼", icon='BONE_DATA')
        else:
            box.label(text="请选择需要添加呼吸动画的骨骼", icon='ERROR')
        
        # 参数设置
        box = layout.box()
        box.label(text="动画设置", icon='SETTINGS')
        
        # 帧范围设置
        row = box.row()
        row.label(text="帧范围:")
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(props, "frame_start", text="开始")
        row.prop(props, "frame_end", text="结束")
        
        # 旋转设置
        row = box.row()
        row.label(text="旋转设置:")
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(props, "rotation_amount")
        row = col.row(align=True)
        row.prop(props, "rotation_axis", expand=True)
        
        # 周期设置
        row = box.row()
        row.label(text="周期数:")
        row.prop(props, "cycles", text="")
        
        # 缓动类型
        row = box.row()
        row.label(text="缓动类型:")
        row.prop(props, "easing_type", text="")
        
        # 应用按钮 - 使用原生的启用/禁用方式
        is_ready = armature.mode == 'POSE' and bool(selected_bones)
        row = layout.row()
        row.scale_y = 1.5
        row.enabled = is_ready  # 设置行的启用状态，而不是operator的属性
        row.operator("anim.apply_breath_animation", icon='MOD_WAVE')
        
        # 提示信息
        col = layout.column()
        col.label(text="提示: 选择骨骼后点击应用按钮", icon='INFO')
        col.label(text="呼吸效果会创建轻微旋转动画")

