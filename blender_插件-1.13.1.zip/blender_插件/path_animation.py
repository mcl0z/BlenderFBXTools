from .core_base import *


def _is_valid_object(obj):
    return obj is not None and obj.name in bpy.data.objects


def _resolve_path_target(props, context):
    curve_obj = props.curve_object if _is_valid_object(props.curve_object) else None

    if _is_valid_object(props.target_object):
        target_obj = props.target_object
        if not curve_obj or target_obj.name != curve_obj.name:
            return target_obj

    active_obj = context.active_object
    if _is_valid_object(active_obj):
        if not curve_obj or active_obj.name != curve_obj.name:
            return active_obj

    return None


class ANIM_OT_SetPathTarget(bpy.types.Operator):
    bl_idname = "anim.set_path_target"
    bl_label = "设为路径目标"
    bl_description = "将当前选中对象设为路径动画目标对象"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not context.active_object:
            return False
        props = context.scene.path_anim_props
        curve_obj = props.curve_object
        return not (curve_obj and curve_obj.name == context.active_object.name)

    def execute(self, context):
        props = context.scene.path_anim_props
        props.target_object = context.active_object
        self.report({'INFO'}, f"路径目标已设置为: {context.active_object.name}")
        return {'FINISHED'}


# Bezier path animation operators and panel.
class ANIM_OT_CreateBezierPath(bpy.types.Operator):
    bl_idname = "anim.create_bezier_path"
    bl_label = "创建贝塞尔路径"
    bl_description = "为选中物体创建一条贝塞尔路径曲线"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        # 修改判断条件，现在允许骨架(armature)类型的物体
        return context.active_object is not None
    
    def execute(self, context):
        props = context.scene.path_anim_props
        active_obj = context.active_object

        if not active_obj:
            self.report({'ERROR'}, "请先选择目标对象")
            return {'CANCELLED'}

        # 避免把路径曲线本身当作目标对象
        if props.curve_object and active_obj.name == props.curve_object.name:
            self.report({'ERROR'}, "请先选择要运动的目标对象，而不是路径曲线")
            return {'CANCELLED'}

        # 统一在对象模式下创建路径，减少模式切换异常
        if context.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception as e:
                self.report({'ERROR'}, f"无法切换到对象模式: {e}")
                return {'CANCELLED'}
        
        # 如果已存在曲线，先删除
        if props.curve_object and props.curve_object.name in bpy.data.objects:
            bpy.data.objects.remove(props.curve_object, do_unlink=True)
        
        # 创建贝塞尔曲线
        curve_data = bpy.data.curves.new(name=f"{active_obj.name}_Path", type='CURVE')
        curve_data.dimensions = '3D'
        curve_data.resolution_u = 12
        
        # 设置曲线显示属性 - 使用安全的方式设置控制点显示
        # 注意：不是所有Blender版本的Curve对象都有show_handles属性
        try:
            # 尝试设置显示控制柄（较新版本的Blender）
            if hasattr(curve_data, "show_handles"):
                curve_data.show_handles = True
        except:
            pass  # 如果不支持，就跳过
            
        # 创建曲线对象
        curve_obj = bpy.data.objects.new(f"{active_obj.name}_Path", curve_data)
        context.collection.objects.link(curve_obj)
        
        # 创建样条
        spline = curve_data.splines.new(type='BEZIER')
        
        # 设置控制点数量
        if props.control_points > 1:
            spline.bezier_points.add(props.control_points - 1)
        
        # 初始曲线形状 - 围绕物体创建一个简单路径
        obj_loc = active_obj.location
        obj_size = 2.0
        
        # 计算控制点位置和手柄
        points_count = len(spline.bezier_points)
        for i, point in enumerate(spline.bezier_points):
            # 计算控制点位置 (围绕物体创建一个圆形路径)
            angle = (i / points_count) * 2 * math.pi
            x = obj_loc.x + obj_size * math.cos(angle)
            y = obj_loc.y + obj_size * math.sin(angle)
            z = obj_loc.z
            
            # 设置控制点位置
            point.co = (x, y, z)
            
            # 计算手柄方向 (圆形的切线)
            handle_angle = angle + math.pi/2
            handle_x = 0.5 * math.cos(handle_angle)
            handle_y = 0.5 * math.sin(handle_angle)
            
            # 设置控制点手柄 (使曲线平滑)
            point.handle_left = (x - handle_x, y - handle_y, z)
            point.handle_right = (x + handle_x, y + handle_y, z)
            
            # 设置控制点手柄类型
            point.handle_left_type = 'ALIGNED'
            point.handle_right_type = 'ALIGNED'
        
        # 存储创建的曲线对象在属性中
        props.curve_object = curve_obj
        props.target_object = active_obj
        props.applied_control_points = props.control_points
        
        # 选择曲线对象以便编辑
        for obj in bpy.context.selected_objects:
            obj.select_set(False)
        curve_obj.select_set(True)
        context.view_layer.objects.active = curve_obj
        
        # 切换到编辑模式以便用户可以立即编辑控制点
        bpy.ops.object.mode_set(mode='EDIT')
        
        self.report({'INFO'}, f"已创建贝塞尔路径，请调整形状后点击应用")
        return {'FINISHED'}

# 修改应用路径动画操作符，使用Blender的曲线评估API获取精确位置和切线
class ANIM_OT_ApplyPathAnimation(bpy.types.Operator):
    bl_idname = "anim.apply_path_animation"
    bl_label = "应用路径动画"
    bl_description = "将选中物体沿贝塞尔路径移动 (精确采样)"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        props = context.scene.path_anim_props
        return (
            props.curve_object
            and props.curve_object.name in bpy.data.objects
            and _resolve_path_target(props, context) is not None
        )
    
    def execute(self, context):
        props = context.scene.path_anim_props
        curve_obj = props.curve_object
        if not curve_obj or curve_obj.name not in bpy.data.objects:
            self.report({'ERROR'}, "路径曲线不存在，请重新创建")
            return {'CANCELLED'}

        active_obj = _resolve_path_target(props, context)
        if not active_obj:
            self.report({'ERROR'}, "请先选择或指定路径目标对象")
            return {'CANCELLED'}
        props.target_object = active_obj

        if props.frame_end <= props.frame_start:
            self.report({'ERROR'}, "结束帧必须大于起始帧")
            return {'CANCELLED'}

        # 尽量先退出编辑模式，避免误作用于曲线对象
        if context.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

        # 确保曲线对象处于对象模式
        old_active = context.view_layer.objects.active
        if curve_obj.mode != 'OBJECT':
            context.view_layer.objects.active = curve_obj
            bpy.ops.object.mode_set(mode='OBJECT')

        # 再切回目标对象作为动画写入对象
        context.view_layer.objects.active = active_obj
        active_obj.select_set(True)
        
        # 检查物体类型并打印相应消息
        is_armature = active_obj.type == 'ARMATURE'
        if is_armature:
            print(f"--- 开始为骨架 ({active_obj.name}) 创建精确路径动画 ---")
        else:
            print(f"--- 开始创建精确路径动画 ({active_obj.name}) ---")
        
        # 1. 基本参数设置
        start_frame = props.frame_start
        base_duration = props.frame_end - props.frame_start
        speed_factor = max(0.01, props.speed_factor)
        adjusted_duration = max(1, int(base_duration / speed_factor))
        end_frame = start_frame + adjusted_duration
        
        # 确保Curve启用了Path参数
        curve_obj.data.use_path = True
        # 设置曲线分辨率和路径时长
        curve_obj.data.resolution_u = max(32, curve_obj.data.resolution_u)  # 确保足够高的分辨率
        curve_obj.data.path_duration = base_duration
        
        # 创建动画数据
        if not active_obj.animation_data:
            active_obj.animation_data_create()
        
        # 创建或重用动作
        action_name = f"{active_obj.name}_PathAction"
        if action_name in bpy.data.actions:
            action = bpy.data.actions[action_name]
            # 清除旧的位置和旋转曲线
            fcurves_to_remove = []
            for fc in action.fcurves:
                if fc.data_path in ["location", "rotation_euler", "rotation_quaternion"]:
                    fcurves_to_remove.append(fc)
            for fc in fcurves_to_remove:
                action.fcurves.remove(fc)
        else:
            action = bpy.data.actions.new(action_name)
        
        active_obj.animation_data.action = action
        
        # 2. 为位置和旋转创建FCurves
        loc_fcurves = []
        for i in range(3):  # XYZ
            fc = action.fcurves.new(data_path="location", index=i)
            loc_fcurves.append(fc)
        
        rot_fcurves = []
        if props.follow_path:
            rotation_mode = active_obj.rotation_mode
            if rotation_mode == 'QUATERNION':
                for i in range(4):  # WXYZ
                    fc = action.fcurves.new(data_path="rotation_quaternion", index=i)
                    rot_fcurves.append(fc)
            else:  # 欧拉旋转
                for i in range(3):  # XYZ
                    fc = action.fcurves.new(data_path="rotation_euler", index=i)
                    rot_fcurves.append(fc)
        
        # 3. 准备曲线路径计算
        import mathutils
        curve_data = curve_obj.data
        splines = curve_data.splines
        matrix_world = curve_obj.matrix_world
        
        if not splines:
            self.report({'ERROR'}, f"曲线对象 {curve_obj.name} 没有样条曲线")
            return {'CANCELLED'}
        
        # 使用样条曲线的路径评估函数
        print(f"获取曲线路径采样数据...")
        
        # 需要的采样数量（每帧一个采样点）
        num_samples = adjusted_duration + 1  
        samples_per_segment = 10  # 每段曲线的额外采样点，用于平滑
        
        # 收集位置和方向数据
        curve_points = []  # 将存储 (位置, 方向) 元组
        total_length = 0  # 用于计算曲线总长度
        prev_point = None
        
        # 使用细分采样收集路径数据
        for spline in splines:
            # 获取样条曲线的点
            if spline.type == 'BEZIER':
                # 对贝塞尔曲线进行精确采样
                points = spline.bezier_points
                segments = len(points) - 1
                
                if segments <= 0:
                    continue  # 跳过单点曲线
                
                # 对每段曲线进行细分采样
                for i in range(segments):
                    p0 = points[i]
                    p1 = points[i+1]
                    
                    # 对这段曲线进行均匀采样
                    for t_sub in range(samples_per_segment + 1):
                        t = t_sub / samples_per_segment
                        # 计算贝塞尔曲线上的精确点
                        # p0.co, p0.handle_right, p1.handle_left, p1.co 是贝塞尔曲线段的4个控制点
                        
                        bezier_point, bezier_tangent = self.evaluate_bezier_curve(
                            matrix_world @ p0.co,
                            matrix_world @ p0.handle_right,
                            matrix_world @ p1.handle_left,
                            matrix_world @ p1.co,
                            t
                        )
                        
                        if prev_point is not None:
                            segment_length = (bezier_point - prev_point).length
                            total_length += segment_length
                        
                        curve_points.append((bezier_point, bezier_tangent.normalized()))
                        prev_point = bezier_point
                
        # 4. 根据长度参数重新采样以获取均匀的点
        if len(curve_points) < 2:
            self.report({'ERROR'}, "曲线太短，无法创建路径动画")
            return {'CANCELLED'}
            
        # 根据路径长度重采样，确保均匀分布，便于基于速度的控制
        resampled_points = []
        distances = [0]  # 起点距离为0
        
        # 计算累计距离
        for i in range(1, len(curve_points)):
            pos_prev, _ = curve_points[i-1]
            pos_curr, _ = curve_points[i]
            distances.append(distances[i-1] + (pos_curr - pos_prev).length)
            
        # 5. 应用插值类型和创建关键帧
        print(f"创建关键帧，应用插值类型: {props.interpolation_type}...")
        
        # 根据插值类型处理采样
        for i in range(num_samples):
            frame = start_frame + i
            
            # 根据插值类型计算不同的时间参数
            if props.interpolation_type == 'LINEAR':
                # 线性插值 - 均匀分布的 t
                t = i / (num_samples - 1) if num_samples > 1 else 0
            elif props.interpolation_type == 'EASE_IN':
                # 先慢后快 - 使用二次方插值
                t_raw = i / (num_samples - 1) if num_samples > 1 else 0
                t = t_raw * t_raw  # 二次方加速
            elif props.interpolation_type == 'EASE_OUT':
                # 先快后慢 - 使用二次方插值
                t_raw = i / (num_samples - 1) if num_samples > 1 else 0
                t = 1 - (1 - t_raw) * (1 - t_raw)  # 二次方减速
            else:
                # 默认线性
                t = i / (num_samples - 1) if num_samples > 1 else 0
            
            # 计算目标距离
            target_distance = t * distances[-1]
            
            # 二分查找找到最接近的点
            idx_low = 0
            idx_high = len(distances) - 1
            while idx_high - idx_low > 1:
                idx_mid = (idx_low + idx_high) // 2
                if distances[idx_mid] < target_distance:
                    idx_low = idx_mid
                else:
                    idx_high = idx_mid
                    
            # 在找到的段上插值
            segment_t = 0
            if idx_high > idx_low:
                segment_length = distances[idx_high] - distances[idx_low]
                if segment_length > 0:
                    segment_t = (target_distance - distances[idx_low]) / segment_length
            
            pos_low, dir_low = curve_points[idx_low]
            pos_high, dir_high = curve_points[idx_high]
            
            # 位置线性插值
            position = pos_low.lerp(pos_high, segment_t)
            
            # 方向球面插值 (对单位向量)
            direction = dir_low.slerp(dir_high, segment_t)
            if direction.length < 0.001:  # 避免零向量
                direction = dir_high if dir_high.length > 0.001 else mathutils.Vector((1, 0, 0))
                
            # 位置关键帧
            for axis in range(3):
                loc_fcurves[axis].keyframe_points.insert(frame, position[axis])
            
            # 旋转关键帧 (如果启用了旋转跟随)
            if props.follow_path and rot_fcurves:
                # 构建朝向矩阵 - 以direction为前方向
                forward = direction
                up = mathutils.Vector((0, 0, 1))  # 假设Z轴向上
                
                # 解决接近平行时的问题
                if abs(forward.dot(up)) > 0.99:
                    up = mathutils.Vector((0, 1, 0))  # 换用Y轴
                
                # 右手坐标系
                right = forward.cross(up).normalized()
                up = right.cross(forward).normalized()
                
                # 创建旋转矩阵
                rot_matrix = mathutils.Matrix((
                    right,
                    forward,
                    up
                ))
                rot_matrix.transpose()  # 矩阵转置
                
                # 根据物体的旋转模式设置
                if rotation_mode == 'QUATERNION':
                    quat = rot_matrix.to_quaternion()
                    for j in range(4):
                        rot_fcurves[j].keyframe_points.insert(frame, quat[j])
                else:
                    euler = rot_matrix.to_euler(rotation_mode)
                    for j in range(3):
                        rot_fcurves[j].keyframe_points.insert(frame, euler[j])
        
        # 6. 更新F曲线
        print("更新F曲线...")
        for fc in loc_fcurves + rot_fcurves:
            # 设置统一的线性插值，因为我们已经应用了自定义速度曲线
            for kp in fc.keyframe_points:
                kp.interpolation = 'LINEAR'
            try:
                fc.update()
            except Exception as e:
                print(f"更新FCurve时出错: {e}")
        
        # 7. 应用循环修改器
        if props.loop_type != 'NONE':
            print(f"应用循环模式: {props.loop_type}, 循环次数: {props.loop_count}, 间隔: {props.loop_gap}")
            
            # 记录有效的动画帧范围
            anim_start = start_frame
            anim_end = end_frame
            original_duration = anim_end - anim_start
            
            # 如果使用PING_PONG模式，需要手动创建返程路径
            if props.loop_type == 'PING_PONG':
                print("为PING_PONG模式创建返程路径...")
                
                # 计算返程开始帧和结束帧
                return_start_frame = anim_end
                return_end_frame = anim_start + (original_duration * 2)
                return_frames = return_end_frame - return_start_frame
                
                # 收集正向路径上的所有关键帧信息
                forward_keyframes = {}
                for fc_idx, fc in enumerate(loc_fcurves):
                    forward_keyframes[fc_idx] = []
                    for kp in fc.keyframe_points:
                        if anim_start <= kp.co.x <= anim_end:
                            forward_keyframes[fc_idx].append((kp.co.x, kp.co.y))
                
                # 同样收集旋转关键帧
                if props.follow_path and rot_fcurves:
                    for fc_idx, fc in enumerate(rot_fcurves):
                        forward_keyframes[fc_idx + len(loc_fcurves)] = []
                        for kp in fc.keyframe_points:
                            if anim_start <= kp.co.x <= anim_end:
                                forward_keyframes[fc_idx + len(loc_fcurves)].append((kp.co.x, kp.co.y))
                
                # 创建返程关键帧 - 反向添加所有正向路径的点
                # 注意帧号需要映射到返程区域
                for fc_idx, keyframes in forward_keyframes.items():
                    # 排序确保按帧顺序处理
                    sorted_keyframes = sorted(keyframes, key=lambda x: x[0])
                    
                    # 反向遍历排序后的帧
                    for i, (orig_frame, value) in enumerate(reversed(sorted_keyframes)):
                        # 跳过第一个点，避免在同一帧处添加两次关键帧
                        if i == 0 and orig_frame == anim_end:
                            continue
                            
                        # 计算对应的返程帧号
                        # 它应该是从返程起点开始的相对位置
                        rel_pos = (orig_frame - anim_start) / original_duration
                        return_frame = return_end_frame - int(rel_pos * return_frames)
                        
                        # 根据fc_idx确定是位置还是旋转曲线
                        if fc_idx < len(loc_fcurves):
                            # 位置曲线
                            loc_fcurves[fc_idx].keyframe_points.insert(return_frame, value)
                        else:
                            # 旋转曲线 - 需要考虑方向反转
                            rot_idx = fc_idx - len(loc_fcurves)
                            if rot_idx < len(rot_fcurves):
                                # 如果是旋转方向相关的分量，可能需要调整值
                                # 这里简单复用原值，可能需要根据实际情况调整
                                rot_fcurves[rot_idx].keyframe_points.insert(return_frame, value)
                
                # 确保返程末尾有与起点相同的关键帧
                for fc_idx, fc in enumerate(loc_fcurves):
                    # 查找起始帧的值
                    start_value = None
                    for kp in fc.keyframe_points:
                        if kp.co.x == anim_start:
                            start_value = kp.co.y
                            break
                            
                    if start_value is not None:
                        # 在返程结束处添加与起点相同的关键帧
                        fc.keyframe_points.insert(return_end_frame, start_value)
                
                # 对旋转也做同样处理
                if props.follow_path and rot_fcurves:
                    for fc_idx, fc in enumerate(rot_fcurves):
                        start_value = None
                        for kp in fc.keyframe_points:
                            if kp.co.x == anim_start:
                                start_value = kp.co.y
                                break
                                
                        if start_value is not None:
                            fc.keyframe_points.insert(return_end_frame, start_value)
                
                # 更新结束帧为返程结束帧
                end_frame = return_end_frame
                
                # 对所有关键帧应用线性插值，确保平滑过渡
                for fc in loc_fcurves + rot_fcurves:
                    for kp in fc.keyframe_points:
                        kp.interpolation = 'LINEAR'
                    try:
                        fc.update()
                    except Exception as e:
                        print(f"更新FCurve时出错: {e}")
            
            # 如果设置了循环间隔，需要调整关键帧
            if props.loop_gap > 0 and props.loop_type == 'REPEAT':
                # 需要在动画末尾添加间隔帧 - 保持末尾值不变
                gap_start = end_frame + 1
                gap_end = gap_start + props.loop_gap - 1
                
                # 为位置和旋转添加间隔帧
                for fc in loc_fcurves:
                    # 获取最后一帧的值
                    last_value = None
                    for kp in fc.keyframe_points:
                        if kp.co.x == end_frame:
                            last_value = kp.co.y
                            break
                    
                    if last_value is not None:
                        # 在间隔开始和结束处添加相同值的关键帧
                        fc.keyframe_points.insert(gap_start, last_value)
                        fc.keyframe_points.insert(gap_end, last_value)
                
                # 对旋转也做同样处理
                if props.follow_path:
                    for fc in rot_fcurves:
                        # 获取最后一帧的值
                        last_value = None
                        for kp in fc.keyframe_points:
                            if kp.co.x == end_frame:
                                last_value = kp.co.y
                                break
                        
                        if last_value is not None:
                            # 在间隔开始和结束处添加相同值的关键帧
                            fc.keyframe_points.insert(gap_start, last_value)
                            fc.keyframe_points.insert(gap_end, last_value)
                
                # 更新结束帧
                end_frame = gap_end
            
            # 应用循环修改器到所有F曲线
            # 对于PING_PONG模式，我们已经手动创建了一个完整的来回，只需要在循环次数>1时添加重复修改器
            for fc in loc_fcurves + rot_fcurves:
                # 移除现有循环修改器
                for mod in list(fc.modifiers):
                    if mod.type == 'CYCLES':
                        fc.modifiers.remove(mod)
                
                # 对于PING_PONG，我们已经手动创建了一个完整的来回，只需要在循环次数>1时添加重复修改器
                if props.loop_count > 1 or props.loop_count == 0:  # 大于1次或无限循环
                    mod = fc.modifiers.new('CYCLES')
                    
                    # 无论是什么循环类型，都使用REPEAT模式，因为我们已经手动处理了PING_PONG的来回
                    mod.mode_before = 'REPEAT'
                    mod.mode_after = 'REPEAT'
                    
                    # 设置循环次数 (0表示无限循环)
                    if props.loop_count > 1:
                        # 每个循环单位现在是一次完整的来回(对于PING_PONG)或一次往返(对于REPEAT)
                        cycle_length = end_frame - anim_start
                        
                        # 设置修改器的结束帧，使其在指定次数后停止
                        cycle_range = cycle_length * (props.loop_count - 1)
                        last_frame = anim_start + cycle_range
                        
                        # 这里使用repeat_end参数限制循环范围
                        mod.use_restricted_range = True
                        mod.frame_start = anim_start
                        mod.frame_end = last_frame
            
            # 更新场景结束帧以包含所有循环
            if props.loop_count > 0:
                # 计算单循环长度 - 对于PING_PONG已经包含来回
                cycle_length = end_frame - anim_start
                
                # 计算总帧数：如果循环次数为1，只包含原始动画长度(可能包括PING_PONG的返程)
                if props.loop_count == 1:
                    total_frames = end_frame
                else:
                    # 动画起点 + 一次完整循环 + 额外循环的长度
                    total_frames = anim_start + cycle_length * props.loop_count
                
                # 只有当用户选择了更新时间线选项时，才更新场景的结束帧
                if props.update_timeline:
                    context.scene.frame_end = max(end_frame, total_frames)
                    print(f"场景总帧数已更新: {context.scene.frame_end} (循环 {props.loop_count} 次)")
                else:
                    print(f"建议的场景总帧数: {max(end_frame, total_frames)} (未更新时间线)")
            else:
                # 无限循环，计算建议的时间线长度
                cycle_length = end_frame - anim_start
                suggested_end_frame = anim_start + cycle_length * 3  # 显示3个循环
                
                # 只有当用户选择了更新时间线选项时，才更新场景的结束帧
                if props.update_timeline:
                    context.scene.frame_end = suggested_end_frame
                    print(f"场景总帧数已更新: {context.scene.frame_end} (无限循环)")
                else:
                    print(f"建议的场景总帧数: {suggested_end_frame} (未更新时间线)")
        else:
            # 无循环
            # 只有当用户选择了更新时间线选项时，才更新场景的结束帧
            if props.update_timeline:
                context.scene.frame_end = end_frame
                print(f"场景总帧数已更新: {end_frame} (无循环)")
            else:
                print(f"建议的场景总帧数: {end_frame} (未更新时间线)")
        
        # 8. 设置场景帧范围和收尾
        if props.update_timeline:
            context.scene.frame_start = start_frame
        context.scene.frame_current = start_frame
        
        context.view_layer.objects.active = active_obj
        active_obj.select_set(True)
        
        # 更新视图
        if context.screen:
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        # 恢复此前活动对象，避免破坏用户选择上下文
        if old_active and old_active.name in bpy.data.objects:
            context.view_layer.objects.active = old_active
        
        print("--- 路径动画创建完成 ---")
        if is_armature:
            self.report({'INFO'}, f"已为骨架 {active_obj.name} 创建沿贝塞尔路径的精确动画")
        else:
            self.report({'INFO'}, f"已为 {active_obj.name} 创建沿贝塞尔路径的精确动画")
        return {'FINISHED'}
    
    def evaluate_bezier_curve(self, p0, p1, p2, p3, t):
        """
        计算贝塞尔曲线上的点和切线
        p0, p1, p2, p3: 四个控制点
        t: 参数 (0-1)
        返回: (位置, 切线方向)
        """
        import mathutils
        
        # 点的计算
        mt = 1 - t
        mt2 = mt * mt
        mt3 = mt2 * mt
        t2 = t * t
        t3 = t2 * t
        
        # 贝塞尔公式计算坐标
        point = mt3 * p0 + 3 * mt2 * t * p1 + 3 * mt * t2 * p2 + t3 * p3
        
        # 切线的计算 (导数)
        tangent = 3 * mt2 * (p1 - p0) + 6 * mt * t * (p2 - p1) + 3 * t2 * (p3 - p2)
        
        return point, tangent

class ANIM_PT_PathAnimation(bpy.types.Panel):
    bl_label = "路径动画工具"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "动画工具"
    
    @classmethod
    def poll(cls, context):
        # 只在active_panel为PATH时显示面板
        return context.scene.anim_merge_props.active_panel == 'PATH'
    
    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        props = context.scene.path_anim_props

        curve_obj = props.curve_object if _is_valid_object(props.curve_object) else None
        target_obj = _resolve_path_target(props, context)
        active_obj = context.active_object
        active_is_curve = bool(active_obj and curve_obj and active_obj.name == curve_obj.name)

        status_box = layout.box()
        status_box.label(text="当前状态", icon='INFO')
        if target_obj:
            icon = 'ARMATURE_DATA' if target_obj.type == 'ARMATURE' else 'OBJECT_DATA'
            status_box.label(text=f"目标对象: {target_obj.name}", icon=icon)
        else:
            status_box.label(text="目标对象: 未指定", icon='ERROR')

        if curve_obj:
            status_box.label(text=f"路径曲线: {curve_obj.name}", icon='CURVE_BEZCURVE')
        else:
            status_box.label(text="路径曲线: 未创建", icon='INFO')
        if active_obj:
            status_box.label(text=f"当前选中: {active_obj.name}", icon='RESTRICT_SELECT_OFF')
        else:
            status_box.label(text="当前选中: 无", icon='ERROR')

        target_row = status_box.row(align=True)
        target_row.prop(props, "target_object", text="目标")
        set_row = status_box.row(align=True)
        set_row.enabled = bool(active_obj) and not active_is_curve
        set_row.operator(ANIM_OT_SetPathTarget.bl_idname, icon='RESTRICT_SELECT_OFF')

        create_row = layout.row(align=True)
        create_row.scale_y = 1.2
        create_row.enabled = bool(active_obj) and not active_is_curve
        create_row.operator(ANIM_OT_CreateBezierPath.bl_idname, text="创建/重建贝塞尔路径", icon='CURVE_BEZCURVE')
        if active_is_curve:
            layout.label(text="当前选中是路径曲线，请先选中目标对象", icon='ERROR')

        # 当曲线已创建时显示设置
        if curve_obj:
            box = layout.box()
            box.label(text="曲线设置", icon='SETTINGS')
            
            # 控制点数量和应用按钮
            row = box.row(align=True)
            row.prop(props, "control_points", text="控制点数量")
            apply_cp_row = box.row(align=True)
            apply_cp_row.enabled = props.control_points != props.applied_control_points
            apply_cp_row.operator("anim.apply_control_points", text="应用控制点数量", icon='CURVE_BEZCIRCLE')
            
            # 帧范围设置
            col = box.column(align=True)
            row = col.row(align=True)
            row.prop(props, "frame_start", text="开始")
            row.prop(props, "frame_end", text="结束")
            
            # 添加时间线更新选项
            row = box.row()
            row.prop(props, "update_timeline", text="更新场景时间线范围")
            
            # 速度设置
            row = box.row()
            row.prop(props, "speed_factor", text="速度因子")
            row = box.row()
            row.prop(props, "interpolation_type", text="速度变化")
            
            # 是否旋转
            row = box.row()
            row.prop(props, "follow_path")
            
            # 循环设置
            box_loop = box.box()
            row = box_loop.row()
            row.label(text="循环设置:", icon='LOOP_FORWARDS')
            row = box_loop.row()
            row.prop(props, "loop_type", text="")
            
            # 只有选择了循环类型才显示相关选项
            if props.loop_type != 'NONE':
                row = box_loop.row()
                row.prop(props, "loop_count", text="循环次数")
                
                if props.loop_type == 'REPEAT':
                    row = box_loop.row()
                    row.prop(props, "loop_gap", text="循环间隔")

            if props.frame_end > props.frame_start:
                base_duration = props.frame_end - props.frame_start
                adjusted_duration = max(1, int(base_duration / max(0.01, props.speed_factor)))
                preview_box = box.box()
                preview_box.label(text=f"原始时长: {base_duration} 帧", icon='TIME')
                preview_box.label(text=f"速度修正后时长: {adjusted_duration} 帧", icon='MOD_TIME')
            
            # 应用动画按钮
            apply_row = layout.row()
            apply_row.scale_y = 1.5
            apply_row.enabled = target_obj is not None and props.frame_end > props.frame_start
            apply_row.operator("anim.apply_path_animation", text="应用路径动画", icon='PLAY')
            if target_obj is None:
                layout.label(text="请先指定目标对象", icon='ERROR')
            elif props.frame_end <= props.frame_start:
                layout.label(text="结束帧必须大于起始帧", icon='ERROR')

class ANIM_OT_ApplyControlPoints(bpy.types.Operator):
    bl_idname = "anim.apply_control_points"
    bl_label = "应用控制点"
    bl_description = "应用新的控制点数量到当前曲线"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        props = context.scene.path_anim_props
        return (props.curve_object and 
                props.curve_object.name in bpy.data.objects and
                props.control_points != props.applied_control_points)
    
    def execute(self, context):
        props = context.scene.path_anim_props
        curve_obj = props.curve_object
        
        # 确保曲线对象有效
        if not curve_obj or curve_obj.name not in bpy.data.objects:
            self.report({'ERROR'}, "找不到曲线对象")
            return {'CANCELLED'}
        
        # 确保曲线对象是曲线类型
        if curve_obj.type != 'CURVE':
            self.report({'ERROR'}, "选择的对象不是曲线")
            return {'CANCELLED'}
        
        # 获取当前活动对象
        active_obj = context.active_object
        
        # 选择曲线对象
        for obj in context.selected_objects:
            obj.select_set(False)
        curve_obj.select_set(True)
        context.view_layer.objects.active = curve_obj
        
        # 确保处于对象模式
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # 获取曲线数据和第一条样条线
        curve_data = curve_obj.data
        if len(curve_data.splines) == 0:
            self.report({'ERROR'}, "曲线没有样条线")
            return {'CANCELLED'}
        
        spline = curve_data.splines[0]
        if spline.type != 'BEZIER':
            self.report({'ERROR'}, "只支持贝塞尔样条线")
            return {'CANCELLED'}
        
        current_points = len(spline.bezier_points)
        target_points = props.control_points
        
        # 记录当前点的位置和手柄
        current_data = []
        for i, point in enumerate(spline.bezier_points):
            current_data.append({
                'co': tuple(point.co),
                'handle_left': tuple(point.handle_left),
                'handle_right': tuple(point.handle_right),
                'handle_left_type': point.handle_left_type,
                'handle_right_type': point.handle_right_type
            })
        
        # 根据是增加还是减少点进行操作
        if target_points > current_points:
            # 增加点
            spline.bezier_points.add(target_points - current_points)
            
            # 重新分配点的位置
            for i in range(target_points):
                # 使用线性插值计算新点的位置
                old_index = (i * (current_points - 1)) / (target_points - 1) if target_points > 1 else 0
                
                idx1 = int(old_index)
                idx2 = min(idx1 + 1, current_points - 1)
                frac = old_index - idx1
                
                # 使用之前保存的数据进行线性插值
                if idx1 == idx2 or frac < 0.001:
                    # 如果是相同的点或者非常接近，直接使用第一个点的数据
                    spline.bezier_points[i].co = current_data[idx1]['co']
                    spline.bezier_points[i].handle_left = current_data[idx1]['handle_left']
                    spline.bezier_points[i].handle_right = current_data[idx1]['handle_right']
                    spline.bezier_points[i].handle_left_type = current_data[idx1]['handle_left_type']
                    spline.bezier_points[i].handle_right_type = current_data[idx1]['handle_right_type']
                else:
                    # 否则进行线性插值
                    # 位置的线性插值
                    co1 = mathutils.Vector(current_data[idx1]['co'])
                    co2 = mathutils.Vector(current_data[idx2]['co'])
                    spline.bezier_points[i].co = co1.lerp(co2, frac)
                    
                    # 手柄的线性插值
                    left1 = mathutils.Vector(current_data[idx1]['handle_left'])
                    left2 = mathutils.Vector(current_data[idx2]['handle_left'])
                    spline.bezier_points[i].handle_left = left1.lerp(left2, frac)
                    
                    right1 = mathutils.Vector(current_data[idx1]['handle_right'])
                    right2 = mathutils.Vector(current_data[idx2]['handle_right'])
                    spline.bezier_points[i].handle_right = right1.lerp(right2, frac)
                    
                    # 设置手柄类型为FREE，允许更灵活的编辑
                    spline.bezier_points[i].handle_left_type = 'FREE'
                    spline.bezier_points[i].handle_right_type = 'FREE'
        
        elif target_points < current_points:
            # 减少点 - 需要先创建一个新的样条替换旧样条
            # 获取重采样后的位置
            resampled_data = []
            for i in range(target_points):
                old_index = (i * (current_points - 1)) / (target_points - 1) if target_points > 1 else 0
                idx1 = int(old_index)
                idx2 = min(idx1 + 1, current_points - 1)
                frac = old_index - idx1
                
                if idx1 == idx2 or frac < 0.001:
                    resampled_data.append(current_data[idx1])
                else:
                    # 进行线性插值
                    co1 = mathutils.Vector(current_data[idx1]['co'])
                    co2 = mathutils.Vector(current_data[idx2]['co'])
                    
                    left1 = mathutils.Vector(current_data[idx1]['handle_left'])
                    left2 = mathutils.Vector(current_data[idx2]['handle_left'])
                    
                    right1 = mathutils.Vector(current_data[idx1]['handle_right'])
                    right2 = mathutils.Vector(current_data[idx2]['handle_right'])
                    
                    resampled_data.append({
                        'co': co1.lerp(co2, frac),
                        'handle_left': left1.lerp(left2, frac),
                        'handle_right': right1.lerp(right2, frac),
                        'handle_left_type': 'FREE',
                        'handle_right_type': 'FREE'
                    })
            
            # 删除旧样条并创建新样条
            curve_data.splines.remove(spline)
            new_spline = curve_data.splines.new(type='BEZIER')
            
            # 添加足够数量的点
            if target_points > 1:
                new_spline.bezier_points.add(target_points - 1)
            
            # 设置新样条上的点位置和手柄
            for i, point_data in enumerate(resampled_data):
                new_spline.bezier_points[i].co = point_data['co']
                new_spline.bezier_points[i].handle_left = point_data['handle_left']
                new_spline.bezier_points[i].handle_right = point_data['handle_right']
                new_spline.bezier_points[i].handle_left_type = point_data['handle_left_type']
                new_spline.bezier_points[i].handle_right_type = point_data['handle_right_type']
        
        # 更新已应用的控制点数量
        props.applied_control_points = props.control_points
        
        # 进入编辑模式
        bpy.ops.object.mode_set(mode='EDIT')
        
        return {'FINISHED'}

# 在PathAnimationProperties类下方添加新的属性组
