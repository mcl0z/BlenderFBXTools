from .core_base import *


def _set_library_message(props, message):
    props.library_last_message = message


def _refresh_library_view(context, target_filepath=None, target_name=None):
    load_library_actions()
    props = context.scene.anim_merge_props
    props.show_library = True
    props.active_panel = 'LIBRARY'

    items = props.action_library_items
    if not items:
        props.action_library_index = 0
        return

    target_idx = None
    target_path_str = str(target_filepath) if target_filepath else None
    if target_path_str:
        for i, it in enumerate(items):
            if it.filepath == target_path_str:
                target_idx = i
                break
    if target_idx is None and target_name:
        for i, it in enumerate(items):
            if it.name == target_name:
                target_idx = i
                break
    if target_idx is None:
        target_idx = min(props.action_library_index, len(items) - 1)
    props.action_library_index = max(0, target_idx)


# Library import/export and FBX merge operators.
class ANIM_OT_SaveCustomAction(bpy.types.Operator):
    bl_idname = "anim.save_custom_action"
    bl_label = "保存自定义动画"
    bl_options = {'REGISTER', 'UNDO'}
    
    name: bpy.props.StringProperty(name="动画名称", default="自定义动画")
    start_frame: bpy.props.IntProperty(name="起始帧", default=1, min=0)
    end_frame: bpy.props.IntProperty(name="结束帧", default=250, min=1)
    
    def execute(self, context):
        target = context.active_object
        if not target or target.type != 'ARMATURE' or not target.animation_data or not target.animation_data.action:
            self.report({'ERROR'}, "请选骨架")
            return {'CANCELLED'}
        
        original_action = target.animation_data.action
        new_action = original_action.copy()
        new_action.name = self.name

        for fcurve in new_action.fcurves:
            keyframes = []
            for kp in fcurve.keyframe_points:
                if self.start_frame <= kp.co.x <= self.end_frame:
                    keyframes.append((kp.co.x, kp.co.y, kp.interpolation))
            
            fcurve.keyframe_points.clear()
            for frame, value, interp in keyframes:
                kp = fcurve.keyframe_points.insert(frame, value)
                kp.interpolation = interp
            fcurve.update()

        safe_name = clean_filename(new_action.name)
        fbx_stem = "Custom_Actions"
        save_dir = LIBRARY_PATH / fbx_stem
        save_dir.mkdir(exist_ok=True)
        save_path = save_dir / f"{safe_name}.json"
        counter = 1
        while save_path.exists():
            save_path = save_dir / f"{safe_name}_{counter}.json"
            counter += 1

        serialize_action(new_action, save_path)
        action_name = new_action.name

        props = context.scene.anim_merge_props
        _refresh_library_view(context, target_filepath=save_path, target_name=action_name)
        _set_library_message(
            props,
            f"已保存动作: {action_name}  ({self.start_frame}-{self.end_frame})",
        )

        bpy.data.actions.remove(new_action)
        self.report({'INFO'}, f"OK: {self.name}")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        if context.active_object and context.active_object.animation_data and context.active_object.animation_data.action:
            action = context.active_object.animation_data.action
            self.name = action.name
            frames = []
            for fcurve in action.fcurves:
                frames.extend([kp.co.x for kp in fcurve.keyframe_points])
            if frames:
                self.start_frame = int(min(frames))
                self.end_frame = int(max(frames))
        return context.window_manager.invoke_props_dialog(self, width=300)
        
    def draw(self, context):
        layout = self.layout
        layout.label(text="保存动作到库", icon='FILE_TICK')
        layout.separator()
        
        layout.prop(self, "name", icon='ACTION')
        
        frame_row = layout.row(align=True)
        frame_row.label(text="帧范围:")
        frame_row.prop(self, "start_frame", text="从")
        frame_row.prop(self, "end_frame", text="到")
        
        layout.separator()
        layout.label(text="动作将存储在自定义动作库中", icon='INFO')

class ANIM_OT_ImportToLibrary(bpy.types.Operator):
    bl_idname = "anim.import_to_library"
    bl_label = "导入动作"
    bl_options = {'REGISTER', 'UNDO'}
    
    filter_glob: bpy.props.StringProperty(default="*.fbx", options={'HIDDEN'})
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    
    def execute(self, context):
        action = load_fbx_animation(self.filepath)
        if not action:
            self.report({'ERROR'}, "无效!!!")
            return {'CANCELLED'}
        action_name = action.name
        safe_name = clean_filename(action_name)
        fbx_stem = clean_filename(Path(self.filepath).stem)

        save_dir = LIBRARY_PATH / fbx_stem
        save_dir.mkdir(exist_ok=True)
        save_path = save_dir / f"{safe_name}.json"
        counter = 1
        while save_path.exists():
            save_path = save_dir / f"{safe_name}_{counter}.json"
            counter += 1
        frames = []
        for fcurve in action.fcurves:
            frames.extend([kp.co.x for kp in fcurve.keyframe_points])
        frame_range = (int(min(frames)), int(max(frames))) if frames else (1, 250)
        serialize_action(action, save_path)

        props = context.scene.anim_merge_props
        _refresh_library_view(context, target_filepath=save_path, target_name=action_name)
        _set_library_message(
            props,
            f"已导入FBX动作: {action_name}  ({frame_range[0]}-{frame_range[1]})",
        )

        bpy.data.actions.remove(action)
        self.report({'INFO'}, f"已保存: {action_name}")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class ANIM_OT_UseLibraryAction(bpy.types.Operator):
    bl_idname = "anim.use_library_action"
    bl_label = "应用动作"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.anim_merge_props
        if not props.action_library_items:
            self.report({'ERROR'}, "你没资产")
            return {'CANCELLED'}
        item = props.action_library_items[props.action_library_index]
        target = context.active_object
        if not target or target.type != 'ARMATURE':
            self.report({'ERROR'}, "选骨架!!!")
            return {'CANCELLED'}
        props.source_start = item.frame_range[0]
        props.source_end = item.frame_range[1]
        
        # 设置标记，表示来自库
        props.is_from_library = True
        
        # 填充骨骼选择列表
        context.scene.bone_selection.clear()
        for bone in target.data.bones:
            item = context.scene.bone_selection.add()
            item.name = bone.name
            item.selected = True
        
        # 打开骨骼选择对话框
        bpy.ops.anim.select_bones('INVOKE_DEFAULT')
        return {'FINISHED'}

class ANIM_OT_UseLibraryActionWithBones(bpy.types.Operator):
    bl_idname = "anim.use_library_action_with_bones"
    bl_label = "带骨骼过滤的应用动作"
    bl_options = {'REGISTER', 'UNDO'}
    
    selected_bones: bpy.props.StringProperty(default="")
    bone_mapping: bpy.props.StringProperty(default="")
    
    def execute(self, context):
        props = context.scene.anim_merge_props
        if not props.action_library_items:
            self.report({'ERROR'}, "你没资产")
            return {'CANCELLED'}
        item = props.action_library_items[props.action_library_index]
        action = deserialize_action(Path(item.filepath))
        if not action:
            self.report({'ERROR'}, "动作加载失败")
            return {'CANCELLED'}
        target = context.active_object
        if not target or target.type != 'ARMATURE':
            self.report({'ERROR'}, "选骨架!!!")
            return {'CANCELLED'}
        
        # 解析选中的骨骼
        selected_bones = self.selected_bones.split(',') if self.selected_bones else []
        if not selected_bones:
            for bone_item in context.scene.bone_selection:
                if bone_item.selected:
                    selected_bones.append(bone_item.name)
        
        # 解析骨骼映射
        bone_mapping = {}
        if self.bone_mapping:
            try:
                bone_mapping = json.loads(self.bone_mapping)
                print(f"成功解析骨骼映射: {bone_mapping}")
            except Exception as e:
                self.report({'WARNING'}, f"骨骼映射解析失败: {str(e)}")
                print(f"骨骼映射解析失败: {str(e)}")
                print(f"原始映射数据: {self.bone_mapping}")
                bone_mapping = {}
        
        # 打印调试信息
        print("\n===== 动作应用前的调试信息 =====")
        print(f"选中的骨骼: {selected_bones}")
        print(f"骨骼映射: {bone_mapping}")
        print(f"启用骨骼映射: {props.enable_bone_mapping}")
        
        # 分析源动作
        print("\n源动作中的骨骼路径:")
        source_bones = set()
        for fcurve in action.fcurves:
            if "pose.bones" in fcurve.data_path:
                match = re.search(r'pose\.bones\["([^"]+)"\]', fcurve.data_path)
                if match:
                    bone_name = match.group(1)
                    source_bones.add(bone_name)
                    
        print(f"源动作中的骨骼: {sorted(list(source_bones))}")
        print("===== 动作应用前的调试信息结束 =====\n")
        
        # 根据选中的骨骼筛选fcurves
        if selected_bones:
            # 创建一个新动作，只包含选中骨骼的数据
            filtered_action = bpy.data.actions.new(name=f"{action.name}_filtered")
            
            # 调试计数器
            applied_curves = 0
            
            for fcurve in action.fcurves:
                # 检查数据路径是否属于选中的骨骼或是物体级别的动画
                is_selected = False
                mapped_path = fcurve.data_path
                
                # 处理骨骼级别的动画曲线
                if "pose.bones" in fcurve.data_path:
                    # 提取骨骼名称
                    match = re.search(r'pose\.bones\["([^"]+)"\]', fcurve.data_path)
                    if match:
                        bone_name = match.group(1)  # 源文件中的骨骼名
                        
                        # 详细调试信息
                        print(f"\n处理曲线 - 骨骼名: {bone_name}, 路径: {fcurve.data_path}")
                        
                        # 判断是否启用骨骼映射
                        if props.enable_bone_mapping and bone_mapping:
                            # 1. 检查源骨骼是否有映射
                            if bone_name in bone_mapping:
                                # 这里是关键修改: 先确定目标骨骼名称
                                target_bone = bone_mapping[bone_name]  # 映射后的目标骨骼名
                                print(f"  应用映射: {bone_name} -> {target_bone}")
                                
                                # 检查目标骨骼是否存在于选中骨骼中
                                is_selected = True  # 如果有映射，总是应用
                                                                
                                # 修改数据路径
                                mapped_path = fcurve.data_path.replace(
                                    f'pose.bones["{bone_name}"]',
                                    f'pose.bones["{target_bone}"]'
                                )
                                print(f"  修改路径: {fcurve.data_path} -> {mapped_path}")
                            else:
                                # 如果没有映射, 则源骨骼名和目标骨骼名相同
                                print(f"  无映射, 检查是否选中: {bone_name in selected_bones}")
                                is_selected = bone_name in selected_bones
                        else:
                            # 不使用映射时，使用原始骨骼名
                            print(f"  不使用映射, 检查是否选中: {bone_name in selected_bones}")
                            is_selected = bone_name in selected_bones
                else:
                    # 物体级别的动画曲线始终保留
                    print(f"  物体级动画曲线: {fcurve.data_path}")
                    is_selected = True
                
                # 如果是选中的骨骼或物体级动画，添加到过滤后的动作
                if is_selected:
                    try:
                        new_curve = filtered_action.fcurves.new(
                            mapped_path, 
                            index=fcurve.array_index
                        )
                        for kp in fcurve.keyframe_points:
                            new_kp = new_curve.keyframe_points.insert(kp.co.x, kp.co.y)
                            new_kp.interpolation = kp.interpolation
                        
                        applied_curves += 1
                        print(f"  成功添加曲线: {mapped_path}[{fcurve.array_index}]")
                    except Exception as e:
                        print(f"  添加曲线失败: {mapped_path}[{fcurve.array_index}], 错误: {str(e)}")
            
            # 使用过滤后的动作进行连续应用
            print(f"\n应用了 {applied_curves} 条曲线")
            
            if applied_curves == 0:
                print("警告: 没有应用任何动画曲线!")
                self.report({'WARNING'}, "没有应用任何动画曲线，请检查骨骼选择和映射")
            
            merged_action, applied_ranges = apply_action_sequence(
                target.animation_data.action if target.animation_data else None,
                filtered_action,
                props.target_start,
                (props.source_start, props.source_end),
                props.merge_mode,
                props.loop_times,
                props.apply_transform,
                target
            )
                
            # 清理临时动作
            bpy.data.actions.remove(filtered_action)
        else:
            # 如果没有选中骨骼，按原来的方式处理
            merged_action, applied_ranges = apply_action_sequence(
                target.animation_data.action if target.animation_data else None,
                action,
                props.target_start,
                (props.source_start, props.source_end),
                props.merge_mode,
                props.loop_times,
                props.apply_transform,
                target
            )
                
        # 应用合并后的动作
        if not target.animation_data:
            target.animation_data_create()
        target.animation_data.action = merged_action
        
        # 更新场景帧范围，确保能看到所有动画
        if applied_ranges:
            context.scene.frame_end = max(
                context.scene.frame_end,
                applied_ranges[-1][1]  # 最后一个范围的结束帧
            )
        
        # 清理原始动作
        bpy.data.actions.remove(action)
        
        self.report({'INFO'}, f"OK: {item.name} 已连续应用 {props.loop_times} 次")
        return {'FINISHED'}

class ANIM_OT_MergeFBX(bpy.types.Operator):
    bl_idname = "anim.merge_fbx"
    bl_label = "合并FBX动画至你的骨骼"
    bl_options = {'REGISTER', 'UNDO'}

    filter_glob: bpy.props.StringProperty(default="*.fbx", options={'HIDDEN'})
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    
    def execute(self, context):
        props = context.scene.anim_merge_props
        target = context.active_object
        
        if not target or target.type != 'ARMATURE':
            self.report({'ERROR'}, "请选择目标骨架")
            return {'CANCELLED'}
        
        # 保存文件路径
        props.filepath = self.filepath
        # 设置标记，表示不是来自库
        props.is_from_library = False
        
        # 填充骨骼选择列表
        context.scene.bone_selection.clear()
        for bone in target.data.bones:
            item = context.scene.bone_selection.add()
            item.name = bone.name
            item.selected = True
        
        # 打开骨骼选择对话框
        bpy.ops.anim.select_bones('INVOKE_DEFAULT')
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class ANIM_OT_ExecuteMergeFromSource(bpy.types.Operator):
    bl_idname = "anim.execute_merge_from_source"
    bl_label = "按动作库选中动画执行合并"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        target = context.active_object
        return bool(target and target.type == 'ARMATURE')

    def execute(self, context):
        props = context.scene.anim_merge_props
        target = context.active_object

        if not target or target.type != 'ARMATURE':
            self.report({'ERROR'}, "请选择目标骨架")
            return {'CANCELLED'}

        if not props.action_library_items:
            self.report({'ERROR'}, "动作库为空，请先导入动作")
            return {'CANCELLED'}
        if not (0 <= props.action_library_index < len(props.action_library_items)):
            self.report({'ERROR'}, "请选择一个有效的动作库动作")
            return {'CANCELLED'}

        lib_item = props.action_library_items[props.action_library_index]
        lib_path = Path(lib_item.filepath)
        if not lib_item.filepath or not lib_path.exists():
            self.report({'ERROR'}, "选中动作文件不存在，请重新导入或删除该条目")
            return {'CANCELLED'}

        props.source_start = int(lib_item.frame_range[0])
        props.source_end = int(lib_item.frame_range[1])
        props.is_from_library = True
        self.report({'INFO'}, f"来源动作: {lib_item.name}")

        bpy.ops.anim.select_bones('INVOKE_DEFAULT')
        return {'FINISHED'}

class ANIM_OT_MergeFBXWithBones(bpy.types.Operator):
    bl_idname = "anim.merge_fbx_with_bones"
    bl_label = "带骨骼过滤的合并FBX"
    bl_options = {'REGISTER', 'UNDO'}
    
    selected_bones: bpy.props.StringProperty(default="")
    bone_mapping: bpy.props.StringProperty(default="")
    
    def execute(self, context):
        props = context.scene.anim_merge_props
        target = context.active_object
        
        if not target or target.type != 'ARMATURE':
            self.report({'ERROR'}, "请选择目标骨架")
            return {'CANCELLED'}
        
        action = load_fbx_animation(props.filepath)
        if not action:
            self.report({'ERROR'}, "读取失败")
            return {'CANCELLED'}
            
        # 解析选中的骨骼
        selected_bones = self.selected_bones.split(',') if self.selected_bones else []
        if not selected_bones:
            for bone_item in context.scene.bone_selection:
                if bone_item.selected:
                    selected_bones.append(bone_item.name)
        
        # 解析骨骼映射
        bone_mapping = {}
        if self.bone_mapping:
            try:
                bone_mapping = json.loads(self.bone_mapping)
                print(f"成功解析骨骼映射: {bone_mapping}")
            except Exception as e:
                self.report({'WARNING'}, f"骨骼映射解析失败: {str(e)}")
                print(f"骨骼映射解析失败: {str(e)}")
                print(f"原始映射数据: {self.bone_mapping}")
                bone_mapping = {}
        
        # 打印调试信息
        print("\n===== 动作应用前的调试信息 =====")
        print(f"选中的骨骼: {selected_bones}")
        print(f"骨骼映射: {bone_mapping}")
        print(f"启用骨骼映射: {props.enable_bone_mapping}")
        
        # 分析源动作
        print("\n源动作中的骨骼路径:")
        source_bones = set()
        for fcurve in action.fcurves:
            if "pose.bones" in fcurve.data_path:
                match = re.search(r'pose\.bones\["([^"]+)"\]', fcurve.data_path)
                if match:
                    bone_name = match.group(1)
                    source_bones.add(bone_name)
                    
        print(f"源动作中的骨骼: {sorted(list(source_bones))}")
        print("===== 动作应用前的调试信息结束 =====\n")
        
        # 根据选中的骨骼筛选fcurves
        if selected_bones:
            # 创建一个新动作，只包含选中骨骼的数据
            filtered_action = bpy.data.actions.new(name=f"{action.name}_filtered")
            
            # 调试计数器
            applied_curves = 0
            
            for fcurve in action.fcurves:
                # 检查数据路径是否属于选中的骨骼或是物体级别的动画
                is_selected = False
                mapped_path = fcurve.data_path
                
                # 处理骨骼级别的动画曲线
                if "pose.bones" in fcurve.data_path:
                    # 提取骨骼名称
                    match = re.search(r'pose\.bones\["([^"]+)"\]', fcurve.data_path)
                    if match:
                        bone_name = match.group(1)  # 源文件中的骨骼名
                        
                        # 详细调试信息
                        print(f"\n处理曲线 - 骨骼名: {bone_name}, 路径: {fcurve.data_path}")
                        
                        # 判断是否启用骨骼映射
                        if props.enable_bone_mapping and bone_mapping:
                            # 1. 检查源骨骼是否有映射
                            if bone_name in bone_mapping:
                                # 这里是关键修改: 先确定目标骨骼名称
                                target_bone = bone_mapping[bone_name]  # 映射后的目标骨骼名
                                print(f"  应用映射: {bone_name} -> {target_bone}")
                                
                                # 检查目标骨骼是否存在于选中骨骼中
                                is_selected = True  # 如果有映射，总是应用
                                                                
                                # 修改数据路径
                                mapped_path = fcurve.data_path.replace(
                                    f'pose.bones["{bone_name}"]',
                                    f'pose.bones["{target_bone}"]'
                                )
                                print(f"  修改路径: {fcurve.data_path} -> {mapped_path}")
                            else:
                                # 如果没有映射, 则源骨骼名和目标骨骼名相同
                                print(f"  无映射, 检查是否选中: {bone_name in selected_bones}")
                                is_selected = bone_name in selected_bones
                        else:
                            # 不使用映射时，使用原始骨骼名
                            print(f"  不使用映射, 检查是否选中: {bone_name in selected_bones}")
                            is_selected = bone_name in selected_bones
                else:
                    # 物体级别的动画曲线始终保留
                    print(f"  物体级动画曲线: {fcurve.data_path}")
                    is_selected = True
                
                # 如果是选中的骨骼或物体级动画，添加到过滤后的动作
                if is_selected:
                    try:
                        new_curve = filtered_action.fcurves.new(
                            mapped_path, 
                            index=fcurve.array_index
                        )
                        for kp in fcurve.keyframe_points:
                            new_kp = new_curve.keyframe_points.insert(kp.co.x, kp.co.y)
                            new_kp.interpolation = kp.interpolation
                        
                        applied_curves += 1
                        print(f"  成功添加曲线: {mapped_path}[{fcurve.array_index}]")
                    except Exception as e:
                        print(f"  添加曲线失败: {mapped_path}[{fcurve.array_index}], 错误: {str(e)}")
            
            # 使用过滤后的动作进行连续应用
            print(f"\n应用了 {applied_curves} 条曲线")
            
            if applied_curves == 0:
                print("警告: 没有应用任何动画曲线!")
                self.report({'WARNING'}, "没有应用任何动画曲线，请检查骨骼选择和映射")
            
            merged_action, applied_ranges = apply_action_sequence(
                target.animation_data.action if target.animation_data else None,
                filtered_action,
                props.target_start,
                (props.source_start, props.source_end),
                props.merge_mode,
                props.loop_times,
                props.apply_transform,
                target
            )
                
            # 清理临时动作
            bpy.data.actions.remove(filtered_action)
        else:
            # 如果没有选中骨骼，按原来的方式处理
            merged_action, applied_ranges = apply_action_sequence(
                target.animation_data.action if target.animation_data else None,
                action,
                props.target_start,
                (props.source_start, props.source_end),
                props.merge_mode,
                props.loop_times,
                props.apply_transform,
                target
            )
                
        # 应用合并后的动作
        if not target.animation_data:
            target.animation_data_create()
        target.animation_data.action = merged_action
        
        # 更新场景帧范围，确保能看到所有动画
        if applied_ranges:
            context.scene.frame_end = max(
                context.scene.frame_end,
                applied_ranges[-1][1]  # 最后一个范围的结束帧
            )
        
        # 清理原始动作
        bpy.data.actions.remove(action)
        
        self.report({'INFO'}, f"合并完成! 已连续应用 {props.loop_times} 次")
        return {'FINISHED'}

class ANIM_OT_SelectBones(bpy.types.Operator):
    bl_idname = "anim.select_bones"
    bl_label = "选择要复制的骨骼"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # 操作完成后继续执行动作合并
        if hasattr(context.scene, "bone_selection"):
            bone_selection = context.scene.bone_selection
            props = context.scene.anim_merge_props
            
            # 打印骨骼选择情况
            print("\n===== 骨骼选择和映射信息 =====")
            
            # 筛选选中的骨骼
            selected_bones = [item.name for item in bone_selection if item.selected]
            print(f"选中的骨骼数量: {len(selected_bones)}")
            
            # 判断是否有选中的骨骼
            if not selected_bones:
                self.report({'INFO'}, "未选择任何骨骼，操作已取消")
                return {'CANCELLED'}
            
            # 获取映射信息(如果启用)
            bone_mapping = {}
            if context.scene.anim_merge_props.enable_bone_mapping:
                print(f"启用了骨骼映射")
                for item in bone_selection:
                    print(f"骨骼项: {item.name}, 选中: {item.selected}, 启用映射: {item.use_mapping}, 映射到: {item.mapped_to}")
                    if item.selected and item.use_mapping and item.mapped_to:
                        # 在启用骨骼映射时，将源骨骼映射到目标骨骼
                        # item.name现在是源文件中的骨骼名称
                        bone_mapping[item.name] = item.mapped_to
                        print(f"添加映射: {item.name} -> {item.mapped_to}")
            
            # 将骨骼列表转换为逗号分隔的字符串
            selected_bones_str = ",".join(selected_bones)
            
            # 将映射信息转换为JSON字符串
            mapping_json = json.dumps(bone_mapping) if bone_mapping else ""
            print(f"最终映射数据: {mapping_json}")
            print(f"启用骨骼映射: {props.enable_bone_mapping}")
            print("===== 骨骼选择和映射信息结束 =====\n")
            
            # 传递选中的骨骼和映射信息到合并函数
            if context.scene.anim_merge_props.is_from_library:
                bpy.ops.anim.use_library_action_with_bones('EXEC_DEFAULT', 
                                                         selected_bones=selected_bones_str,
                                                         bone_mapping=mapping_json)
            else:
                bpy.ops.anim.merge_fbx_with_bones('EXEC_DEFAULT', 
                                                selected_bones=selected_bones_str,
                                                bone_mapping=mapping_json)
                
        return {'FINISHED'}
    
    def invoke(self, context, event):
        props = context.scene.anim_merge_props
        
        # 清空骨骼选择列表
        context.scene.bone_selection.clear()
        
        # 如果启用骨骼映射，获取源文件中的骨骼列表
        if props.enable_bone_mapping:
            # 使用共用函数加载源骨骼
            source_bones = load_source_bones(context, props)
            
            # 如果成功获取到源骨骼，添加到选择列表
            if source_bones:
                for bone_name in sorted(source_bones):
                    item = context.scene.bone_selection.add()
                    item.name = bone_name
                    item.selected = True
                    # 默认不启用映射
                    item.use_mapping = False
                    item.mapped_to = ""
            else:
                # 如果没有获取到源骨骼，使用当前骨架的骨骼
                self.report({'WARNING'}, "未找到源文件中的骨骼，将使用当前骨架的骨骼")
                active_obj = context.active_object
                if active_obj and active_obj.type == 'ARMATURE':
                    for bone in active_obj.data.bones:
                        item = context.scene.bone_selection.add()
                        item.name = bone.name
                        item.selected = True
                        item.use_mapping = False
                        item.mapped_to = ""
        else:
            # 不启用骨骼映射时，使用当前骨架的骨骼
            active_obj = context.active_object
            if active_obj and active_obj.type == 'ARMATURE':
                for bone in active_obj.data.bones:
                    item = context.scene.bone_selection.add()
                    item.name = bone.name
                    item.selected = True
                    item.use_mapping = False
                    item.mapped_to = ""
        
        return context.window_manager.invoke_props_dialog(self, width=450)
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.anim_merge_props
        
        # 判断是否有骨骼可选
        has_bones = len(context.scene.bone_selection) > 0
        
        if props.enable_bone_mapping:
            title = "选择要映射的源骨骼:"
        else:
            title = "选择要复制动画的骨骼:"
            
        layout.label(text=title, icon='BONE_DATA')
        
        # 添加骨骼映射开关
        mapping_box = layout.box()
        
        # 使用更紧凑的布局
        top_row = mapping_box.row(align=True)
        top_row.prop(props, "enable_bone_mapping", text="启用骨骼映射")
        help_btn = top_row.row()
        help_btn.alignment = 'RIGHT'
        help_btn.prop(props, "show_mapping_help", text="", icon='QUESTION')
        
        # 添加自动映射和刷新按钮
        buttons_row = mapping_box.row(align=True)
        buttons_row.scale_y = 1.2
        buttons_row.operator("anim.auto_bone_mapping", text="自动映射", icon='AUTO')
        buttons_row.operator("anim.reload_bone_mapping", text="重新加载", icon='FILE_REFRESH')
        
        # 显示帮助信息
        if props.show_mapping_help:
            help_box = mapping_box.box()
            help_box.label(text="骨骼映射使用说明:", icon='INFO')
            help_box.label(text="1. 勾选要使用的源骨骼")
            help_box.label(text="2. 对需要映射的骨骼启用映射")
            help_box.label(text="3. 点击🔍按钮搜索目标骨骼")
            help_box.label(text="例如: leg_left(源) → Leg.L(目标)")
        
        if has_bones:
            # 添加全选/全不选按钮
            button_row = layout.row(align=True)
            button_row.scale_y = 1.2
            button_row.operator("anim.select_all_bones", text="全选", icon='CHECKBOX_HLT').select_all = True
            button_row.operator("anim.select_all_bones", text="全不选", icon='CHECKBOX_DEHLT').select_all = False
            
            # 显示骨骼列表
            box = layout.box()
            
            # 计算合适的列数
            total_bones = len(context.scene.bone_selection)
            
            if props.enable_bone_mapping:
                # 单列布局以适应更多控件
                col = box.column(align=True)
                
                if props.is_from_library:
                    source_type = "JSON文件"
                else:
                    source_type = "FBX文件"
                
                # 添加标题行，清楚标明左侧是源骨骼，右侧是目标骨骼
                header_row = col.row()
                header_row.label(text=f"源骨骼({source_type})")
                header_row.label(text="启用映射")
                header_row.label(text="目标骨骼(当前骨架)")
                
                for i, item in enumerate(context.scene.bone_selection):
                    row = col.row(align=True)
                    # 选中复选框
                    row.prop(item, "selected", text="")
                    # 骨骼名称
                    row.label(text=item.name)
                    # 启用映射复选框
                    map_toggle = row.row()
                    map_toggle.enabled = item.selected
                    map_toggle.prop(item, "use_mapping", text="", icon='ARROW_LEFTRIGHT')
                    # 映射目标输入框和搜索按钮
                    if item.selected and item.use_mapping:
                        map_field = row.row(align=True)
                        map_field.prop(item, "mapped_to", text="")
                        # 添加搜索按钮
                        search_op = map_field.operator("anim.search_bone", text="", icon='VIEWZOOM')
                        search_op.bone_index = i
                    else:
                        # 如果没有启用映射，添加一个空的占位符
                        row.label(text="")
            else:
                # 标准网格布局
                if total_bones > 20:
                    grid = box.grid_flow(row_major=True, columns=2, even_columns=True)
                    for item in context.scene.bone_selection:
                        row = grid.row(align=True)
                        row.prop(item, "selected", text="")
                        row.label(text=item.name)
                else:
                    # 单列时使用普通列布局
                    col = box.column(align=True)
                    for item in context.scene.bone_selection:
                        row = col.row(align=True)
                        row.prop(item, "selected", text="")
                        row.label(text=item.name)
        else:
            layout.label(text="未找到骨骼，请先选择一个骨架", icon='ERROR')
                
        # 添加底部提示
        layout.label(text="提示: 未选择任何骨骼将取消操作", icon='INFO')

class ANIM_OT_SelectAllBones(bpy.types.Operator):
    bl_idname = "anim.select_all_bones"
    bl_label = "全选/全不选骨骼"
    bl_options = {'REGISTER', 'UNDO'}
    
    select_all: bpy.props.BoolProperty()
    
    def execute(self, context):
        for item in context.scene.bone_selection:
            item.selected = self.select_all
        return {'FINISHED'}

class ANIM_UL_ActionLibrary(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            split = layout.split(factor=0.6)
            split.label(text=item.name, icon='ACTION')
            split.label(text=f"{item.source_fbx} [{item.frame_range[0]}-{item.frame_range[1]}]")
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text=item.name, icon='ACTION')

class ANIM_OT_ExportAction(bpy.types.Operator):
    bl_idname = "anim.export_action"
    bl_label = "导出动作为JSON"
    bl_options = {'REGISTER', 'UNDO'}
    
    filepath: bpy.props.StringProperty(
        subtype="FILE_PATH",
        default="animation.json"
    )
    filter_glob: bpy.props.StringProperty(
        default="*.json",
        options={'HIDDEN'}
    )
    
    def execute(self, context):
        target = context.active_object
        if not target or target.type != 'ARMATURE' or not target.animation_data or not target.animation_data.action:
            self.report({'ERROR'}, "未选择含有动作的骨架")
            return {'CANCELLED'}
        
        action = target.animation_data.action
        
        # 使用现有的序列化函数
        try:
            serialize_action(action, self.filepath)
            self.report({'INFO'}, f"成功导出动作: {action.name}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"导出失败: {str(e)}")
            return {'CANCELLED'}
    
    def invoke(self, context, event):
        if context.active_object and context.active_object.animation_data and context.active_object.animation_data.action:
            self.filepath = clean_filename(context.active_object.animation_data.action.name) + ".json"
        
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class ANIM_OT_ImportActionFromJSON(bpy.types.Operator):
    bl_idname = "anim.import_json"
    bl_label = "导入JSON到动作库"
    bl_options = {'REGISTER', 'UNDO'}
    
    filepath: bpy.props.StringProperty(
        subtype="FILE_PATH"
    )
    filter_glob: bpy.props.StringProperty(
        default="*.json",
        options={'HIDDEN'}
    )
    
    def execute(self, context):
        try:
            # 使用现有的反序列化函数临时加载动作
            action = deserialize_action(self.filepath)
            if not action:
                self.report({'ERROR'}, "JSON文件格式错误或不包含有效动作")
                return {'CANCELLED'}
            
            # 获取动作的帧范围
            frames = []
            for fcurve in action.fcurves:
                frames.extend([kp.co.x for kp in fcurve.keyframe_points])
            frame_range = (int(min(frames)), int(max(frames))) if frames else (1, 250)
            
            # 准备保存路径
            json_path = Path(self.filepath)
            safe_name = clean_filename(action.name)
            fbx_stem = "Imported_JSON"
            save_dir = LIBRARY_PATH / fbx_stem
            save_dir.mkdir(exist_ok=True)
            save_path = save_dir / f"{safe_name}.json"
            counter = 1
            while save_path.exists():
                save_path = save_dir / f"{safe_name}_{counter}.json"
                counter += 1
            
            # 复制JSON文件到库目录
            with open(json_path, 'r', encoding='utf-8') as src_file:
                action_data = json.load(src_file)
                with open(save_path, 'w', encoding='utf-8') as dest_file:
                    json.dump(action_data, dest_file, indent=2, ensure_ascii=False)

            props = context.scene.anim_merge_props
            _refresh_library_view(context, target_filepath=save_path, target_name=action.name)
            _set_library_message(
                props,
                f"已导入JSON动作: {action.name}  ({frame_range[0]}-{frame_range[1]})",
            )
            
            # 清理临时动作
            bpy.data.actions.remove(action)
            
            self.report({'INFO'}, f"成功导入动作: {action.name}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"导入失败: {str(e)}")
            return {'CANCELLED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
