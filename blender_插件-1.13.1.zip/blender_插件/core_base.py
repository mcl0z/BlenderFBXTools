# Core data models and low-level animation helpers.
# Extracted from the original monolithic addon for maintainability.
import bpy
import os
import json
import re
import mathutils
from pathlib import Path
import urllib.request
import ssl
import threading
import tempfile
import shutil
import time
import math
import random
from urllib.error import URLError, HTTPError

ADDON_INFO = {
    "name": "动画助手",
    "author": "ΔIng KMnO4",
    "version": (1, 13, 1),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > 动画工具",
    "description": "AMI 动画工作流工具，支持动作库、动画合并、骨骼映射、路径/呼吸/摄像机动画。",
    "warning": "",
    "doc_url": "",
    "category": "Animation",
}
LIBRARY_PATH = Path.home() / "AniTools"
LIBRARY_PATH.mkdir(parents=True, exist_ok=True)

# 跟踪启动定时器是否注册
_startup_timer_registered = False

# 服务器设置
UPDATE_SERVER = "http://blenderplusinupdata.432445.xyz"
UPDATE_CHECK_URL = f"{UPDATE_SERVER}/check_update"
UPDATE_CHECK_INTERVAL = 86400
last_update_check = 0
update_available = False
latest_version = None
download_url = None
update_message = ""

def clean_filename(name):
    return re.sub(r'[<>:"/\\|?*]', '_', name).strip('_')[:120]

def format_vector(v, prec=3):
    return f"({v.x:.{prec}f}, {v.y:.{prec}f}, {v.z:.{prec}f})"

class ActionLibraryItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="动作名称")
    filepath: bpy.props.StringProperty(name="文件路径")
    source_fbx: bpy.props.StringProperty(name="来源FBX")
    frame_range: bpy.props.IntVectorProperty(size=2, name="帧范围")

def get_target_bones(scene, context):

    items = []
    
    # 当前选中骨架
    active_obj = context.active_object
    if active_obj and active_obj.type == 'ARMATURE':
        # 添加一个空选项，表示不映射
        items.append(("", "不映射", "不映射到任何骨骼"))
        
        # 获取骨架中的所有骨骼
        for bone in active_obj.data.bones:
            items.append((bone.name, bone.name, f"映射到 {bone.name} 骨骼"))
    
    # 如果没有找到骨架或骨骼，显示一个提示选项
    if not items:
        items.append(("", "请先选择骨架", ""))
    
    return items

def get_target_bones_enum(self, context):

    items = []
    
    # 当前选中骨架
    active_obj = context.active_object
    if active_obj and active_obj.type == 'ARMATURE':
        # 添加一个空选项，表示不映射
        items.append(("", "不映射", "不映射到任何骨骼"))
        
        # 获取骨架中的所有骨骼
        for bone in active_obj.data.bones:
            items.append((bone.name, bone.name, f"映射到 {bone.name} 骨骼"))
    
    # 如果没有找到骨架或骨骼，显示一个提示选项
    if not items:
        items.append(("", "请先选择骨架", ""))
    
    return items

def get_bone_search_items(self, context):

    items = []
    
    # 获取当前骨架
    active_obj = context.active_object
    if active_obj and active_obj.type == 'ARMATURE':
        # 获取搜索文本
        search_text = self.bone_search_text.lower() if hasattr(self, 'bone_search_text') else ""
        
        # 搜索所有匹配的骨骼
        bone_names = []
        for bone in active_obj.data.bones:
            if search_text in bone.name.lower():
                bone_names.append(bone.name)
        
        # 按字母排序
        bone_names.sort()
        
        # 转换为选项列表
        for name in bone_names:
            items.append((name, name, f"选择 {name}"))
    
    # 如果没有匹配的骨骼，添加一个提示
    if not items:
        items.append(("", "没有匹配的骨骼", ""))
        
    return items

class BoneSelectionItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="骨骼名称")
    selected: bpy.props.BoolProperty(name="选中", default=True)
    mapped_to: bpy.props.StringProperty(name="映射到", default="")
    use_mapping: bpy.props.BoolProperty(name="启用映射", default=False)

class AnimMergeProperties(bpy.types.PropertyGroup):
    filepath: bpy.props.StringProperty(subtype='FILE_PATH', options={'SKIP_SAVE'})
    source_start: bpy.props.IntProperty(
        name="源起始帧",
        default=1,
        min=0
    )
    source_end: bpy.props.IntProperty(
        name="源结束帧",
        default=250,
        min=1
    )
    target_start: bpy.props.IntProperty(
        name="目标起始帧",
        default=1,
        min=0
    )
    loop_times: bpy.props.IntProperty(
        name="循环次数",
        default=1,
        min=1,
        description="将动画循环复制指定次数"
    )
    merge_mode: bpy.props.EnumProperty(
        name="合并模式",
        items=[
            ('REPLACE', "覆盖", "完全替换目标时间段内的动画"),
            ('MIX', "混合(测试ing)", "保留原有动画并混合新动画")
        ],
        default='REPLACE'
    )
    apply_transform: bpy.props.BoolProperty(
        name="保持骨架位置和旋转",
        default=True,
        description="应用动画时保持原有骨架的位置和旋转"
    )
    action_library_index: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    action_library_items: bpy.props.CollectionProperty(type=ActionLibraryItem, options={'SKIP_SAVE'})
    show_library: bpy.props.BoolProperty(default=False, name="显示动作库", options={'SKIP_SAVE'})
    is_from_library: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})
    library_last_message: bpy.props.StringProperty(
        name="动作库最近消息",
        default="",
        options={'SKIP_SAVE'}
    )
    
    # 自动检查更新设置
    auto_check_update: bpy.props.BoolProperty(
        name="自动检查更新",
        default=True,
        description="启动时自动检查插件更新"
    )
    
    # 添加骨骼映射控制
    enable_bone_mapping: bpy.props.BoolProperty(
        name="启用骨骼映射",
        default=False,
        description="允许将源动画中的骨骼映射到目标骨架中的骨骼",
        update=lambda self, context: update_bone_mapping(self, context)
    )
    
    show_mapping_help: bpy.props.BoolProperty(
        name="显示帮助",
        default=False
    )
    
    # 添加当前活动面板属性
    active_panel: bpy.props.EnumProperty(
        name="当前功能",
        items=[
            ('MERGE', "动画合并", "FBX动画合并功能"),
            ('LIBRARY', "动作库", "动作资产库功能"),
            ('PATH', "路径动画", "贝塞尔路径动画工具"),
            ('BREATH', "呼吸动画", "骨骼呼吸动画功能"),
            ('CAMERA', "摄像机动画", "摄像机相关动画工具"), # 新增摄像机功能选项
            ('UPDATE', "更新信息", "插件更新与信息"),
        ],
        default='MERGE',
        options={'SKIP_SAVE'}
    )

class PathAnimationProperties(bpy.types.PropertyGroup):
    """贝塞尔曲线路径动画设置"""
    
    # 曲线控制点数量
    control_points: bpy.props.IntProperty(
        name="控制点数量",
        description="贝塞尔曲线控制点数量",
        default=3,
        min=2,
        max=20
    )
    
    # 存储上一次应用的控制点数量
    applied_control_points: bpy.props.IntProperty(default=3)
    
    # 动画帧范围
    frame_start: bpy.props.IntProperty(
        name="起始帧",
        description="路径动画的起始帧",
        default=1,
        min=1
    )
    
    frame_end: bpy.props.IntProperty(
        name="结束帧",
        description="路径动画的结束帧",
        default=250,
        min=2
    )
    
    # 速度设置
    speed_factor: bpy.props.FloatProperty(
        name="速度因子",
        description="控制物体沿路径移动的速度",
        default=1.0,
        min=0.1,
        max=10.0
    )
    
    # 插值类型 - 简化为三种选项
    interpolation_type: bpy.props.EnumProperty(
        name="插值类型",
        description="选择动画的插值方式",
        items=[
            ('LINEAR', "平移", "线性插值，均匀速度"),
            ('EASE_IN', "先慢后快", "物体会先慢慢加速，然后快速移动"),
            ('EASE_OUT', "先快后慢", "物体会先快速移动，然后慢慢减速")
        ],
        default='LINEAR'
    )
    
    # 是否旋转
    follow_path: bpy.props.BoolProperty(
        name="跟随路径旋转",
        description="物体移动时是否沿路径方向旋转",
        default=True
    )
    
    # 当前曲线对象
    curve_object: bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="曲线对象",
        description="当前创建的贝塞尔曲线对象"
    )

    # 路径动画目标对象
    target_object: bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="目标对象",
        description="沿路径运动的目标对象"
    )
    
    # 是否展示高级选项
    show_advanced: bpy.props.BoolProperty(
        name="高级选项",
        description="显示更多设置选项",
        default=False
    )
    
    # 循环类型
    loop_type: bpy.props.EnumProperty(
        name="循环类型",
        description="选择动画如何循环",
        items=[
            ('NONE', "不循环", "动画播放一次后停止"),
            ('REPEAT', "重复", "动画重复播放"),
            ('PING_PONG', "来回", "动画正向播放后再反向播放")
        ],
        default='NONE'
    )
    
    # 循环次数
    loop_count: bpy.props.IntProperty(
        name="循环次数",
        description="设置动画循环的次数 (0表示无限循环)",
        default=0,
        min=0,
        max=100
    )
    
    # 循环间隔
    loop_gap: bpy.props.IntProperty(
        name="循环间隔",
        description="设置循环之间的帧间隔 (仅用于重复模式)",
        default=0,
        min=0,
        max=100
    )
    
    # 是否更新时间线范围
    update_timeline: bpy.props.BoolProperty(
        name="更新时间线范围",
        description="应用路径动画时是否自动更新场景的时间线范围",
        default=False
    )

# 骨骼映射开关更新回调函数
def update_bone_mapping(self, context):
    # 如果对话框已经打开，不处理此回调，避免与对话框中的操作冲突
    if hasattr(context.window_manager, 'invoke_props_dialog_running') and context.window_manager.invoke_props_dialog_running:
        return
    
    # 保存当前状态
    context.scene['bone_mapping_enabled'] = self.enable_bone_mapping
    
    # 自动重新加载骨骼列表
    if hasattr(context.scene, 'bone_selection'):
        # 清空当前骨骼选择列表
        context.scene.bone_selection.clear()
        
        # 根据映射开关状态加载不同的骨骼列表
        if self.enable_bone_mapping:
            # 加载源文件中的骨骼列表
            source_bones = load_source_bones(context, self)
            
            # 如果成功获取到源骨骼，添加到选择列表
            if source_bones:
                for bone_name in sorted(source_bones):
                    item = context.scene.bone_selection.add()
                    item.name = bone_name
                    item.selected = True
                    item.use_mapping = False
                    item.mapped_to = ""
                print(f"自动加载了 {len(source_bones)} 个源骨骼")
            else:
                # 如果没有源骨骼，使用当前骨架的骨骼
                print("未找到源文件骨骼，使用当前骨架骨骼")
                active_obj = context.active_object
                if active_obj and active_obj.type == 'ARMATURE':
                    for bone in active_obj.data.bones:
                        item = context.scene.bone_selection.add()
                        item.name = bone.name
                        item.selected = True
                        item.use_mapping = False
                        item.mapped_to = ""
        else:
            # 不启用骨骼映射时，使用当前骨架的骨骼
            active_obj = context.active_object
            if active_obj and active_obj.type == 'ARMATURE':
                for bone in active_obj.data.bones:
                    item = context.scene.bone_selection.add()
                    item.name = bone.name
                    item.selected = True
                    item.use_mapping = False
                    item.mapped_to = ""
    
    return None

# 用于加载源文件骨骼的函数，便于重用
def load_source_bones(context, props):
    # 从文件中获取源骨骼
    source_bones = []
    
    # 根据来源类型(库或FBX文件)获取骨骼列表
    if props.is_from_library:
        if props.action_library_items and props.action_library_index < len(props.action_library_items):
            item = props.action_library_items[props.action_library_index]
            filepath = Path(item.filepath)
            
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    action_data = json.load(f)
                
                # 提取骨骼名称
                for fcurve in action_data.get('fcurves', []):
                    data_path = fcurve.get('data_path', '')
                    match = re.search(r'pose\.bones\["([^"]+)"\]', data_path)
                    if match and match.group(1) not in source_bones:
                        source_bones.append(match.group(1))
            except Exception as e:
                print(f"读取动作文件失败: {str(e)}")
    else:
        # 从FBX文件中获取骨骼
        if props.filepath:
            # 临时导入FBX以获取骨骼列表
            original_objects = set(context.scene.objects)
            try:
                bpy.ops.import_scene.fbx(
                    filepath=props.filepath,
                    use_anim=True,
                    automatic_bone_orientation=True,
                    ignore_leaf_bones=True
                )
                
                # 找出新导入的物体
                new_objects = set(context.scene.objects) - original_objects
                armatures = [obj for obj in new_objects if obj.type == 'ARMATURE']
                
                if armatures:
                    # 第一个骨架
                    armature = armatures[0]
                    # 获取骨骼名称
                    source_bones = [bone.name for bone in armature.data.bones]
                
                # 清理导入的物体
                for obj in new_objects:
                    bpy.data.objects.remove(obj, do_unlink=True)
            except Exception as e:
                print(f"FBX导入失败: {str(e)}")
    
    return source_bones

# 用于重新加载骨骼列表的操作符
class ANIM_OT_ReloadBoneMapping(bpy.types.Operator):

    bl_idname = "anim.reload_bone_mapping"
    bl_label = "重新加载骨骼"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.anim_merge_props
        
        # 清空骨骼选择列表
        context.scene.bone_selection.clear()
        
        # 如果启用骨骼映射，获取源文件中的骨骼列表
        if props.enable_bone_mapping:
            # 加载源文件骨骼
            source_bones = load_source_bones(context, props)
            
            # 如果成功获取到源骨骼，添加到选择列表
            if source_bones:
                for bone_name in sorted(source_bones):
                    item = context.scene.bone_selection.add()
                    item.name = bone_name
                    item.selected = True
                    # 默认不启用映射
                    item.use_mapping = False
                    item.mapped_to = ""
                
                self.report({'INFO'}, f"已加载 {len(source_bones)} 个源骨骼")
            else:
                # 如果没有获取到源骨骼，使用当前骨架的骨骼
                self.report({'WARNING'}, "未找到源文件中的骨骼，将使用当前骨架的骨骼")
                active_obj = context.active_object
                if active_obj and active_obj.type == 'ARMATURE':
                    for bone in active_obj.data.bones:
                        item = context.scene.bone_selection.add()
                        item.name = bone.name
                        item.selected = True
                        item.use_mapping = False
                        item.mapped_to = ""
        else:
            # 不启用骨骼映射时，使用当前骨架的骨骼
            active_obj = context.active_object
            if active_obj and active_obj.type == 'ARMATURE':
                for bone in active_obj.data.bones:
                    item = context.scene.bone_selection.add()
                    item.name = bone.name
                    item.selected = True
                    item.use_mapping = False
                    item.mapped_to = ""
        
        return {'FINISHED'}

def load_fbx_animation(filepath):
    scene = bpy.context.scene
    original_objects = set(scene.objects)
    imported_objects = set()

    def cleanup_imported_objects():
        # 清理本次临时导入的所有对象，避免把FBX内容留在场景里
        for obj in list(imported_objects):
            try:
                if obj and obj.name in bpy.data.objects:
                    bpy.data.objects.remove(obj, do_unlink=True)
            except Exception as e:
                print(f"清理临时导入对象失败: {e}")

    try:
        bpy.ops.import_scene.fbx(
            filepath=filepath,
            use_anim=True,
            automatic_bone_orientation=True,
            ignore_leaf_bones=True
        )
    except Exception as e:
        print(f"FBX导入失败: {str(e)}")
        return None

    imported_objects = set(scene.objects) - original_objects
    armatures = [obj for obj in imported_objects if obj.type == 'ARMATURE']
    if not armatures:
        cleanup_imported_objects()
        return None

    armature = armatures[0]
    source_action = armature.animation_data.action if armature.animation_data else None
    if not source_action:
        cleanup_imported_objects()
        return None

    # 复制一份独立动作，后续即使删除临时导入对象也不受影响
    copied_action = source_action.copy()
    copied_action.name = source_action.name

    cleanup_imported_objects()

    # 如果源动作已无引用，顺手清理避免数据块堆积
    try:
        if source_action.users == 0:
            bpy.data.actions.remove(source_action)
    except Exception as e:
        print(f"清理临时源动作失败: {e}")

    return copied_action

def serialize_action(action, save_path):
    action_data = {
        "name": action.name,
        "fcurves": []
    }
    for fcurve in action.fcurves:
        curve_data = {
            "data_path": fcurve.data_path,
            "array_index": fcurve.array_index,
            "keyframes": []
        }
        for kp in fcurve.keyframe_points:
            curve_data["keyframes"].append({
                "frame": kp.co.x,
                "value": kp.co.y,
                "interpolation": kp.interpolation
            })
        action_data["fcurves"].append(curve_data)
    
    with open(save_path, 'w', encoding='utf-8') as f:
        json.dump(action_data, f, indent=2, ensure_ascii=False)

def deserialize_action(load_path):
    try:
        with open(load_path, 'r', encoding='utf-8') as f:
            action_data = json.load(f)
    except Exception as e:
        print(f"加载失败:{str(e)}")
        return None
    
    action = bpy.data.actions.new(name=action_data["name"])
    
    for curve_data in action_data["fcurves"]:
        fcurve = action.fcurves.new(
            curve_data["data_path"], 
            index=curve_data["array_index"]
        )
        for kp_data in curve_data["keyframes"]:
            kp = fcurve.keyframe_points.insert(kp_data["frame"], kp_data["value"])
            kp.interpolation = kp_data["interpolation"]
    
    return action

def merge_actions(target_action, source_action, time_offset, source_range, merge_mode, loop_times=1):
    # 确保参数为整数
    time_offset = int(time_offset)
    source_range = (int(source_range[0]), int(source_range[1]))
    
    merged_action = target_action.copy() if target_action else bpy.data.actions.new("Merged_Action")
    duration = source_range[1] - source_range[0]
    
    for loop in range(loop_times):
        current_offset = time_offset + loop * duration
        
        for src_fcurve in source_action.fcurves:
            # 检查源曲线是否有关键帧
            if len(src_fcurve.keyframe_points) == 0:
                continue
                
            target_fcurve = next(
                (fc for fc in merged_action.fcurves 
                 if fc.data_path == src_fcurve.data_path 
                 and fc.array_index == src_fcurve.array_index),
                None
            )
            
            if not target_fcurve:
                target_fcurve = merged_action.fcurves.new(
                    src_fcurve.data_path,
                    index=src_fcurve.array_index
                )
            
            # 获取现有关键帧
            existing_keys = {}
            if target_fcurve.keyframe_points:  # 检查目标曲线是否有关键帧
                for k in target_fcurve.keyframe_points:
                    # 使用整数帧索引避免浮点精度问题
                    existing_keys[int(k.co.x)] = k
            
            # 预先计算要添加的关键帧
            keys_to_add = []
            for src_key in src_fcurve.keyframe_points:
                frame = src_key.co.x
                # 使用范围检查代替精确比较
                if not (source_range[0] <= frame <= source_range[1]):
                    continue
                    
                # 确保计算结果为整数帧，避免浮点精度问题
                target_frame = int(frame - source_range[0] + current_offset)
                
                if merge_mode == 'REPLACE':
                    # 先记录要添加的，后面一次性处理
                    keys_to_add.append((target_frame, src_key.co.y, src_key.interpolation))
                    
                elif merge_mode == 'MIX':
                    if target_frame in existing_keys:
                        existing_val = existing_keys[target_frame].co.y
                        new_val = (existing_val + src_key.co.y) * 0.5
                        keys_to_add.append((target_frame, new_val, src_key.interpolation))
                    else:
                        keys_to_add.append((target_frame, src_key.co.y, src_key.interpolation))
            
            # 如果是替换模式，先清除将被替换的关键帧
            if merge_mode == 'REPLACE' and keys_to_add:
                frames_to_remove = [frame for frame in existing_keys.keys() 
                                   if any(abs(frame - key[0]) < 0.5 for key in keys_to_add)]
                for frame in frames_to_remove:
                    if frame in existing_keys:
                        try:
                            target_fcurve.keyframe_points.remove(existing_keys[frame])
                        except:
                            # 如果删除失败，忽略错误继续处理
                            pass
            
            # 添加关键帧
            if keys_to_add:
                for frame, value, interp in keys_to_add:
                    try:
                        # 检查是否已存在该帧的关键帧（避免冲突）
                        existing = next((k for k in target_fcurve.keyframe_points if abs(k.co.x - frame) < 0.5), None)
                        if existing:
                            existing.co.y = value
                            existing.interpolation = interp
                        else:
                            new_key = target_fcurve.keyframe_points.insert(frame, value)
                            new_key.interpolation = interp
                    except Exception as e:
                        print(f"添加关键帧时出错: {str(e)}")
                        continue
            
            # 更新曲线
            try:
                target_fcurve.update()
            except:
                pass
    
    return merged_action

def merge_actions_with_transform(target_action, source_action, time_offset, source_range, merge_mode, target_armature, loop_times=1):

    # 确保参数为整数
    time_offset = int(time_offset)
    source_range = (int(source_range[0]), int(source_range[1]))
    
    # 记录原始变换
    original_location = target_armature.location.copy()
    original_rotation_euler = target_armature.rotation_euler.copy()
    original_rotation_mode = target_armature.rotation_mode
    original_rotation_quaternion = target_armature.rotation_quaternion.copy() if hasattr(target_armature, 'rotation_quaternion') else None
    
    # 检查源动作和目标动作
    if not source_action.fcurves:
        return target_action.copy() if target_action else bpy.data.actions.new("Merged_Action")
    
    # 先执行常规合并
    try:
        merged_action = merge_actions(target_action, source_action, time_offset, source_range, merge_mode, loop_times)
    except Exception as e:
        print(f"合并动作时出错: {str(e)}")
        # 如果合并失败，返回一个新的空动作或复制目标动作
        return target_action.copy() if target_action else bpy.data.actions.new("Merged_Action")
    
    # 获取帧范围
    duration = source_range[1] - source_range[0]
    total_duration = duration * loop_times
    
    # 对骨架对象级别的变换曲线进行处理
    location_curves = {}
    rotation_euler_curves = {}
    rotation_quaternion_curves = {}
    
    for fcurve in merged_action.fcurves:
        if fcurve.data_path == 'location':
            location_curves[fcurve.array_index] = fcurve
        elif fcurve.data_path == 'rotation_euler':
            rotation_euler_curves[fcurve.array_index] = fcurve
        elif fcurve.data_path == 'rotation_quaternion':
            rotation_quaternion_curves[fcurve.array_index] = fcurve
    
    # 处理位置曲线
    for axis, fcurve in location_curves.items():
        if not fcurve.keyframe_points:  # 检查是否有关键帧
            continue
        for kp in fcurve.keyframe_points:
            if time_offset <= kp.co.x <= time_offset + total_duration:
                kp.co.y += original_location[axis]
    
    # 处理欧拉旋转曲线
    for axis, fcurve in rotation_euler_curves.items():
        if not fcurve.keyframe_points:  # 检查是否有关键帧
            continue
        for kp in fcurve.keyframe_points:
            if time_offset <= kp.co.x <= time_offset + total_duration:
                kp.co.y += original_rotation_euler[axis]
    
    # 处理四元数旋转曲线（这里需要更复杂的四元数数学）
    if rotation_quaternion_curves and original_rotation_quaternion:
        orig_quat = original_rotation_quaternion
        
        # 收集所有关键帧
        frames = set()
        for axis, fcurve in rotation_quaternion_curves.items():
            if not fcurve.keyframe_points:  # 检查是否有关键帧
                continue
            for kp in fcurve.keyframe_points:
                if time_offset <= kp.co.x <= time_offset + total_duration:
                    # 使用整数帧来避免浮点精度问题
                    frames.add(int(kp.co.x))
        
        # 按帧处理四元数
        for frame in frames:
            # 获取当前帧的四元数
            current_quat = mathutils.Quaternion()
            for i in range(4):
                if i in rotation_quaternion_curves and rotation_quaternion_curves[i].keyframe_points:
                    for kp in rotation_quaternion_curves[i].keyframe_points:
                        if abs(kp.co.x - frame) < 0.5:  # 使用0.5作为阈值，更合理地匹配帧
                            current_quat[i] = kp.co.y
            
            # 应用原始四元数旋转（相乘）
            result_quat = orig_quat @ current_quat
            
            # 更新关键帧值
            for i in range(4):
                if i in rotation_quaternion_curves and rotation_quaternion_curves[i].keyframe_points:
                    for kp in rotation_quaternion_curves[i].keyframe_points:
                        if abs(kp.co.x - frame) < 0.5:  # 使用0.5作为阈值
                            kp.co.y = result_quat[i]
    
    # 更新所有曲线
    for fcurve in merged_action.fcurves:
        try:
            fcurve.update()
        except:
            pass
    
    return merged_action

def apply_action_sequence(target_action, source_action, target_start, source_range, merge_mode, loop_times, apply_transform=False, target_armature=None):

    # 确保参数为整数，避免浮点精度问题
    target_start = int(target_start)
    source_range = (int(source_range[0]), int(source_range[1]))
    
    result_action = target_action.copy() if target_action else bpy.data.actions.new("Merged_Action")
    
    # 第一次应用初始位置
    current_start_frame = target_start
    
    # 计算源动画的持续时间
    source_duration = source_range[1] - source_range[0]
    
    # 记录每次应用后的终点，作为下一次的起点
    current_end_frame = current_start_frame + source_duration
    
    # 记录原始位置增量（用于位移动画）
    original_location_start = None
    original_location_end = None
    location_delta = None
    
    # 查找并记录源动作中的第一帧，用于后续处理
    first_frame_in_source = int(source_range[0])
    
    # 找出源动作中的位置变化（对于走路等动画）
    if apply_transform and source_action:
        # 查找位置曲线
        location_curves = {}
        for fcurve in source_action.fcurves:
            if fcurve.data_path == 'location':
                location_curves[fcurve.array_index] = fcurve
        
        # 如果有位置曲线，计算起始和结束位置
        if location_curves:
            # 创建起始和结束位置向量
            original_location_start = mathutils.Vector([0, 0, 0])
            original_location_end = mathutils.Vector([0, 0, 0])
            
            # 用于精确匹配的误差阈值
            epsilon = 0.01
            
            # 填充位置数据
            for axis, fcurve in location_curves.items():
                if not fcurve.keyframe_points:
                    continue
                
                # 收集所有关键帧并按时间排序
                all_keys_in_range = [kp for kp in fcurve.keyframe_points if source_range[0] <= kp.co.x <= source_range[1]]
                all_keys_in_range.sort(key=lambda kp: kp.co.x)
                
                if all_keys_in_range:
                    # 使用范围内第一个和最后一个关键帧
                    original_location_start[axis] = all_keys_in_range[0].co.y
                    original_location_end[axis] = all_keys_in_range[-1].co.y
            
            # 计算位置变化量
            location_delta = original_location_end - original_location_start
            print(f"检测到位置变化: {location_delta}，起始：{original_location_start}，结束：{original_location_end}")
    
    # 记录每次循环的帧范围，用于后续更新
    applied_ranges = []
    
    # 依次应用每一个循环
    for i in range(loop_times):
        print(f"应用循环 {i+1}/{loop_times}，起始帧: {current_start_frame}")
        
        # 创建源动作的副本
        loop_source = source_action.copy()
        
        # 如果不是第一次循环，且有位置变化，则调整本次循环的所有关键帧位置
        if i > 0 and location_delta is not None:
            accumulated_delta = location_delta * i
            
            # 调整位置曲线的所有关键帧
            for fcurve in loop_source.fcurves:
                if fcurve.data_path == 'location':
                    axis = fcurve.array_index
                    # 确保变化值足够大才应用，避免浮点精度问题
                    if abs(accumulated_delta[axis]) > 0.0001:
                        for kp in fcurve.keyframe_points:
                            kp.co.y += accumulated_delta[axis]
        
        # 合并此次循环的动作
        if apply_transform and target_armature:
            temp_result = merge_actions_with_transform(
                result_action, 
                loop_source, 
                current_start_frame, 
                source_range, 
                merge_mode, 
                target_armature, 
                1  # 每次只合并一次
            )
        else:
            temp_result = merge_actions(
                result_action, 
                loop_source, 
                current_start_frame, 
                source_range, 
                merge_mode, 
                1  # 每次只合并一次
            )
        
        # 清理本次循环的临时动作
        bpy.data.actions.remove(loop_source)
        
        # 如果合并成功，更新结果动作
        if temp_result:
            # 先保存旧的结果动作
            old_result = result_action
            # 更新为新的结果
            result_action = temp_result
            # 删除旧的结果（如果不是第一个）
            if i > 0:
                bpy.data.actions.remove(old_result)
        
        # 记录本次应用的帧范围，确保使用整数帧
        applied_ranges.append((int(current_start_frame), int(current_end_frame)))
        
        # 更新下一次循环的起始帧（确保帧号为整数）
        current_start_frame = int(current_end_frame)
        current_end_frame = int(current_start_frame + source_duration)
    
    # 最后一步：删除所有循环衔接处的第一帧关键帧（除了第一个循环）
    if loop_times > 1:
        delete_first_frames_at_loop_boundaries(result_action, applied_ranges, first_frame_in_source)
    
    return result_action, applied_ranges

def delete_first_frames_at_loop_boundaries(action, applied_ranges, first_frame_in_source):

    if len(applied_ranges) <= 1:
        return  # 只有一个循环，不需要删除
    
    # 对于每个循环的起始点（第一个循环除外）
    for i in range(1, len(applied_ranges)):
        loop_start_frame = applied_ranges[i][0]
        
        # 计算这个循环中第一帧的绝对帧位置
        first_frame_absolute = loop_start_frame  # 循环起始帧就是第一帧的位置
        
        print(f"删除循环 {i} 开始处的第一帧关键帧，帧号: {first_frame_absolute}")
        
        # 查找并删除所有位于这个位置的关键帧
        for fcurve in action.fcurves:
            # 查找并收集这个位置的关键帧
            keyframes_to_remove = []
            for j, kp in enumerate(fcurve.keyframe_points):
                if abs(kp.co.x - first_frame_absolute) < 0.5:  # 使用容差匹配
                    keyframes_to_remove.append(j)
            
            # 从后向前删除（避免索引变化问题）
            for idx in reversed(keyframes_to_remove):
                try:
                    fcurve.keyframe_points.remove(fcurve.keyframe_points[idx])
                    print(f"从数据路径 {fcurve.data_path}[{fcurve.array_index}] 删除了帧 {first_frame_absolute} 的关键帧")
                except Exception as e:
                    print(f"删除关键帧时出错: {str(e)}")
            
            # 更新曲线
            try:
                fcurve.update()
            except:
                pass



def load_library_actions():
    try:
        if LIBRARY_PATH.exists():
            for scene in bpy.data.scenes:
                scene.anim_merge_props.action_library_items.clear()
                
                for category_dir in LIBRARY_PATH.glob("*"):
                    if category_dir.is_dir():
                        for action_file in category_dir.glob("*.json"):
                            try:
                                with open(action_file, 'r', encoding='utf-8') as f:
                                    data = json.load(f)
                                    frames = []
                                    for curve in data['fcurves']:
                                        frames.extend([k['frame'] for k in curve['keyframes']])
                                    frame_range = (int(min(frames)), int(max(frames))) if frames else (1, 250)
                                    
                                    item = scene.anim_merge_props.action_library_items.add()
                                    item.name = data.get('name', action_file.stem)
                                    item.filepath = str(action_file)
                                    item.source_fbx = category_dir.name
                                    item.frame_range = frame_range
                            except Exception as e:
                                print(f"加载动作失败:{action_file}，错误:{str(e)}")
    except Exception as e:
        print(f"初始化动作库失败:{str(e)}")
